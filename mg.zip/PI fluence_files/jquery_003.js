
(function($) {
	
	$.popgSLfrm = {
		
		// These properties can be read/written by accessing $.popgSLfrm.propertyName from your scripts at any time
		
		verticalOffset: -175,                // vertical offset of the dialog from center screen, in pixels
		horizontalOffset: -50,                // horizontal offset of the dialog from center screen, in pixels/
		repositionOnResize: false,           // re-centers the dialog on window resize
		overlayOpacity: .65,                // transparency level of overlay
		overlayColor: '#B5B5B5',               // base color of overlay
		draggable: true,                    // make the dialogs draggable (requires UI Draggables plugin)
		okButton: '&nbsp;OK&nbsp;',         // text for the OK button
		savButton: '&nbsp;Save&nbsp;',
		delButton: '&nbsp;Delete&nbsp;',
		clrButton: '&nbsp;Clear&nbsp;',
		cancelButton: '&nbsp;Cancel&nbsp;', // text for the Cancel button
		displayMode: false, // FALSE for minimized screen and TRUE for full screen
		containerTop: 0,
		containerLeft:0,
		cnTxtHelp: -400,
		cnTxtHelpSid: false,
		styleIds: [],
		// Public methods
		
		GntTaskFCAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskFCAdd';
			$.popgSLfrm.cnTxtHelp = 401;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntTaskFCAdd', styles);
		},
		GntTaskFCEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskFCEdit';
			$.popgSLfrm.cnTxtHelp = 402;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskFCEdit', styles);
		},
		GntTaskPredAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskPredAdd';
			$.popgSLfrm.cnTxtHelp = 403;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntTaskPredAdd', styles);
		},
		GntTaskPredEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskPredEdit';
			$.popgSLfrm.cnTxtHelp = 404;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskPredEdit', styles);
		},
		GntSaveAs: function(message, value, title, styles) {
			if( title == null ) title = 'GntSaveAs';
			$.popgSLfrm.cnTxtHelp = 405;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntSaveAs', styles);
		},
		GntBaseline: function(message, value, title, styles) {
			if( title == null ) title = 'GntBaseline';
			$.popgSLfrm.cnTxtHelp = 406;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntBaseline', styles);
		},
		ShwResRate: function(message, value, title, styles) {
			if( title == null ) title = 'ShwResRate';
			$.popgSLfrm.cnTxtHelp = 407;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ShwResRate', styles);
		},
		GntDelivUpload: function(message, value, title, styles) {
			if( title == null ) title = 'GntDelivUpload';
			$.popgSLfrm.cnTxtHelp = 408;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntDelivUpload', styles);
		},
		GntactFCAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntactFCAdd';
			$.popgSLfrm.cnTxtHelp = 409;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntactFCAdd', styles);
		},
		GntactFCEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntactFCEdit';
			$.popgSLfrm.cnTxtHelp = 410;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntactFCEdit', styles);
		},
		GntactRWAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntactRWAdd';
			$.popgSLfrm.cnTxtHelp = 411;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntactRWAdd', styles);
		},
		GntactRWEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntactRWEdit';
			$.popgSLfrm.cnTxtHelp = 412;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntactRWEdit', styles);
		},
		GntMOMsUpload: function(message, value, title, styles) {
			if( title == null ) title = 'GntMOMsUpload';
			$.popgSLfrm.cnTxtHelp = 413;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntMOMsUpload', styles);
		},
		GntParticipantAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntParticipantAdd';
			$.popgSLfrm.cnTxtHelp = 414;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntParticipantAdd', styles);
		},
		GntParticipantEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntParticipantEdit';
			$.popgSLfrm.cnTxtHelp = 415;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntParticipantEdit', styles);
		},
		GntRpsUpload: function(message, value, title, styles) {
			if( title == null ) title = 'GntRpsUpload';
			$.popgSLfrm.cnTxtHelp = 416;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRpsUpload', styles);
		},
		GntRpsGenerate: function(message, value, title, styles) {
			if( title == null ) title = 'GntRpsGenerate';
			$.popgSLfrm.cnTxtHelp = 417;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRpsGenerate', styles);
		},
		GntTaskReviewAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskReviewAdd';
			$.popgSLfrm.cnTxtHelp = 418;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntTaskReviewAdd', styles);
		},
		GntReviewParticipantAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntReviewParticipantAdd';
			$.popgSLfrm.cnTxtHelp = 419;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = true;
			$.popgSLfrm._create(title, message, value, 'GntReviewParticipantAdd', styles);
		},
		GntReviewParticipantEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntReviewParticipantEdit';
			$.popgSLfrm.cnTxtHelp = 420;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntReviewParticipantEdit', styles);
		},
		GntReviewParticipantView: function(message, value, title, styles) {
			if( title == null ) title = 'GntReviewParticipantView';
			$.popgSLfrm.cnTxtHelp = -421;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntReviewParticipantView', styles);
		},
		GntRpsCreate: function(message, value, title, styles) {
			if( title == null ) title = 'GntRpsCreate';
			$.popgSLfrm.cnTxtHelp = 422;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRpsCreate', styles);
		},
		GntParticipantView: function(message, value, title, styles) {
			if( title == null ) title = 'GntParticipantView';
			$.popgSLfrm.cnTxtHelp = -423;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntParticipantView', styles);
		},
		GntTaskIssueAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskIssueAdd';
			$.popgSLfrm.cnTxtHelp = 424;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskIssueAdd', styles);
		},
		GntTaskIssueEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskIssueEdit';
			$.popgSLfrm.cnTxtHelp = 425;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskIssueEdit', styles);
		},
		GntTaskIssueUpdt: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskIssueUpdt';
			$.popgSLfrm.cnTxtHelp = 426;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskIssueUpdt', styles);
		},
		GntIssueCommentAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntIssueCommentAdd';
			$.popgSLfrm.cnTxtHelp = 427;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntIssueCommentAdd', styles);
		},
		GntIssueCommentEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntIssueCommentEdit';
			$.popgSLfrm.cnTxtHelp = 428;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntIssueCommentEdit', styles);
		},
		GntIssueCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'GntIssueCommentView';
			$.popgSLfrm.cnTxtHelp = -429;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntIssueCommentView', styles);
		},
		GntProjectRiskAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntProjectRiskAdd';
			$.popgSLfrm.cnTxtHelp = 430;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntProjectRiskAdd', styles);
		},
		GntProjectRiskEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntProjectRiskEdit';
			$.popgSLfrm.cnTxtHelp = 431;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntProjectRiskEdit', styles);
		},
		GntTaskRiskUpdt: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskRiskUpdt';
			$.popgSLfrm.cnTxtHelp = 432;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskRiskUpdt', styles);
		},
		GntRiskCommentAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntRiskCommentAdd';
			$.popgSLfrm.cnTxtHelp = 433;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRiskCommentAdd', styles);
		},
		GntRiskCommentEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntRiskCommentEdit';
			$.popgSLfrm.cnTxtHelp = 434;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRiskCommentEdit', styles);
		},
		GntRiskCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'GntRiskCommentView';
			$.popgSLfrm.cnTxtHelp = -435;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRiskCommentView', styles);
		},
		GntProjectCRAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntProjectCRAdd';
			$.popgSLfrm.cnTxtHelp = 436;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntProjectCRAdd', styles);
		},
		GntCRUpload: function(message, value, title, styles) {
			if( title == null ) title = 'GntCRUpload';
			$.popgSLfrm.cnTxtHelp = 437;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntCRUpload', styles);
		},
		GntCRCommentAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntCRCommentAdd';
			$.popgSLfrm.cnTxtHelp = 438;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntCRCommentAdd', styles);
		},
		GntCRCommentEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntCRCommentEdit';
			$.popgSLfrm.cnTxtHelp = 439;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntCRCommentEdit', styles);
		},
		GntCRCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'GntCRCommentView';
			$.popgSLfrm.cnTxtHelp = -440;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntCRCommentView', styles);
		},
		GntProjectBDAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntProjectBDAdd';
			$.popgSLfrm.cnTxtHelp = 441;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntProjectBDAdd', styles);
		},
		GntBDUpload: function(message, value, title, styles) {
			if( title == null ) title = 'GntBDUpload';
			$.popgSLfrm.cnTxtHelp = 442;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntBDUpload', styles);
		},
		GntBDCommentAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntBDCommentAdd';
			$.popgSLfrm.cnTxtHelp = 443;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntBDCommentAdd', styles);
		},
		GntBDCommentEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntBDCommentEdit';
			$.popgSLfrm.cnTxtHelp = 444;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntBDCommentEdit', styles);
		},
		GntBDCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'GntBDCommentView';
			$.popgSLfrm.cnTxtHelp = -445;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntBDCommentView', styles);
		},
		GntTaskCRUpdt: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskCRUpdt';
			$.popgSLfrm.cnTxtHelp = 446;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskCRUpdt', styles);
		},
		GntTaskBDUpdt: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskBDUpdt';
			$.popgSLfrm.cnTxtHelp = 447;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntTaskBDUpdt', styles);
		},
		StakeGeneralEdit: function(message, value, title, styles) {
			if( title == null ) title = 'StakeGeneralEdit';
			$.popgSLfrm.cnTxtHelp = 448;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'StakeGeneralEdit', styles);
		},
		RskRegisterCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'RskRegisterCommentView';
			$.popgSLfrm.cnTxtHelp = -449;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'RskRegisterCommentView', styles);
		},
		IsuRegisterCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'IsuRegisterCommentView';
			$.popgSLfrm.cnTxtHelp = -450;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'IsuRegisterCommentView', styles);
		},
		BakWorkIssueView: function(message, value, title, styles) {
			if( title == null ) title = 'BakWorkIssueView';
			$.popgSLfrm.cnTxtHelp = -451;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'BakWorkIssueView', styles);
		},
		BakWorkIssueUpdate: function(message, value, title, styles) {
			if( title == null ) title = 'BakWorkIssueUpdate';
			$.popgSLfrm.cnTxtHelp = 452;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'BakWorkIssueUpdate', styles);
		},
		ProjCtrlView: function(message, value, title, styles) {
			if( title == null ) title = 'ProjCtrlView';
			$.popgSLfrm.cnTxtHelp = -453;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ProjCtrlView', styles);
		},
		ProjCtrlLock: function(message, value, title, styles) {
			if( title == null ) title = 'ProjCtrlLock';
			$.popgSLfrm.cnTxtHelp = 454;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ProjCtrlLock', styles);
		},
		ProjCtrlUnlock: function(message, value, title, styles) {
			if( title == null ) title = 'ProjCtrlUnlock';
			$.popgSLfrm.cnTxtHelp = 455;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ProjCtrlUnlock', styles);
		},
		ProjCtrlHistory: function(message, value, title, styles) {
			if( title == null ) title = 'ProjCtrlHistory';
			$.popgSLfrm.cnTxtHelp = 456;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ProjCtrlHistory', styles);
		},
		GntMOMEmailView: function(message, value, title, styles) {
			if( title == null ) title = 'GntMOMEmailView';
			$.popgSLfrm.cnTxtHelp = -457;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntMOMEmailView', styles);
		},
		GntRpsEmailView: function(message, value, title, styles) {
			if( title == null ) title = 'GntRpsEmailView';
			$.popgSLfrm.cnTxtHelp = -458;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRpsEmailView', styles);
		},
		GntRvwEmailView: function(message, value, title, styles) {
			if( title == null ) title = 'GntRvwEmailView';
			$.popgSLfrm.cnTxtHelp = -459;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'GntRvwEmailView', styles);
		},
		showResAvail: function(message, value, title, styles) {
			if( title == null ) title = 'showResAvail';
			$.popgSLfrm.cnTxtHelp = 460;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'showResAvail', styles);
		},
		showResActuals: function(message, value, title, styles) {
			if( title == null ) title = 'showResActuals';
			$.popgSLfrm.cnTxtHelp = 461;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'showResActuals', styles);
		},
		anzrResAlloc: function(message, value, title, styles) {
			if( title == null ) title = 'anzrResAlloc';
			$.popgSLfrm.cnTxtHelp = 462;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrResAlloc', styles);
		},
		anzrResPerform: function(message, value, title, styles) {
			if( title == null ) title = 'anzrResPerform';
			$.popgSLfrm.cnTxtHelp = 463;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrResPerform', styles);
		},
		anzrResCost: function(message, value, title, styles) {
			if( title == null ) title = 'anzrResCost';
			$.popgSLfrm.cnTxtHelp = 464;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrResCost', styles);
		},
		anzrResProjection: function(message, value, title, styles) {
			if( title == null ) title = 'anzrResProjection';
			$.popgSLfrm.cnTxtHelp = 465;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrResProjection', styles);
		},
		anzrResIssues: function(message, value, title, styles) {
			if( title == null ) title = 'anzrResIssues';
			$.popgSLfrm.cnTxtHelp = 466;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrResIssues', styles);
		},
		anzrTskSchedule: function(message, value, title, styles) {
			if( title == null ) title = 'anzrTskSchedule';
			$.popgSLfrm.cnTxtHelp = 467;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrTskSchedule', styles);
		},
		anzrTskCost: function(message, value, title, styles) {
			if( title == null ) title = 'anzrTskCost';
			$.popgSLfrm.cnTxtHelp = 468;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrTskCost', styles);
		},
		anzrTskWork: function(message, value, title, styles) {
			if( title == null ) title = 'anzrTskWork';
			$.popgSLfrm.cnTxtHelp = 469;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrTskWork', styles);
		},
		anzrTskEVMS: function(message, value, title, styles) {
			if( title == null ) title = 'anzrTskEVMS';
			$.popgSLfrm.cnTxtHelp = 470;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrTskEVMS', styles);
		},
		anzrTskBurn: function(message, value, title, styles) {
			if( title == null ) title = 'anzrTskBurn';
			$.popgSLfrm.cnTxtHelp = 471;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'anzrTskBurn', styles);
		},
		ppfResWork: function(message, value, title, styles) {
			if( title == null ) title = 'ppfResWork';
			$.popgSLfrm.cnTxtHelp = 472;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ppfResWork', styles);
		},
		ppfEfsAnz: function(message, value, title, styles) {
			if( title == null ) title = 'ppfEfsAnz';
			$.popgSLfrm.cnTxtHelp = 473;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ppfEfsAnz', styles);
		},
		ppfProductionAnz: function(message, value, title, styles) {
			if( title == null ) title = 'ppfProductionAnz';
			$.popgSLfrm.cnTxtHelp = 474;
			$.popgSLfrm.cnTxtHelpSid = true;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'ppfProductionAnz', styles);
		},
		AglPushStory: function(message, value, title, styles) {
			if( title == null ) title = 'AglPushStory';
			$.popgSLfrm.cnTxtHelp = 475;
			$.popgSLfrm.cnTxtHelpSid = false;
			$.popgSLfrm.displayMode = false;
			$.popgSLfrm._create(title, message, value, 'AglPushStory', styles);
		},
		
		
		// Private methods     
		
		_create: function(title, msg, value, type, styles) {
			if ((styles != undefined) && (styles != '')) $.popgSLfrm.styleIds = styles.split('|');
			if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
				if (($.popgSLfrm.styleIds[2] == undefined) || ($.popgSLfrm.styleIds[2] == '')) $.popgSLfrm._hide();
					else {
						$.popgSLfrm.displayMode = true;
						if ($("#gSform_container").length) {
						$("#gSform_container").remove();
						clearPopUps("SL");
						$.popgSLfrm._overlay('hide');
						$.popgSLfrm._maintainPosition(false);					
					}
				}	
				if (($.popgSLfrm.styleIds[2] == undefined) || ($.popgSLfrm.styleIds[2] == '')) {
					$("BODY").append(
					  '<div id="gSform_container" style="display: none;">' +
						'<h1 id="gSform_title"></h1>' +
						'<div id="gSform_errors" style="display: none;"><div class="error_title">ERRORS:</div></div>' +
						'<div id="gSform_content">' +
						  '<div id="gSform_message"></div>' +
						'</div>' +
					  '</div>');
				} else {
					$("BODY").append(
					  '<div id="gSform_container" style="display: none;">' +
						'<h1 id="gSform_title"></h1>' +
						'<table class="charts-table-cls-sl"  style="display:block;"><tr><td id="'+ $.popgSLfrm.styleIds[2] +'-filter" class="charts-filter-side">' +
						'<div id="'+ $.popgSLfrm.styleIds[2] +'"></div></td>' +
						'<td id="'+ $.popgSLfrm.styleIds[1] +'-canvas" class="charts-canvas-side">' +
						'<div id="'+ $.popgSLfrm.styleIds[1] +'"  class="charts-canvas-cls"></div></td></tr></table>' +
						'<div id="gSform_errors" style="display: none;"><div class="error_title">ERRORS:</div></div>' +
					  '</div>');
						$("#WA-3-canvas").css({ // WA-3 and WA-2 can be generalized if needed
								 "width": $(window).width() - $("#WA-2-filter").width() - 30 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
				}
				
				//$("BODY").css("overflow", "hidden");
				$("html, body").animate({ scrollTop: 0 }, "slow");
				
				// IE6 Fix
				var pos = ($.browser.msie && parseInt($.browser.version) <= 6 ) ? 'absolute' : 'fixed'; 
				$("#gSform_container").css({
					position: pos,
					zIndex: 4669,
					padding: 0,
					margin: 0
				});
				if ($.popgSLfrm.displayMode == false) {
					$("#gSform_content").css({
						"max-height": "360px",
						"overflow-y": "auto"
					}); 
				} else {
					if ($("#gSform_content").length) $("#gSform_content").css({
						"width": $(window).innerWidth() - 5,
						"height": $(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60,
						"overflow-y": "auto"
					}); 
				}
				$("#gSform_title").text(title).append('<div id="sl_cls_bak_bt" class="navButtonSz closeButton" style="display: none;" onclick="$.popgSLfrm._hide();">&nbsp;&nbsp;</div>')
					.append('<div id="gSform_errors_ico" class="navButtonSz errorButton" style="display: none;" onclick="$.popgSLfrm._errbox();">&nbsp;&nbsp;</div>');
				
				//if (($.popgSLfrm.styleIds[2] == undefined) || ($.popgSLfrm.styleIds[2] == '')) $("#sl_cls_bak_bt").css("margin-right","10px");
					//else $("#sl_cls_bak_bt").css("margin-right","25px");
				
				/*
					.append('<div id="sl_hlp_bt" class="navButtonSz helpButton" style="display: none;" onclick="$.popgSLfrm._help();">&nbsp;&nbsp;</div>')
					.append('<div id="sl_bak_hom_bt" class="navButtonSz homeButton" style="display: none;" onclick="$.popgSLfrm._home();">&nbsp;&nbsp;</div>')
					
					
				*/
					
				if ($("#gSform_content").length) {	
					$("#gSform_message").text(''); // msg
					$("#gSform_message").html( $("#gSform_message").text().replace(/\n/g, '<br />') );
				}
				if ($.popgSLfrm.displayMode == false) {
					$("#gSform_container").css({
						minWidth: $("#gSform_container").outerWidth(),
						maxWidth: $("#gSform_container").outerWidth()
					});
				} else {
					$("#gSform_container").css({
						width: $(window).innerWidth() - 5,
						height: $(window).innerHeight() - $('.fix_header_class').outerHeight( true ) 
					});
				}
				$.popgSLfrm._reposition();
				$.popgSLfrm._maintainPosition(true);
				
				if ($.popgSLfrm.displayMode == false) {
					$("#gSform_container").css({
						 "min-width": "750px", 
					});
				} else {
					$("#gSform_container").css({
						"min-width": '99.8%' //$(window).innerWidth() - 4 
					});					
				}
			} 
			popup_stack.push('SL');
			popup_help.push($.popgSLfrm.cnTxtHelp);
			if ($.popgSLfrm.cnTxtHelp <= 0) $("#brd_help").css("display","none");
				else $("#brd_help").css("display","inline");

			switch( type ) {
				case 'GntTaskFCAdd': {
					$("#gSform_message").append('<input type="text"  id="fc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#gSform_division").load("Gantt_Masters.html #TaskFCAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskFCAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#fc-entity-id-edit').val();
						dynsubmitTaskFCAdd(val); 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskFCEdit': {
					$("#gSform_message").append('<input type="text"  id="fc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#gSform_division").load("Gantt_Masters.html #TaskFCEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskFCEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#fc-entity-id-edit').val();
						dynsubmitTaskFCEdit(val); 
					});
					$("#gSform_del").click( function() {
						var val = $('#fc-entity-id-edit').val();
						dynsubmitTaskFCDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskPredAdd': {
					$("#gSform_message").append('<input type="text"  id="pc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#gSform_division").load("Gantt_Masters.html #TaskPredAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskPredecessorAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#pc-entity-id-edit').val();
						dynsubmitTaskPredAdd(val); 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				} 	
				case 'GntTaskPredEdit': {
					$("#gSform_message").append('<input type="text"  id="pc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgSLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/> <input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#gSform_division").load("Gantt_Masters.html #TaskPredEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskPredecessorEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#pc-entity-id-edit').val();
						dynsubmitTaskPredEdit(val); 
					});
					$("#gSform_del").click( function() {
						var val = $('#pc-entity-id-edit').val();
						dynsubmitTaskPredDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntSaveAs': {
					$("#gSform_message").append('<input type="text"  id="gntwbs-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#gSform_division").load("Gantt_Masters.html #ProjectToWBS", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.ganttControl.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.ganttControl.js' )
												.done(function( script, textStatus ) {
													ganttController();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntwbs-entity-id-edit').val();
						//alert('clicked');
						submitGanttWBSSave(val); 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntBaseline': {
					$("#gSform_message").append('<input type="text"  id="gntbase-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#gSform_division").load("Gantt_Masters.html #ProjectBaseline", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.ganttControl.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.ganttControl.js' )
												.done(function( script, textStatus ) {
													ganttController();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ShwResRate': {
					$("#gSform_message").append('<input type="text"  id="gntrshw-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#ShowResourceRate").remove();
										$("#gSform_division").load("Gantt_Masters.html #ShowResourceRate", function(responseText, statusText, xhr) {
											$.popgSLfrm._show();
											$.ajax({
												url: "phpGanttLoad.php",
												type: 'POST',
												data: {"page": "gantt-ShwResRate", "project-id": $('#gantt-select-devp').val(), "res-id": parseInt(value)},
												timeout: xhr_timeout,
												error: function () {
													hide_all_errors();
													hide_upload_started();
													jAlert('Could not connect to server...','T');
												},
												success: function(response) {
													//alert(response);  //MSD
													response = $.parseJSON(response); 
													hide_all_errors();
													$("#gntResName-show").val(response[0]["resName"]);
													$("#gntResRole-show").val(response[0]["resRole"]);
													$("#gntResRate-show").val(response[0]["resRate"]);
													$("#gntResOTR-show").val(response[0]["resOTR"]);
													hide_upload_started();
												}
											});
											
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntDelivUpload': {
					$("#gSform_message").append('<input type="text"  id="gntdelivupld-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#UpdateTaskDocsAdd").remove();
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskDocsAdd", function(responseText, statusText, xhr) {
											hide_upload_started();	
											$.popgSLfrm._show();
											var NodeInfo = getNodeInfo(value);
											if ((prjAgility == 1) && (bakLogShow == 1)) $('#gntNode-tskName-show').val('(ID: '+getOrigLink(value)+') '+getNodeName(value));
												else $('#gntNode-tskName-show').val('(Task: '+getOrigLink(value)+') '+getNodeName(value));
											$('#tskdelivToUpload').MultiFile({ 
													list: '#tskdelivUploadList',
													max: 5,
													accept: deliv_extns,  
													STRING: {
														remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
													}
											});
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntdelivupld-entity-id-edit').val();
						//alert('clicked');
						
						if ($('a.MultiFile-remove','#tskdelivUploadList').length > 0) {
							var page_url = "tskdeliverable-file";
							if ((prjAgility == 1) && (bakLogShow == 1)) page_url = "story-file";
							$('#tskdelivUploadData').append('<input type="text"  id="tskdeliv-entity-elf" name="element" value='+ page_url +' style="display:none"/>');
							$('#tskdelivUploadData').append('<input type="text"  id="tskdeliv-entityf" name="page" value="tskdelivToUpload" style="display:none"/>');
							$('#tskdelivUploadData').append('<input type="text"  id="tskdeliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+value+'"/>'); 
							$('#btntskUploadDeliv').trigger('click'); 
							if ((prjAgility == 1) && (bakLogShow == 1)) {
								jAlert('Document uploaded successfully. ','S', function() {
										$.popgSLfrm._hide();
										$("#flex-sty-documents").flexReload();
								});
							} else {
								jAlert('Deliverable uploaded successfully. ','S', function() {
										$.popgSLfrm._hide();
										$("#flex-tsk-documents").flexReload();
								});
							}
						} else {
							jAlert('Deliverable not added to list... ','E', function() {
									return;
							});
						}
						 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntactFCAdd': {
					$("#gSform_message").append('<input type="text"  id="gntactFCadd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskActFCAdd").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskActFCAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskActFCAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntactFCadd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskActFCAdd(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntactFCEdit': {
					$("#gSform_message").append('<input type="text"  id="gntactFCedit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskActFCEdit").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskActFCEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskActFCEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntactFCedit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskActFCEdit(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#gntactFCedit-entity-id-edit').val();
						dynsubmitTskActFCDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntactRWAdd': {
					$("#gSform_message").append('<input type="text"  id="GntactRWAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskActResWorkAdd").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskActResWorkAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskActRWAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntactRWAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskActRWAdd(val); // function in gntUpdt_Forms.js
					});
				/*	$("#gSform_del").click( function() {
						var val = $('#GntactRWAdd-entity-id-edit').val();
						dynsubmitTskActRWDel(val);
					}); */
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				
				case 'GntactRWEdit': {
					$("#gSform_message").append('<input type="text"  id="GntactRWEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskActResWorkEdit").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskActResWorkEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskActRWEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntactRWEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskActRWEdit(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntactRWEdit-entity-id-edit').val();
						dynsubmitTskActRWDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntMOMsUpload': {
					$("#gSform_message").append('<input type="text"  id="gntMoMsupld-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#UpdateTaskMoMsAdd").remove();
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskMoMsAdd", function(responseText, statusText, xhr) {
											hide_upload_started();	
											$.popgSLfrm._show();
											var NodeInfo = getNodeInfo(value);
											$('#gntNode-tskName-show').val('(Task: '+getOrigLink(value)+') '+getNodeName(value));


											$('#tskMoMsToUpload').MultiFile({ 
													list: '#tskMoMsUploadList',
													max: 5,
													accept: deliv_extns,  
													STRING: {
														remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
													}
											});


										
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntMoMsupld-entity-id-edit').val();
						//alert('clicked');
						if ($('a.MultiFile-remove','#tskMoMsUploadList').length > 0) {
						//alert('Succ');
							$('#tskMoMsUploadData').append('<input type="text"  id="tskMoMs-entity-elf" name="element" value="tskMoMs-file" style="display:none"/>');
							$('#tskMoMsUploadData').append('<input type="text"  id="tskMoMs-entityf" name="page" value="tskMoMsToUpload" style="display:none"/>');
							$('#tskMoMsUploadData').append('<input type="text"  id="tskMoMs-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+value+'"/>'); 
							$('#btntskUploadMoMs').trigger('click'); 
							jAlert('MOM Documents uploaded successfully. ','S', function() {
									$.popgSLfrm._hide();
									$("#flex-tsk-minutes").flexReload();
							});
						} else {
							jAlert('MOM Documents not added to list... ','E', function() {
									return;
							});
						} 
						 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntParticipantAdd': {
					$("#gSform_message").append('<input type="text"  id="GntParticipantAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskMeetingParticipantAdd").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingParticipantAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskMeetPartAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntParticipantAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitMeetPartAdd(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntParticipantEdit': {
					$("#gSform_message").append('<input type="text"  id="GntParticipantEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskMeetingParticipantEdit").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingParticipantEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskMeetPartEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntParticipantEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskMEPartEdit(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntParticipantEdit-entity-id-edit').val();
						dynsubmitTskMEPartDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRpsUpload': {
					$("#gSform_message").append('<input type="text"  id="gntRpsupld-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#UpdateTaskRpsAdd").remove();
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskRpsAdd", function(responseText, statusText, xhr) {
											hide_upload_started();	
											$.popgSLfrm._show();
											var NodeInfo = getNodeInfo(value);
											$('#gntNode-tskName-show').val('(Task: '+getOrigLink(value)+') '+getNodeName(value));


											$('#tskRpsToUpload').MultiFile({ 
													list: '#tskRpsUploadList',
													max: 5,
													accept: deliv_extns,  
													STRING: {
														remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
													}
											});


										
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#gntRpsupld-entity-id-edit').val();
						//alert('clicked');
						if ($('a.MultiFile-remove','#tskRpsUploadList').length > 0) {
						//alert('Succ');
							$('#tskRpsUploadData').append('<input type="text"  id="tskRps-entity-elf" name="element" value="tskRps-file" style="display:none"/>');
							$('#tskRpsUploadData').append('<input type="text"  id="tskRps-entityf" name="page" value="tskRpsToUpload" style="display:none"/>');
							$('#tskRpsUploadData').append('<input type="text"  id="tskRps-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+value+'"/>'); 
							$('#btntskUploadRps').trigger('click'); 
							jAlert('Reports Documents uploaded successfully. ','S', function() {
									$.popgSLfrm._hide();
									$("#flex-tsk-progressReports").flexReload();
							});
						} else {
							jAlert('Reports Documents not added to list... ','E', function() {
									return;
							});
						} 
						 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRpsGenerate': {
					$("#gSform_message").append('<input type="text"  id="GntRpsGenerate-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Generate" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskRpsGenerate").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskRpsGenerate", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReportGenerate();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntRpsGenerate-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskReportGenerate(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskReviewAdd': {
					$("#gSform_message").append('<input type="text"  id="GntTaskReviewAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskReviewAdd").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskReviewAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReviewAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#UpdateTaskReviewAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTaskReviewAdd(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntReviewParticipantAdd': {
					$("#gSform_message").append('<input type="text"  id="GntReviewParticipantAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskMeetingParticipantAdd").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingParticipantAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntInter_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntInter_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReviewPartAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntInter_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntReviewParticipantAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitReviewPartAdd(val); // function in gntInter_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				
				case 'GntReviewParticipantEdit': {
					$("#gSform_message").append('<input type="text"  id="GntReviewParticipantEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskMeetingParticipantEdit").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingParticipantEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntInter_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntInter_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReviewPartEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntInter_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntReviewParticipantEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitReviewPartEdit(val); // function in gntInter_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntReviewParticipantEdit-entity-id-edit').val();
						dynsubmitReviewPartDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntReviewParticipantView': {
					$("#gSform_message").append('<input type="text"  id="GntReviewParticipantView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#TaskMeetingParticipantView").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingParticipantView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntInter_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntInter_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReviewPartView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntInter_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRpsCreate': {
					$("#gSform_message").append('<input type="text"  id="GntRpsCreate-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Generate" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskRpsCreate").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskRpsCreate", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskReportCreate();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntRpsCreate-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTskReportCreate(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntParticipantView': {
					$("#gSform_message").append('<input type="text"  id="GntParticipantView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#TaskMeetingPartView").remove(); // HTML Shared with Edit section
										$("#gSform_division").load("Gantt_Masters.html #TaskMeetingPartView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskMeetPartView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskIssueAdd': {
					$("#gSform_message").append('<input type="text"  id="GntTaskIssueAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskIssueAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskIssueAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskIsu-lbl").text("Story Title:");
														$("#gnt-name-tskIsu-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popBacklogIssueAdd();
													} else {
														$("#gnt-add-tskIsu-lbl").text("Task Name:");
														$("#gnt-name-tskIsu-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popTaskIssueAdd();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskIssueAdd-entity-id-edit').val();
						//alert('clicked');
						if ((prjAgility == 1) && (bakLogShow == 1)) dynsubmitBacklogIssueAdd(val); // function in gntView_Forms.js
							else dynsubmitTaskIssueAdd(val); 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskIssueEdit': {
					$("#gSform_message").append('<input type="text"  id="GntTaskIssueEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskIssueEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskIssueEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskIsu-lbl").text("Story Title:");
														$("#gnt-name-tskIsu-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popBacklogIssueEdit();
													} else {
														$("#gnt-add-tskIsu-lbl").text("Task Name:");
														$("#gnt-name-tskIsu-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popTaskIssueEdit();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskIssueEdit-entity-id-edit').val();
						//alert('clicked');
						if ((prjAgility == 1) && (bakLogShow == 1)) dynsubmitBacklogIssueEdit(val); // function in gntView_Forms.js
							else dynsubmitTaskIssueEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntTaskIssueEdit-entity-id-edit').val();
						if ((prjAgility == 1) && (bakLogShow == 1)) dynsubmitBacklogIssueDel(val); // function in gntView_Forms.js
							else dynsubmitTaskIssueDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}
				case 'GntTaskIssueUpdt': {
					$("#gSform_message").append('<input type="text"  id="GntTaskIssueUpdt-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="Purge" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskIssueUpdt").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskIssueUpdt", function(responseText, statusText, xhr) {
											$('#gSform_sav, #gSform_del').attr("disabled","disabled").css("display", "none");
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskIsu-lbl").text("Story Title:");
														$("#gnt-name-tskIsu-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														$("#gnt-chg-tskIsu-lbl").text("Change to Story:");
														$("#gnt-cat-tskIsu-lbl").text("Challenge Category:").append('<span style="color: #cd1800;">&#42;</span>');
														$("#gnt-sts-tskIsu-lbl").text("Challenge Status:").append('<span style="color: #cd1800;">&#42;</span>');
														popBacklogIssueUpdate();
													} else {
														$("#gnt-add-tskIsu-lbl").text("Task Name:");
														$("#gnt-name-tskIsu-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														$("#gnt-chg-tskIsu-lbl").text("Change to Task:");
														$("#gnt-cat-tskIsu-lbl").text("Issue Category:").append('<span style="color: #cd1800;">&#42;</span>');
														$("#gnt-sts-tskIsu-lbl").text("Issue Status:").append('<span style="color: #cd1800;">&#42;</span>');
														popTaskIssueUpdate();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskIssueUpdt-entity-id-edit').val();
						//alert('clicked');
						dynsubmitTaskIssueUpdt(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntTaskIssueUpdt-entity-id-edit').val();
						//alert('P');
						dynsubmitTaskIssuePurg(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateTaskIssueUpdt").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntIssueCommentAdd': {
					$("#gSform_message").append('<input type="text"  id="GntIssueCommentAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateIssueCommentAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateIssueCommentAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskCom-lbl").text("Story Title:");
														$("#gnt-name-tskCom-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentAdd();
													} else {
														$("#gnt-add-tskCom-lbl").text("Task Name:");
														$("#gnt-name-tskCom-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentAdd();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntIssueCommentAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitIssueCommentAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntIssueCommentEdit': {
					$("#gSform_message").append('<input type="text"  id="GntIssueCommentEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateIssueCommentEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateIssueCommentEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskCom-lbl").text("Story Title:");
														$("#gnt-name-tskCom-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentEdit();
													} else {
														$("#gnt-add-tskCom-lbl").text("Task Name:");
														$("#gnt-name-tskCom-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentEdit();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntIssueCommentEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitIssueCommentEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntIssueCommentEdit-entity-id-edit').val();
						dynsubmitIssueCommentDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateIssueCommentEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntIssueCommentView': {
					$("#gSform_message").append('<input type="text"  id="GntIssueCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateIssueCommentView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateIssueCommentView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskCom-lbl").text("Story Title:");
														$("#gnt-name-tskCom-lbl").text("Challenge Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentView();
													} else {
														$("#gnt-add-tskCom-lbl").text("Task Name:");
														$("#gnt-name-tskCom-lbl").text("Issue Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popIssueCommentView();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateIssueCommentView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntProjectRiskAdd': {
					$("#gSform_message").append('<input type="text"  id="GntProjectRiskAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateProjectRiskAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateProjectRiskAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popProjectRiskAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntProjectRiskAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectRiskAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateProjectRiskAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntProjectRiskEdit': {
					$("#gSform_message").append('<input type="text"  id="GntProjectRiskEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateProjectRiskEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateProjectRiskEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popProjectRiskEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntProjectRiskEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectRiskEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntProjectRiskEdit-entity-id-edit').val();
						dynsubmitProjectRiskDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateProjectRiskEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskRiskUpdt': {
					$("#gSform_message").append('<input type="text"  id="GntTaskRiskUpdt-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="Purge" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskRiskUpdt").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskRiskUpdt", function(responseText, statusText, xhr) {
											$('#gSform_sav, #gSform_del').attr("disabled","disabled").css("display", "none");
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskRiskUpdate();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskRiskUpdt-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectRiskUpdt(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntTaskRiskUpdt-entity-id-edit').val();
						dynsubmitProjectRiskPurg(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateTaskRiskUpdt").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRiskCommentAdd': {
					$("#gSform_message").append('<input type="text"  id="GntRiskCommentAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateRiskCommentAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateRiskCommentAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popRiskCommentAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntRiskCommentAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitRiskCommentAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateRiskCommentAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRiskCommentEdit': {
					$("#gSform_message").append('<input type="text"  id="GntRiskCommentEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateRiskCommentEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateRiskCommentEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popRiskCommentEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntRiskCommentEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitRiskCommentEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntRiskCommentEdit-entity-id-edit').val();
						dynsubmitRiskCommentDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateRiskCommentEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRiskCommentView': {
					$("#gSform_message").append('<input type="text"  id="GntRiskCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateRiskCommentView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateRiskCommentView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popRiskCommentView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateRiskCommentView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntProjectCRAdd': {
					$("#gSform_message").append('<input type="text"  id="GntProjectCRAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateProjectCRAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateProjectCRAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskCR-lbl").text("Story Title:");
														$("#gnt-name-tskCR-lbl").text("Grooming Tip Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popBacklogCRAdd();
													} else {
														$("#gnt-add-tskCR-lbl").text("Task Name:");
														$("#gnt-name-tskCR-lbl").text("Change Request Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popProjectCRAdd();
													}	
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntProjectCRAdd-entity-id-edit').val();
						//alert('clicked');
						if ((prjAgility == 1) && (bakLogShow == 1)) dynsubmitBacklogCRAdd(val); // function in gntView_Forms.js
							else dynsubmitProjectCRAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateProjectCRAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntCRUpload': {
					$("#gSform_message").append('<input type="text"  id="GntCRUpload-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#UpdateCRDocsAdd").remove();
										$("#gSform_division").load("Gantt_Masters.html #UpdateCRDocsAdd", function(responseText, statusText, xhr) {
											hide_upload_started();	
											$.popgSLfrm._show();
											var NodeInfo = getNodeInfo(value); 
											$('#gntNode-CRName-show').val('(Ticket: '+value+') '+$('#gnt-tskCR-name').val());

											$('#tskCRToUpload').MultiFile({ 
												list: '#tskCRUploadList',
												max: 5,
												accept: deliv_extns,  
												STRING: {
													remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
												}
											}); 


										
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntCRUpload-entity-id-edit').val();
						//alert(value);
						if ($('a.MultiFile-remove','#tskCRUploadList').length > 0) {
						//alert('Succ');
							var page_identity = "crs-file";
							if ((prjAgility == 1) && (bakLogShow == 1)) page_identity = "gts-file";
							$('#tskCRUploadData').append('<input type="text"  id="crs-entity-elf" name="element" value='+ page_identity +' style="display:none"/>');
							$('#tskCRUploadData').append('<input type="text"  id="crs-entityf" name="page" value="tskCRToUpload" style="display:none"/>');
							$('#tskCRUploadData').append('<input type="text"  id="crs-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+value+'"/>'); 
							$('#btntskUploadCR').trigger('click'); 	
							jAlert('Document(s) uploaded successfully. ','S', function() {
									$.popgSLfrm._hide();
									$("#UpdateCRDocsAdd").remove();
									jQuery("#flex-tsk-CRdocuments, #flex-tsk-crs").flexReload();
							});
						} else {
							jAlert('Documents not added to list... ','E', function() {
									return;
							});
						}
						 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateCRDocsAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntTaskCRUpdt': {
					$("#gSform_message").append('<input type="text"  id="GntTaskCRUpdt-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="Purge" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskCRUpdt").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskCRUpdt", function(responseText, statusText, xhr) {
											$('#gSform_sav, #gSform_del').attr("disabled","disabled").css("display", "none");
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-tskCR-lbl").text("Story Title:");
														$("#gnt-name-tskCR-lbl").text("Grooming Tip Title:");
														$("#gnt-chg-tskCR-lbl").text("Change to Story:");
														$("#gnt-sts-tskCR-lbl").text("Grooming Tip Status:").append('<span style="color: #cd1800;">&#42;</span>');
														popBacklogGTUpdate();
													} else {
														$("#gnt-add-tskCR-lbl").text("Task Name:");
														$("#gnt-name-tskCR-lbl").text("Change Request Title:");
														$("#gnt-chg-tskCR-lbl").text("Change to Task:");
														$("#gnt-sts-tskCR-lbl").text("Change Request Status:").append('<span style="color: #cd1800;">&#42;</span>');
														popTaskCRUpdate();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskCRUpdt-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectCRUpdt(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntTaskCRUpdt-entity-id-edit').val();
						dynsubmitProjectCRPurg(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateTaskCRUpdt").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntCRCommentAdd': {
					$("#gSform_message").append('<input type="text"  id="GntCRCommentAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateCRCommentAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateCRCommentAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-CRCom-lbl").text("Story Title:");
														$("#gnt-name-CRCom-lbl").text("Grooming Tip Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentAdd();
													} else {
														$("#gnt-add-CRCom-lbl").text("Task Name:");
														$("#gnt-name-CRCom-lbl").text("Change Request Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentAdd();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntCRCommentAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitCRCommentAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateCRCommentAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntCRCommentEdit': {
					$("#gSform_message").append('<input type="text"  id="GntCRCommentEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateCRCommentEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateCRCommentEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-CRCom-lbl").text("Story Title:");
														$("#gnt-name-CRCom-lbl").text("Grooming Tip Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentEdit();
													} else {
														$("#gnt-add-CRCom-lbl").text("Task Name:");
														$("#gnt-name-CRCom-lbl").text("Change Request Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentEdit();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntCRCommentEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitCRCommentEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntCRCommentEdit-entity-id-edit').val();
						dynsubmitCRCommentDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateCRCommentEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntCRCommentView': {
					$("#gSform_message").append('<input type="text"  id="GntCRCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateCRCommentView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateCRCommentView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													if ((prjAgility == 1) && (bakLogShow == 1)) {
														$("#gnt-add-CRCom-lbl").text("Story Title:");
														$("#gnt-name-CRCom-lbl").text("Grooming Tip Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentView();
													} else {
														$("#gnt-add-CRCom-lbl").text("Task Name:");
														$("#gnt-name-CRCom-lbl").text("Change Request Title:").append('<span style="color: #cd1800;">&#42;</span>');
														popCRCommentView();
													}
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateCRCommentView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntProjectBDAdd': {
					$("#gSform_message").append('<input type="text"  id="GntProjectBDAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateProjectBDAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateProjectBDAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popProjectBDAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntProjectBDAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectBDAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateProjectBDAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntBDUpload': {
					$("#gSform_message").append('<input type="text"  id="GntBDUpload-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#UpdateBDDocsAdd").remove();
										$("#gSform_division").load("Gantt_Masters.html #UpdateBDDocsAdd", function(responseText, statusText, xhr) {
											hide_upload_started();
											$.popgSLfrm._show();
											var NodeInfo = getNodeInfo(value); 
											$('#gntNode-BDName-show').val('(Ticket: '+value+') '+$('#gnt-tskBD-name').val());

											$('#tskBDToUpload').MultiFile({ 
												list: '#tskBDUploadList',
												max: 5,
												accept: deliv_extns,  
												STRING: {
													remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
												}
											}); 


										
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.ganttControl.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntBDUpload-entity-id-edit').val();
						//alert(value);
						if ($('a.MultiFile-remove','#tskBDUploadList').length > 0) {
						//alert('Succ');
							$('#tskBDUploadData').append('<input type="text"  id="bds-entity-elf" name="element" value="bds-file" style="display:none"/>');
							$('#tskBDUploadData').append('<input type="text"  id="bds-entityf" name="page" value="tskBDToUpload" style="display:none"/>');
							$('#tskBDUploadData').append('<input type="text"  id="bds-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+value+'"/>'); 
							$('#btntskUploadBD').trigger('click'); 	
							jAlert('Document(s) uploaded successfully. ','S', function() {
									$.popgSLfrm._hide();
									$("#UpdateBDDocsAdd").remove();
									jQuery("#flex-tsk-BDdocuments, #flex-tsk-bugs").flexReload();
							});
						} else {
							jAlert('Documents not added to list... ','E', function() {
									return;
							});
						}
						 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateBDDocsAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}
				case 'GntTaskBDUpdt': {
					$("#gSform_message").append('<input type="text"  id="GntTaskBDUpdt-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="Purge" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateTaskBDUpdt").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateTaskBDUpdt", function(responseText, statusText, xhr) {
											$('#gSform_sav, #gSform_del').attr("disabled","disabled").css("display", "none");
											exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntUpdt_Forms.js' )
												.done(function( script, textStatus ) {
													popTaskBDUpdate();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntUpdt_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntTaskBDUpdt-entity-id-edit').val();
						//alert('clicked');
						dynsubmitProjectBDUpdt(val); // function in gntUpdt_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntTaskBDUpdt-entity-id-edit').val();
						dynsubmitProjectBDPurg(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateTaskBDUpdt").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntBDCommentAdd': {
					$("#gSform_message").append('<input type="text"  id="GntBDCommentAdd-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateBDCommentAdd").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateBDCommentAdd", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popBDCommentAdd();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntBDCommentAdd-entity-id-edit').val();
						//alert('clicked');
						dynsubmitBDCommentAdd(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateBDCommentAdd").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntBDCommentEdit': {
					$("#gSform_message").append('<input type="text"  id="GntBDCommentEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gSform_del"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										
										$("#UpdateBDCommentEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateBDCommentEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popBDCommentEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#GntBDCommentEdit-entity-id-edit').val();
						//alert('clicked');
						dynsubmitBDCommentEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_del").click( function() {
						var val = $('#GntBDCommentEdit-entity-id-edit').val();
						dynsubmitBDCommentDel(val);
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateBDCommentEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntBDCommentView': {
					$("#gSform_message").append('<input type="text"  id="GntBDCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#UpdateBDCommentView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #UpdateBDCommentView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntView_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntView_Forms.js' )
												.done(function( script, textStatus ) {
													popBDCommentView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntView_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#UpdateBDCommentView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'StakeGeneralEdit': {
					$("#gSform_message").append('<input type="text"  id="StakeGeneralEdit-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#GeneralStakeholderEdit").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Business_Masters.html #GeneralStakeholderEdit", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popGeneralStakeholderEdit();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#StakeGeneralEdit-entity-id-edit').val();
						//alert('clicked');
						dynGeneralStakeholderEdit(val); // function in gntView_Forms.js
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#GeneralStakeholderEdit").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'RskRegisterCommentView': {
					$("#gSform_message").append('<input type="text"  id="RskRegisterCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#RskRegCommentsView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #RskRegCommentsView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popRskRegCommentsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#RskRegCommentsView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'IsuRegisterCommentView': {
					$("#gSform_message").append('<input type="text"  id="IsuRegisterCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#IsuRegCommentsView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #IsuRegCommentsView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popIsuRegCommentsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#IsuRegCommentsView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'BakWorkIssueView': {
					$("#gSform_message").append('<input type="text"  id="BakWorkIssueView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#BacklogWorkIssueView").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #BacklogWorkIssueView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popBaklogWrkIsueView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#BacklogWorkIssueView").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'BakWorkIssueUpdate': {
					$("#gSform_message").append('<input type="text"  id="BakWorkIssueUpdate-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="' + $.popgSLfrm.savButton + '" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										
										$("#BacklogWorkIssueUpdate").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #BacklogWorkIssueUpdate", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popBaklogWrkIsueUpdate();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#BakWorkIssueUpdate-entity-id-edit').val();
						//alert('clicked');
						dynWorkIssueUpdate(val); 
					});
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#BacklogWorkIssueUpdate").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ProjCtrlView': {
					$("#gSform_message").append('<input type="text"  id="ProjCtrlView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="ProjCtrlView-action" name="field-edit" style="display:none" value="View"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#ProjectController").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Project_Masters.html #ProjectController", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popProjContrller();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#ProjectController").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ProjCtrlLock': {
					$("#gSform_message").append('<input type="text"  id="ProjCtrlLock-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="ProjCtrlView-action" name="field-edit" style="display:none" value="Lock"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Lock" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#ProjectController").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Project_Masters.html #ProjectController", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popProjContrller();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#ProjCtrlLock-entity-id-edit').val();
						ctrlUserProject(val,'Lock'); 
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#ProjectController").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ProjCtrlUnlock': {
					$("#gSform_message").append('<input type="text"  id="ProjCtrlUnlock-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="ProjCtrlView-action" name="field-edit" style="display:none" value="Unlock"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Unlock" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#ProjectController").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Project_Masters.html #ProjectController", function(responseText, statusText, xhr) {
											$('#ProjectController').css("display","none");
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popProjContrller();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#ProjCtrlUnlock-entity-id-edit').val();
						ctrlUserProject(val,'Unlock'); 
					}); 
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#ProjectController").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ProjCtrlHistory': {
					$("#gSform_message").append('<input type="text"  id="ProjCtrlHistory-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#ProjectCtrlHistory").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Project_Masters.html #ProjectCtrlHistory", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popProjectCtrlHistory();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#ProjectCtrlHistory").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntMOMEmailView': {
					$("#gSform_message").append('<input type="text"  id="GntMOMEmailView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="entity-type" name="entity-type" style="display:none" value="MoM"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#SendEmailsViewer").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #SendEmailsViewer", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popSendEmailViewer();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#SendEmailsViewer").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRpsEmailView': {
					$("#gSform_message").append('<input type="text"  id="GntRpsEmailView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="entity-type" name="entity-type" style="display:none" value="Rps"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#SendEmailsViewer").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #SendEmailsViewer", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popSendEmailViewer();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#SendEmailsViewer").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'GntRvwEmailView': {
					$("#gSform_message").append('<input type="text"  id="GntRvwEmailView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="entity-type" name="entity-type" style="display:none" value="Rvw"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="OK" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#SendEmailsViewer").remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("Gantt_Masters.html #SendEmailsViewer", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popSendEmailViewer();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_cancel").click( function() {
						hide_all_errors();
						$("#SendEmailsViewer").remove();
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'showResAvail': {
					var filterContentHtml = "ResChartFiler";
					if (($.popgSLfrm.styleIds[2] == undefined) || ($.popgSLfrm.styleIds[2] == '')) {
						$("#gSform_message").append('<input type="text"  id="showResAvail-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="chart-select" name="chart-select" style="display:none" value="Usage"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						
						filterContentHtml = "ResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[2]).append('<input type="text"  id="showResAvail-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[2]).append('<input type="text"  id="chart-select" name="chart-select" style="display:none" value="Usage"/>');
						$("#"+$.popgSLfrm.styleIds[2]).append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						$("#gSform_panel").css({
								 "z-index": parseInt($("#gSform_container").css("z-index"))+40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 60,
								 "left": 0
							});	
					}
					
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											load_script("css/jquery.ganttDisplay.css", "css");
											exclude_script('js/jquery.ganttDisplay.js', "js");
											hide_upload_started();
											
											$.when(
												$.getScript( 'js/jquery.services.js' ),
												$.getScript( 'js/jquery.ganttDisplay.js' ),
												$.Deferred(function( deferred ){
													$( deferred.resolve );
												})
											)
											.done(function(){
												popResAvailability();
											})
											.fail(function( jqxhr, settings, exception ) {
												jAlert('Could not load script !', 'E');
											}); 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
												exclude_script('js/jquery.ganttDisplay.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#showResAvail-entity-id-edit').val();
						showResAvailabilityChart(val,$.popgSLfrm.styleIds[1]); 
					}); 
					$("#gSform_cancel").click( function() {
						$("#ResChartFiler").remove();
						serIndx_actuals = undefined;
						pntIndx_actuals = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'showResActuals': {
					var filterContentHtml = "ResChartFiler";
					if (($.popgSLfrm.styleIds[2] == undefined) || ($.popgSLfrm.styleIds[2] == '')) {
						$("#gSform_message").append('<input type="text"  id="showResActuals-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="chart-select" name="chart-select" style="display:none" value="Actuals"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						
						filterContentHtml = "ResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[2]).append('<input type="text"  id="showResActuals-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[2]).append('<input type="text"  id="chart-select" name="chart-select" style="display:none" value="Actuals"/>');
						$("#"+$.popgSLfrm.styleIds[2]).append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						$("#gSform_panel").css({
								 "z-index": parseInt($("#gSform_container").css("z-index"))+40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});	
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											exclude_script('js/jquery.services.js', "js");
											load_script("css/jquery.ganttDisplay.css", "css");
											exclude_script('js/jquery.ganttDisplay.js', "js");
											hide_upload_started();	
											
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													$.getScript( 'js/jquery.ganttDisplay.js' )
														.done(function( script, textStatus ) {
															popResAvailability();
														})
														.fail(function( jqxhr, settings, exception ) {
															jAlert('Could not load script !', 'E');
														});	 
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
												exclude_script('js/jquery.ganttDisplay.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#showResActuals-entity-id-edit').val();
						showResActualsChart(val,$.popgSLfrm.styleIds[1]); 
					}); 
					$("#gSform_cancel").click( function() {
						$("#ResChartFiler").remove();
						serIndx_actuals = undefined;
						pntIndx_actuals = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrResAlloc': {
					var filterContentHtml = "AnzrResChartFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrResAlloc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Usage"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />');					
						
					} else {
						filterContentHtml = "AnzrResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrResAlloc-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Usage"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#AnzrDateInp").css("display", "block");
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrResAlloc-entity-id-edit').val();
						var resr_id = $('#projkt_resource').val();
						showResAvailabilityChart(resr_id+','+val,$.popgSLfrm.styleIds[1]); 
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrResChartFiler").remove();
						serIndx_actuals = undefined;
						pntIndx_actuals = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrResPerform': {
					var filterContentHtml = "AnzrResChartFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrResPerform-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Actuals"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrResPerform-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Actuals"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#AnzrDateInp").css("display", "block");
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrResPerform-entity-id-edit').val();
						var resr_id = $('#projkt_resource').val();
						showResActualsChart(resr_id+','+val,$.popgSLfrm.styleIds[1]); 
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrResChartFiler").remove();
						serIndx_actuals = undefined;
						pntIndx_actuals = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrResCost': {
					var filterContentHtml = "AnzrResChartFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrResCost-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Cost"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrResCost-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Cost"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#AnzrDateInp").css("display", "block");
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrResCost-entity-id-edit').val();
						var resr_id = $('#projkt_resource').val();
						showResCostChart(resr_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrResChartFiler").remove();
						serIndx_actuals = undefined;
						pntIndx_actuals = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrResProjection': {
					var filterContentHtml = "AnzrResChartFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrResProjection-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Projections"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrResProjection-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Projections"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrResProjection-entity-id-edit').val();
						var resr_id = $('#projkt_resource').val();
						showResProjtsChart(resr_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrResChartFiler").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serIndx_cost = undefined;
						pntIndx_cost = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrResIssues': {
					var filterContentHtml = "AnzrResChartFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrResIssues-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Issues"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrResChartFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrResIssues-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="Issues"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrResIssues-entity-id-edit').val();
						var resr_id = $('#projkt_resource').val();
						showResIssuesChart(resr_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrResChartFiler").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serIndx_cost = undefined;
						pntIndx_cost = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrTskSchedule': {
					var filterContentHtml = "AnzrTaskChartFilter";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrTskSchedule-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskSchedule"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrTaskChartFilter-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrTskSchedule-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskSchedule"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											//include_script('js/jquery.services.js', "js"); 
											load_script("css/jquery.ganttDisplay.css", "css");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrTaskFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrTskSchedule-entity-id-edit').val();
						var task_id = $('#projkt_task').val();
						showTaskScheduleChart(task_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrTaskChartFilter").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serIndx_cost = undefined;
						pntIndx_cost = undefined;
						serInactive_actuals = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrTskCost': {
					var filterContentHtml = "AnzrTaskChartFilter";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrTskCost-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskCost"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrTaskChartFilter-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrTskCost-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskCost"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#AnzrDateInp").css("display", "block");
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrTaskFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrTskCost-entity-id-edit').val();
						var task_id = $('#projkt_task').val();
						showTaskCostChart(task_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrTaskChartFilter").remove();
						serIndx_cost = undefined;
						pntIndx_cost = undefined;
						serInactive_cost = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrTskWork': {
					var filterContentHtml = "AnzrTaskChartFilter";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrTskWork-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskWork"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrTaskChartFilter-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrTskWork-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskWork"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#AnzrDateInp").css("display", "block");
											//$("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrTaskFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrTskWork-entity-id-edit').val();
						var task_id = $('#projkt_task').val();
						showTaskWorkChart(task_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrTaskChartFilter").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serInactive_work = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrTskEVMS': {
					var filterContentHtml = "AnzrTaskChartFilter";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrTskEVMS-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskEVMS"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
						
					} else {
						filterContentHtml = "AnzrTaskChartFilter-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrTskEVMS-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskEVMS"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
						
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											if (user_form_id == 'anzr-prjkt-evms') $("#projkt_task_contrl").css("display", "none");
											$("#chart_basis_contrl").css("display", "block");
											//if (user_form_id != 'anzr-prjkt-evms') $("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrTaskFilters($.popgSLfrm.styleIds[0]); 
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrTskEVMS-entity-id-edit').val();
						if (user_form_id == 'anzr-prjkt-evms') var task_id = '1';
							else var task_id = $('#projkt_task').val();
						showTaskEVMSChart(task_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrTaskChartFilter").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serInactive_work = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'anzrTskBurn': {
					var filterContentHtml = "AnzrTaskChartFilter";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="anzrTskBurn-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskBurn"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
					} else {
						filterContentHtml = "AnzrTaskChartFilter-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzrTskBurn-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="TskBurn"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
									
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											if (user_form_id == 'anzr-prjkt-burn') $("#projkt_task_contrl").css("display", "none");
											$("#chart_basis_contrl").css("display", "block");
											//if (user_form_id != 'anzr-prjkt-burn') $("#gSform_sav").attr("disabled", "disabled");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popAnzrTaskFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
											
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#anzrTskBurn-entity-id-edit').val();
						if (user_form_id == 'anzr-prjkt-burn') var task_id = '1';
							else var task_id = $('#projkt_task').val();
						showTaskBurnChart(task_id+','+val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#AnzrTaskChartFilter").remove();
						serIndx_work = undefined;
						pntIndx_work = undefined;
						serInactive_work = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ppfResWork': {
					var filterContentHtml = "PpfAnzrResFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="ppfResWork-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfRWork"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
					} else {
						filterContentHtml = "PpfAnzrResFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="ppfResWork-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfRWork"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
				
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											if (user_form_id == 'ppf-res-productivity') $("#PpfAnzrPeriodInp").css("display", "none");
												else $("#PpfAnzrDateInp").css("display", "block");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
													popPpfAnzrResFilters($.popgSLfrm.styleIds[0]);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#ppfResWork-entity-id-edit').val(); 
						if (user_form_id == 'ppf-res-productivity') showPpfResProductivity(val,$.popgSLfrm.styleIds[1]);
							else showPpfResWorkCharts(val,$.popgSLfrm.styleIds[1]);  
					}); 
					$("#gSform_cancel").click( function() {
						$("#PpfAnzrResFiler").remove();
						all_prj_select = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ppfEfsAnz': {
					var filterContentHtml = "PpfAnzrEFsFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="ppfEfsAnz-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfEfs"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
					} else {
						filterContentHtml = "PpfAnzrEFsFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="ppfEfsAnz-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfEfs"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											if (user_form_id == 'ppf-res-productivity') $("#PpfAnzrPeriodInp").css("display", "none");
												else $("#PpfAnzrDateInp, #PpfAnzrPeriodInp, #PpfAnzrOrderInp").css("display", "block");
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
														if ($('#wk0PPfAnalyzerProj').length){
															if ((user_form_id == 'ppf-ef-risks') || (user_form_id == 'ppf-ef-issues') || (user_form_id == 'ppf-ef-changes') || (user_form_id == 'ppf-ef-defects')) popPpfAnzrEfsFilters($.popgSLfrm.styleIds[0]);
																else popPpfAnzrProductionFilters($.popgSLfrm.styleIds[0]);
														};
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#ppfEfsAnz-entity-id-edit').val();
						showPpfEfsAnalyticCharts(val,$.popgSLfrm.styleIds[1]);
					}); 
					$("#gSform_cancel").click( function() {
						$("#PpfAnzrEFsFiler").remove();
						all_prj_select = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'ppfProductionAnz': {
					var filterContentHtml = "PpfAnzrEFsFiler";
					if (($.popgSLfrm.styleIds[0] == undefined) || ($.popgSLfrm.styleIds[0] == '')) {
						$("#gSform_message").append('<input type="text"  id="ppfProductionAnz-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gSform_message").append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfEfs"/>');
						$("#gSform_message").append('<br /><div id="gSform_division"></div');
						$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Chart" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
					} else {
						filterContentHtml = "PpfAnzrEFsFiler-inline";
						$("#"+$.popgSLfrm.styleIds[0]).empty();
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="ppfProductionAnz-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<input type="text"  id="anzr-chart-select" name="anzr-chart-select" style="display:none" value="ppfEfs"/>');
						$("#"+$.popgSLfrm.styleIds[0]).append('<br /><div id="gSform_division"></div');
						$("#"+$.popgSLfrm.styleIds[0]).append('<div id="inSLLine_panel" class="mnu_button_panel"><input type="button" value="Chart" id="gSform_sav" class="button mnu_btt"/></div><br />'); 
						$("#inSLLine_panel").css({
								 "z-index": 40,
								 "min-width": "99.8%",
								 "height": "40px",
								 "top": $(window).innerHeight() - 50,
								 "left": 0
							});		
						$("#WA-3-canvas").css({
								 "width": $(window).width() - $("#WA-2-filter").width() - 10 + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
						$("#WA-3").css({
								 "width": $("#WA-3-canvas").width() + 'px',
								 "height": ($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60)  + 'px'
							});
					}
										show_upload_started();
										$("#"+filterContentHtml).remove(); // HTML Shared with Update and View section
										$("#gSform_division").load("General_Services.html #"+filterContentHtml, function(responseText, statusText, xhr) {
											$("#ppf-efName-lbl").text("Production Metrics:");
											//alert(user_form_id);
											if (user_form_id == 'ppf-res-productivity') $("#PpfAnzrPeriodInp").css("display", "none");
												else {
													$('#ppf_res_rpt_interval').empty().append($('<option>', {value: 'Compl', text : 'Complete Duration'})).append($('<option>', {value: 'Month', text : 'Monthly'})).append($('<option>', {value: 'Week', text : 'Weekly'}));
													$("#ppf_res_rpt_interval option[value='Month']").attr("selected","selected");
													$("#PpfAnzrDateInp, #PpfAnzrPeriodInp").css("display", "block");
												}
											exclude_script('js/jquery.services.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.services.js' )
												.done(function( script, textStatus ) {
														if ($('#wk0PPfAnalyzerProj').length){
															if ((user_form_id == 'ppf-ef-risks') || (user_form_id == 'ppf-ef-issues') || (user_form_id == 'ppf-ef-changes') || (user_form_id == 'ppf-ef-defects')) popPpfAnzrEfsFilters($.popgSLfrm.styleIds[0]);
																else popPpfAnzrProductionFilters($.popgSLfrm.styleIds[0]);
														};
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.services.js', "js");
											}
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#ppfProductionAnz-entity-id-edit').val();
						showPpfProductionAnalyticCharts(val,$.popgSLfrm.styleIds[1]);
					}); 
					$("#gSform_cancel").click( function() {
						$("#PpfAnzrEFsFiler").remove();
						all_prj_select = undefined;
						user_form_id = undefined;
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				case 'AglPushStory': {
					$("#gSform_message").append('<input type="text"  id="AglPushStory-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gSform_message").append('<input type="text"  id="add-restrict-select" name="add-restrict-select" style="display:none" value="IPRestrict"/>');
					$("#gSform_message").append('<br /><div id="gSform_division"></div');
					$("#gSform_container").append('<div id="gSform_panel"><input type="button" value="Push" id="gSform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgSLfrm.cancelButton + '" id="gSform_cancel"  class="button gray smlbut"/></div><br />'); 
										show_upload_started();
										$("#SprintPushStory").remove(); 
										$("#gSform_division").load("Agile_Masters.html #SprintPushStory", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.gntSl_Forms.js', "js");
											//hide_upload_started(); 
											$.getScript( 'js/jquery.gntSl_Forms.js' )
												.done(function( script, textStatus ) {
													popPushStory(value);
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.gntSl_Forms.js', "js");
											}
										});
					
					$("#gSform_sav").click( function() {
						var val = $('#AglPushStory-entity-id-edit').val();
						submitPushStory(val);
					}); 
					$("#gSform_cancel").click( function() {
						$.popgSLfrm._hide();
					});
					if( value ) $("#gSform_division").val(value);
					$("#gSform_division").focus().select();
					break;
				}	
				
				
				
				
				
				/* next case here   */ 
				
				
			}
			// Make draggable
			if( $.popgSLfrm.draggable ) {
				try {
					$("#gSform_container").draggable({ handle: $("#gSform_title") });
					$("#gSform_title").css({ cursor: 'move' });
				} catch(e) { /* requires jQuery UI draggables */ }
			}
		},
		_show: function() {
			if (($.popgSLfrm.styleIds[0] == undefined) ||($.popgSLfrm.styleIds[0] == '')) {
				if ($.popgSLfrm.displayMode == false) {
					$("#gSform_container").removeClass("window-display").addClass("popuped-display");
					$("#gSform_title").removeClass("window-display-title").addClass("popuped-display-title");
					$(".gntSl-content-box").removeClass("gntSl-content-box-window").addClass("gntSl-content-box-popuped");
					$("#gSform_panel").css({
						 "min-width": $("#gSform_container").innerWidth(),
						 "height": "40px"
					});	
					$("#sl_cls_bak_bt").removeClass("backButton").addClass("closeButton"); 
				} else {
					$("#gSform_container").removeClass("popuped-display").addClass("window-display");
					$("#gSform_title").removeClass("popuped-display-title").addClass("window-display-title"); 
					$(".gntSl-content-box").removeClass("gntSl-content-box-popuped").addClass("gntSl-content-box-window");
					$("#gSform_panel").css({
						 "min-width": "99.8%",
						 "height": "40px"
					});	
					$("#sl_cls_bak_bt, #sl_hlp_bt").css("display", "none");
					$("#gSform_content").css({
						"height": $(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - $('#gSform_panel').outerHeight( true ) - 32
					}); 
				}
				//alert(popup_stack.length);
				$("#brd_errors_ico").css("display","none");
				var msgid = $("#gSform_division [id$='-message-box']").attr('id');
				if ((msgid != undefined) && (msgid !="")) {
					var classNames = $("#"+msgid).attr("class").toString();
					$("#"+msgid).remove();
					$("#gSform_errors").append('<div id="'+ msgid +'"></div>');
					$("#"+msgid).addClass(classNames).css("display", "none");
					
					if ($.popgSLfrm.displayMode == false) {
						$("#gSform_errors").css({
							zIndex: 4674,
							maxHeight: 180,
							minWidth: $("#gSform_container").innerWidth(),
							top: $.popgSLfrm.containerTop + $('#gSform_title').outerHeight( true ) + 'px',
							left: $.popgSLfrm.containerLeft + 'px'
						});
						
						$("#sl_cls_bak_bt, #sl_hlp_bt").css("display", "inline-block"); // check for help button
						$.popgSLfrm.containerTop = 0;
						$.popgSLfrm.containerLeft = 0;
						
					} else {
						$("#gSform_errors").css({
							zIndex: 4674,
							maxHeight: (($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 60) / 2),
							minWidth: "99.8%",
							top: $('.fix_header_class').outerHeight( true ) + $('#gSform_title').outerHeight( true )  + 'px',
							left: 0
						});
						$("#brd_back, #brd_home").css("display", "inline-block");
					}			
				
				}
				$("BODY").css("overflow", "hidden");
				$.popgSLfrm._overlay('show');
				$("#gSform_container").css("display", "block");
			}
			
		},
		_errbox: function() {
			var msgid = $("#gSform_errors [id$='-message-box']").attr('id');
			if ((msgid != undefined) && (msgid !="")) {
				if ($("#"+msgid).text() != '') {
					if ($("#gSform_errors").css("display") == "none") $("#gSform_errors").css("display", "block");
						else $("#gSform_errors").css("display", "none");
				}
			}
		},
		_home: function() {
			clearPopUps("Mn");
		
		},
		_help: function() {
			// help function - centralized
			return;
		},
		_hide: function() {
			if (($.popgSLfrm.styleIds[0] == undefined) ||($.popgSLfrm.styleIds[0] == '')) {
				$("#gSform_container").remove();
				clearPopUps("SL");
				$.popgSLfrm._overlay('hide');
				$.popgSLfrm._maintainPosition(false);
			}
			$.popgSLfrm.styleIds = [];
			if ($("[id$='form_container']").length == 0) $("BODY").css("overflow", "auto");
		},
		_overlay: function(status) {
			switch( status ) {
				case 'show':
					$.popgSLfrm._overlay('hide');
					$("BODY").append('<div id="gSform_overlay"></div>');
					if ($.popgSLfrm.displayMode == false) {
						$.popgSLfrm.overlayOpacity = 0.65;
						/*$("BODY").append('<div id="gSform_overlay_brd"></div>');
						$("#gSform_overlay_brd").css({
							position: 'absolute',
							zIndex: $(".fix_header_class").css("zIndex") + 4668,
							top: $('.fix_header_class').outerHeight( true ) - $("#GanttWithMode").outerHeight( false ) - $("#mega-menu-1").outerHeight( true ) +'px',  
							left: 0,
							width: '100%',
							height: $('#GanttWithMode').outerHeight( true ) + $("#mega-menu-1").outerHeight( true ),
							background: $.popgSLfrm.overlayColor,
							opacity: $.popgSLfrm.overlayOpacity
						}); */
					} else $.popgSLfrm.overlayOpacity = 0.01;
					$("#gSform_overlay").css({
						position: 'absolute',
						zIndex: 4668,
						top: $('.fix_header_class').outerHeight( true ) +'px',  
						left: 0,
						width: '100%',
						height: $(document).height() - $('.fix_header_class').outerHeight( true ) + 1,
						background: $.popgSLfrm.overlayColor,
						opacity: $.popgSLfrm.overlayOpacity
					});
					
				break;
				case 'hide':
					/* if ($.popgSLfrm.displayMode == false) $("#gSform_overlay, #gSform_overlay_brd").remove();
						else */
						$("#gSform_overlay").remove();
				break;
			}
		},
		_reposition: function() {
			if ($.popgSLfrm.displayMode == false) {
				var top = (($(window).height() / 2) - ($("#gSform_container").outerHeight() / 2)) + $.popgSLfrm.verticalOffset;
				var left = (($(window).width() / 2) - ($("#gSform_container").outerWidth() / 2)) + $.popgSLfrm.horizontalOffset;
				if( top < 0 ) top = 0;
				if( left < 0 ) left = 0;
				// IE6 fix
				if( $.browser.msie && parseInt($.browser.version) <= 6 ) top = top + $(window).scrollTop();
				
				$("#gSform_container").css({
					top: top + 'px',
					left: left + 'px'
				});
				
				$.popgSLfrm.containerTop = top;
				$.popgSLfrm.containerLeft = left;			
			
			} else {
				$("#gSform_container").css({
					top: $('.fix_header_class').outerHeight( true ) + 'px',
					left: 0
				});
			}
			
			$("#gSform_overlay").height( $(document).height() );
		},
		_maintainPosition: function(status) {
			if( $.popgSLfrm.repositionOnResize ) {
				switch(status) {
					case true:
						$(window).bind('resize', $.popgSLfrm._reposition);
					break;
					case false:
						$(window).unbind('resize', $.popgSLfrm._reposition);
					break;
				}
			}
		}
		
	}
	
	
	jgSforms = function(message, value, title, styles) {
		switch(message){ 

			case 'GntTaskFCAdd':
				$.popgSLfrm.GntTaskFCAdd(message, value, title, styles);
				break;
			case 'GntTaskFCEdit': 
				$.popgSLfrm.GntTaskFCEdit(message, value, title, styles);
				break;
			case 'GntTaskPredAdd':
				$.popgSLfrm.GntTaskPredAdd(message, value, title, styles);	
				break;

			case 'GntTaskPredEdit':
				$.popgSLfrm.GntTaskPredEdit(message, value, title, styles);
				break;
			case 'GntSaveAs': 
				$.popgSLfrm.GntSaveAs(message, value, title, styles);
				break;
			case 'GntBaseline':
				$.popgSLfrm.GntBaseline(message, value, title, styles);	
				break;
			case 'ShwResRate': 
				$.popgSLfrm.ShwResRate(message, value, title, styles);	
				break;
			case 'GntDelivUpload':
				$.popgSLfrm.GntDelivUpload(message, value, title, styles);
				break;

			case 'GntactFCAdd':
				$.popgSLfrm.GntactFCAdd(message, value, title, styles);
				break;
			case 'GntactFCEdit': 
				$.popgSLfrm.GntactFCEdit(message, value, title, styles);
				break;
			case 'GntactRWAdd':
				$.popgSLfrm.GntactRWAdd(message, value, title, styles);	
				break;
			case 'GntactRWEdit': 
				$.popgSLfrm.GntactRWEdit(message, value, title, styles);	
				break;
			case 'GntMOMsUpload':
				$.popgSLfrm.GntMOMsUpload(message, value, title, styles);
				break;


			case 'GntParticipantAdd':
				$.popgSLfrm.GntParticipantAdd(message, value, title, styles);
				break;
			case 'GntParticipantEdit': 
				$.popgSLfrm.GntParticipantEdit(message, value, title, styles);
				break;
			case 'GntRpsUpload':
				$.popgSLfrm.GntRpsUpload(message, value, title, styles);	
				break;
			case 'GntRpsGenerate': 
				$.popgSLfrm.GntRpsGenerate(message, value, title, styles);	
				break;
			case 'GntTaskReviewAdd':
				$.popgSLfrm.GntTaskReviewAdd(message, value, title, styles);
				break;


			case 'GntReviewParticipantAdd':
				$.popgSLfrm.GntReviewParticipantAdd(message, value, title, styles);
				break;
			case 'GntReviewParticipantEdit': 
				$.popgSLfrm.GntReviewParticipantEdit(message, value, title, styles);
				break;
			case 'GntReviewParticipantView':
				$.popgSLfrm.GntReviewParticipantView(message, value, title, styles);	
				break;
			case 'GntRpsCreate': 
				$.popgSLfrm.GntRpsCreate(message, value, title, styles);	
				break;
			case 'GntParticipantView':
				$.popgSLfrm.GntParticipantView(message, value, title, styles);
				break;


			case 'GntTaskIssueAdd':
				$.popgSLfrm.GntTaskIssueAdd(message, value, title, styles);
				break;
			case 'GntTaskIssueEdit': 
				$.popgSLfrm.GntTaskIssueEdit(message, value, title, styles);
				break;
			case 'GntTaskIssueUpdt':
				$.popgSLfrm.GntTaskIssueUpdt(message, value, title, styles);	
				break;
			case 'GntIssueCommentAdd': 
				$.popgSLfrm.GntIssueCommentAdd(message, value, title, styles);	
				break;
			case 'GntIssueCommentEdit':
				$.popgSLfrm.GntIssueCommentEdit(message, value, title, styles);
				break;


			case 'GntIssueCommentView':
				$.popgSLfrm.GntIssueCommentView(message, value, title, styles);
				break;
			case 'GntProjectRiskAdd': 
				$.popgSLfrm.GntProjectRiskAdd(message, value, title, styles);
				break;
			case 'GntProjectRiskEdit':
				$.popgSLfrm.GntProjectRiskEdit(message, value, title, styles);	
				break;
			case 'GntTaskRiskUpdt': 
				$.popgSLfrm.GntTaskRiskUpdt(message, value, title, styles);	
				break;
			case 'GntRiskCommentAdd':
				$.popgSLfrm.GntRiskCommentAdd(message, value, title, styles);
				break;


			case 'GntRiskCommentEdit':
				$.popgSLfrm.GntRiskCommentEdit(message, value, title, styles);
				break;
			case 'GntRiskCommentView': 
				$.popgSLfrm.GntRiskCommentView(message, value, title, styles);
				break;
			case 'GntProjectCRAdd':
				$.popgSLfrm.GntProjectCRAdd(message, value, title, styles);	
				break;
			case 'GntCRUpload': 
				$.popgSLfrm.GntCRUpload(message, value, title, styles);	
				break;
			case 'GntTaskCRUpdt':
				$.popgSLfrm.GntTaskCRUpdt(message, value, title, styles);
				break;


			case 'GntCRCommentAdd':
				$.popgSLfrm.GntCRCommentAdd(message, value, title, styles);
				break;
			case 'GntCRCommentEdit': 
				$.popgSLfrm.GntCRCommentEdit(message, value, title, styles);
				break;
			case 'GntCRCommentView':
				$.popgSLfrm.GntCRCommentView(message, value, title, styles);	
				break;
			case 'GntProjectBDAdd': 
				$.popgSLfrm.GntProjectBDAdd(message, value, title, styles);	
				break;
			case 'GntBDUpload':
				$.popgSLfrm.GntBDUpload(message, value, title, styles);
				break;


			case 'GntTaskBDUpdt':
				$.popgSLfrm.GntTaskBDUpdt(message, value, title, styles);
				break;
			case 'GntBDCommentAdd': 
				$.popgSLfrm.GntBDCommentAdd(message, value, title, styles);
				break;
			case 'GntBDCommentEdit':
				$.popgSLfrm.GntBDCommentEdit(message, value, title, styles);	
				break;
			case 'GntBDCommentView': 
				$.popgSLfrm.GntBDCommentView(message, value, title, styles);	
				break;
			case 'StakeGeneralEdit':
				$.popgSLfrm.StakeGeneralEdit(message, value, title, styles);
				break;


			case 'RskRegisterCommentView':
				$.popgSLfrm.RskRegisterCommentView(message, value, title, styles);
				break;
			case 'IsuRegisterCommentView': 
				$.popgSLfrm.IsuRegisterCommentView(message, value, title, styles);
				break;
			case 'BakWorkIssueView':
				$.popgSLfrm.BakWorkIssueView(message, value, title, styles);	
				break;
			case 'BakWorkIssueUpdate': 
				$.popgSLfrm.BakWorkIssueUpdate(message, value, title, styles);	
				break;
			case 'ProjCtrlView':
				$.popgSLfrm.ProjCtrlView(message, value, title, styles);	
				break;
			case 'ProjCtrlLock': 
				$.popgSLfrm.ProjCtrlLock(message, value, title, styles);	
				break;
			case 'ProjCtrlUnlock':
				$.popgSLfrm.ProjCtrlUnlock(message, value, title, styles);
				break;


			case 'ProjCtrlHistory':
				$.popgSLfrm.ProjCtrlHistory(message, value, title, styles);
				break;
			case 'GntMOMEmailView': 
				$.popgSLfrm.GntMOMEmailView(message, value, title, styles);
				break;
			case 'GntRpsEmailView':
				$.popgSLfrm.GntRpsEmailView(message, value, title, styles);	
				break;
			case 'GntRvwEmailView': 
				$.popgSLfrm.GntRvwEmailView(message, value, title, styles);	
				break;
		
			case 'showResAvail':
				$.popgSLfrm.showResAvail(message, value, title, styles);
				break;
			case 'showResActuals': 
				$.popgSLfrm.showResActuals(message, value, title, styles);
				break;
			case 'anzrResAlloc':
				$.popgSLfrm.anzrResAlloc(message, value, title, styles);	
				break;
			case 'anzrResPerform': 
				$.popgSLfrm.anzrResPerform(message, value, title, styles);	
				break;
			case 'anzrResCost':
				$.popgSLfrm.anzrResCost(message, value, title, styles);
				break;


			case 'anzrResProjection': 
				$.popgSLfrm.anzrResProjection(message, value, title, styles);
				break;
			case 'anzrResIssues':
				$.popgSLfrm.anzrResIssues(message, value, title, styles);
				break;				
			case 'anzrTskSchedule':
				$.popgSLfrm.anzrTskSchedule(message, value, title, styles);
				break;
			case 'anzrTskCost':
				$.popgSLfrm.anzrTskCost(message, value, title, styles);
				break;
			case 'anzrTskWork':
				$.popgSLfrm.anzrTskWork(message, value, title, styles);
				break;
				
				
			case 'anzrTskEVMS':
				$.popgSLfrm.anzrTskEVMS(message, value, title, styles);
				break;
			case 'anzrTskBurn':
				$.popgSLfrm.anzrTskBurn(message, value, title, styles);
				break;
			case 'ppfResWork':
				$.popgSLfrm.ppfResWork(message, value, title, styles);
				break;
			case 'ppfEfsAnz':
				$.popgSLfrm.ppfEfsAnz(message, value, title, styles);
				break;
			case 'ppfProductionAnz':
				$.popgSLfrm.ppfProductionAnz(message, value, title, styles);
				break;
				
			case 'AglPushStory':
				$.popgSLfrm.AglPushStory(message, value, title, styles);
				break;
				
			


			
		}
			
			
			
	}; 	
	
})(jQuery);