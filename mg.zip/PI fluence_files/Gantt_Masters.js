﻿
$(document).ready(function(){
	var user_identity = 0;
	
	if ((user_profile == 'stake') || (user_profile == 'proposal')) user_identity = user_id;
		else user_identity = user_sys_id;
	
	$("#flex-project-selector-planner").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
				{display: ' ID ', name : 'id', width : 160, sortable : true, align: 'left', hide: true},
				{display: 'Customer Name', name : 'customer_name', width : 360, sortable : true, align: 'left'},
				{display: 'Project Name', name : 'project_name', width : 360, sortable : true, align: 'left'},
				{display: 'Project Status', name : 'project_status', width : 160, sortable : true, align: 'left'},
				{display: 'Project Manager', name : 'project_manager', width : 360, sortable : true, align: 'left'}, 
				{display: 'Account Manager', name : 'account_manager', width : 360, sortable : true, align: 'left'},
				{display: 'Customer Contact', name : 'contact_id', width : 360, sortable : true, align: 'left'}, 
				{display: 'Agility', name : 'project_agility', width : 120, sortable : true, align: 'left'},
				{display: 'Start Date', name : 'start_date', width : 160, sortable : true, align: 'center'},		
				{display: 'Deadline End Date', name : 'deadline_end_date', width : 160, sortable : true, align: 'center'},
				{display: 'NDA', name : 'project_nda', width : 120, sortable : true, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add flx-plnr-add', onpress : selectProjectPlannerList},
			{separator: true}
			], 
		searchitems : [
				{display: 'Customer Name', name : 'customer_name'},
				{display: 'Project Name', name : 'project_name', isdefault: true}
			], 
		sortname: "customer_name",
		sortorder: "asc",
		usepager: true,
		title: 'Select Project:<span style="color: #cd1800;">&#42;</span>',
		useRp: true,
		onDoubleClick: '.flx-plnr-add',
		rp: 20,
		showTableToggleBtn: false,
		width: ($(window).width() * 0.75),
		height: (($(window).innerHeight() - $('.fix_header_class').outerHeight( true ) - 100) * 0.65),
		singleSelect: true,
		btnShow: false,
		appPage: "project-gantt-load-flx",
		fldSelect: user_identity+','+user_profile+','+publicView
	}); 
		
	$('#gantt-select-devp').change(function(){
		hide_all_errors();
		$("#GanttChartDIV").empty(); 
		$("#content_devp_data").css("display", "none");
		$('#gnt-process-mode option[value="2"]').attr("selected", "selected");
		$("#project_governance").removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("baklog_detach").addClass("ganttBaklog");
		
	}); 

	$("#gTrack_prg").prop("checked", true); 
	if (prjAgility == 0) $("#gWork_h").prop("checked", true); 
			 else $("#gWork_d").prop("checked", true); 
	
	$("#gRes_rl").prop("checked", true); 

	$("#Gantt-PWTrack input[name='gPWTrack']").change(function(){
		var sGTrack = parseInt($("#Gantt-PWTrack input[name='gPWTrack']:checked").val());
		if(sGTrack == 0) ProgressActual = 0; 
			else ProgressActual = 1; 
			$('#Gantt-type option[value="1"]').attr("selected", "selected");
			UpdateColsArray(); 
			if (prjAgility == 0) reDrawGantt();
			 else reDrawAgile();
	});
	
	$("#Gantt-DayHour input[name='gWork']").change(function(){
		var sGWork = parseInt($("#Gantt-DayHour input[name='gWork']:checked").val());
		if(sGWork == 0) WorkShow = 'H'; 
			else WorkShow = 'D'; 
		$('#Gantt-type option[value="1"]').attr("selected", "selected");
		UpdateColsArray(); 
		if (prjAgility == 0) reDrawGantt();
			 else reDrawAgile();
	});

	$("#Gantt-RoleName input[name='gRes']").change(function(){
		var sGRes = $("#Gantt-RoleName input[name='gRes']:checked").val();
		if(sGRes == 0) RoleName = 0; 
			else RoleName = 1;
		$('#Gantt-type option[value="1"]').attr("selected", "selected");
		UpdateColsArray(); 
		if (prjAgility == 0) reDrawGantt();
			 else reDrawAgile();
	});

	$("#Gantt-coverage").unbind("change").change(function(){
		var sGdisp = parseInt($("#Gantt-coverage").val());
		if(sGdisp == 1) {
			sgMode = 0; 
			$('#Gantt-type').removeAttr("disabled").removeClass('disabled_fld');
			$('#Gantt-type option[value="1"]').attr("selected", "selected");
			$("#print_ctrl").removeAttr('disabled').attr('title', 'Print Gantt chart').removeClass("printer_detach").addClass("ganttPrint");
		} else if(sGdisp == 2) {
			sgMode = 1; 
			$('#Gantt-type').attr("disabled", "disabled").addClass('disabled_fld');
			$("#print_ctrl").removeAttr('disabled').attr('title', 'Print Gantt chart').removeClass("printer_detach").addClass("ganttPrint");
		} else if(sGdisp == 3) {
			sgMode = 2; 
			$('#Gantt-type').removeAttr("disabled").removeClass('disabled_fld');
			$('#Gantt-type option[value="1"]').attr("selected", "selected");
			$('#print_ctrl').attr('disabled', 'disabled').removeAttr('title').removeClass("ganttPrint").addClass("printer_detach");
		}
		$('#Gantt-type option[value="1"]').attr("selected", "selected");
		UpdateColsArray(); 
		if (prjAgility == 0) reDrawGantt();
			 else reDrawAgile();
	});


	$("#Gantt-type").change(function(){
		var sGtype = parseInt($("#Gantt-type").val());
		if(sGtype == 1) $('#leftbotfill input[name="radFormat"][value="day"]').trigger("click");
			else if(sGtype == 2) $('#leftbotfill input[name="radFormat"][value="week"]').trigger("click");
			else if(sGtype == 3) $('#leftbotfill input[name="radFormat"][value="month"]').trigger("click");
			else if(sGtype == 4) $('#leftbotfill input[name="radFormat"][value="quarter"]').trigger("click");
	});
	
	hide_upload_started();
}); 

/*------------- Project Select Populator --------------     */ 

function selectProjectPlannerList(com,grid) {
    if (com=='Add') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist =items[0].id.substr(3);
			$('#gantt-select-devp').val(itemlist);
		} else $('#gantt-select-devp').val(0);
		
		if (parseInt($('#gantt-select-devp').val()) > 0) {
			empty_message_box("menu-message-box");
			hide_message_box("menu-message-box");
			$("#GanttChartDIV").empty(); 
			$("#content_devp_data").css("display", "none");
			$('#gnt-process-mode option[value="2"]').attr("selected", "selected");
			$("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
			populateGanttDevp('');
		} else {
				hide_all_errors();
				$("#GanttChartDIV").empty(); 
				$("#content_devp_data").css("display", "none");
				$('#gnt-process-mode option[value="2"]').attr("selected", "selected");
				$("#project_governance").removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("baklog_detach").addClass("ganttBaklog");		
				empty_message_box("menu-message-box");
				$("#menu-message-box").append('<br/><p><b>Project</b></p>').append('<p>&#9830; No project selected</p>');
				show_message_box("menu-message-box");
				jAlert('Correct errors indicated...','E');
			}	
	}
}	

function plannerButtonClick() {
	$(".flx-plnr-add").trigger("click"); //.hiddenFlexBtn
	$("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
}


/*------------- Project Gantt Chart Load --------------     */ 
function populateGanttDevp(elID) {
	$("#ganttview_ctrl").css("display","none");
	$("#content_devp_data").css("display", "block");
	clipAction = '';
	procesMode = 2;
	clipNode = -1;
	show_upload_started();
	user_previlege = 2;
	baklog_previlege = 0;
	bakLogShow = 0;
	primeDispStak = 1;
	primeDispTeam = 0;
	var user_identity = 0;
	if ((user_profile == 'stake') || (user_profile == 'proposal')) user_identity = user_id;
		else user_identity = user_sys_id;
	//alert(user_identity+' '+user_id);
	
	//return false;
	$.ajax({
        url: "phpGanttLoad.php",
        type: 'POST',
        data: {"page": "project-load", "project-id": $('#gantt-select-devp').val(), "user-identity":user_identity, "user-profile": user_profile, "user-id": user_id },
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);
			hide_all_errors();
			hide_upload_started();
			first_time_load = true;
			projData = jQuery.parseJSON(response);
			
			projectCustomer_id = projData[0]['customer-id'];
			customer = projData[0]['customer'];
			prjAgility = projData[0]['agility'];
			prjSprDur = projData[0]['sprint-duration'];
			prjSp2Hrs = projData[0]['sp-to-hrs'];
			prjSprVelocity = projData[0]['sprint-velocity'];
			deliv_extns = projData[0]['deliv-extns'];
			if (deliv_extns == '') deliv_extns ='0x1';
			weekEnds = projData[0]['week-ends'].split(",");
			HoliDays = projData[0]['holidays'].split(",");
			prjDtIn = projData[0]['date-input'];
			ganttDtOut = projData[0]['date-display'];
			prjStartDt = projData[0]['start-date'];
			if (projData[0]['deadline-track'] == '0') prjEndDt = '';
				else prjEndDt =	projData[0]['end-date'];
			prjAudit = projData[0]['audit-support'];
			prjStatus = projData[0]['status'];
			if (projData[0]['edit-lock'] > 0) prjStatus = 5;
			prjPayment = projData[0]['payment-mode'];
			prjPrgsLmt = -1 * projData[0]['progress-limit'];
			hoursAday = projData[0]['hours-day'];
			hoursAweek = projData[0]['hours-week'];
			daysAmonth = projData[0]['days-month'];
			WorkShow = projData[0]['effort-display'];
			GroupClr = projData[0]['group-color'];
			NormClr = projData[0]['normal-color'];
			MileClr = projData[0]['mile-color'];
			StryClr = projData[0]['story-color'];
			RGrpClr = projData[0]['rgroup-color'];
			RTskClr = projData[0]['rtask-color'];
			gCmpClr = projData[0]['gcomp-color'];
			gActClr = projData[0]['gactl-color'];
			gBakClr = projData[0]['gbakl-color'];
			gRlsClr = projData[0]['grels-color'];
			currency = projData[0]['cost-currency'];
			primeDispStak = projData[0]['display-stak'];
			primeDispTeam = projData[0]['display-team'];
			if (projData[0]['edit-lock'] == 3) prjLockSts = 1;
				else prjLockSts = 0;
			if (projData[0]['nda-status'] == 1) prjNdaSts = 1;
				else prjNdaSts = 0;	
			
			$("#Gantt-PWTrack-lbl, #Gantt-PWTrack").css('display', 'block');
			hide_fins = parseInt(projData[0]['hide-financials']);
			hide_acts = parseInt(projData[0]['hide-actuals']);
			
			brow_height = parseInt(projData[0]['browser-row-height']);
			brow_tuner = parseInt(projData[0]['browser-row-tuner']);
			//alert(brow_height);
			baklog_previlege = parseInt(projData[0]['baklog-previlege']);
			
			var u_prev = parseInt(projData[0]['user-previlege']);
			if (u_prev < user_previlege) user_previlege = u_prev;
			if (publicView > 0) {
				user_previlege = 2;
				hide_fins = 1;
				//hide_acts = 1;
			}
			//alert(user_previlege);
			response = undefined;
			if (user_previlege == 2) {
			    $("#project_settings, #project_analyzing, #project_governance, #baseline_ctrl, #clipboard_ctrl, #gnt-process-mode").css("display", "none");
				if (prjAgility == 0) $("#ganttsave_ctrl").css("display", "none");
					else $("#ganttsave_ctrl").css("display", "block");
			} else if (user_previlege == 1) {
				$("#project_settings, #project_analyzing, #project_governance, #baseline_ctrl, #clipboard_ctrl").css("display", "none");
				if (prjAgility == 0) $("#ganttsave_ctrl").css("display", "none");
					else $("#ganttsave_ctrl").css("display", "block");
				$("#gnt-process-mode option[value='0']").remove();
				$("#gnt-process-mode option[value='2']").attr("selected","selected");
				$("#project_governance").removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("baklog_detach").addClass("ganttBaklog");
				if (user_profile == 'stake') $("#gnt-process-mode").css("display", "block");
					else $("#project_governance, #gnt-process-mode").css("display", "block");
			} if (user_previlege == 0) {
				// Full Rights
				if ( $("#gnt-process-mode option[value='0']").length == 0 ){
					$('#gnt-process-mode').empty().append($('<option>', {value: '0', text : 'Edit'})).append($('<option>', {value: '1', text : 'Update'})).append($('<option>', {value: '2', text : 'View'}));
					$("#gnt-process-mode option[value='2']").attr("selected","selected");
					$("#project_governance").removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("baklog_detach").addClass("ganttBaklog");
				}
				if (user_profile == 'stake') {
					if (prjAgility == 0) $("#ganttsave_ctrl").css("display", "none");
						else $("#ganttsave_ctrl").css("display", "block");
					$("#clipboard_ctrl, #gnt-process-mode").css("display", "block");
				} else $("#project_settings, #project_analyzing, #ganttsave_ctrl, #project_governance, #baseline_ctrl, #clipboard_ctrl, #gnt-process-mode").css("display", "block");
			}
			
			if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) $('#report_create').css("display","none");
				else $('#report_create').css("display", "block");
				
						
			$("#client_name").text(customer);
			if (prjAgility == 0) {
				WorkShow = 'H'; 
				$("#gWork_h").prop("checked", true); 
				//$("input[name='gWork'][value='0']").attr("checked", "checked");
			} else {
				WorkShow = 'P';
				$("#gWork_d").prop("checked", true); 
				//$("input[name='gWork'][value='1']").attr("checked", "checked");
			} 
			
			// Open this comment to show baklog first for stakeholders or porposal
			if ((prjAgility == 1) && ((user_profile == 'stake') || (user_profile == 'proposal')) && (primeDispStak == 1)) bakLogShow = 1;
				else if ((prjAgility == 1) && ((user_profile == 'stake') || (user_profile == 'proposal')) && (primeDispStak == 0)) bakLogShow = 0;
				else {
					if ((prjAgility == 1) && (primeDispTeam == 1)) bakLogShow = 1;
						else bakLogShow = 0;
				}
			fnProjectSelectorMenu( false );	
			loadProjectGantt('');
			
		}
	});
	
	if (publicView > 0) {
		procesMode = 2;
		$("#gnt-process-mode").css("display", "none");
	}
	$("#gnt-process-mode").unbind( "change" ).change(function(){	
		
		if($("#gnt-process-mode").val() == "2") $("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
			else $('#project_governance').removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("baklog_detach").addClass("ganttBaklog");
				
		
		
		if ($("#gnt-process-mode").val() == "0") {
			var prjStatusStr = "";
			if ((prjStatus == 2) || (prjStatus == 4) || (prjStatus == 5)) {
				switch (prjStatus) {
					case 2:
						prjStatusStr = 'Completed';
						break;
					case 4:
						prjStatusStr = 'Cancelled';
						break;
					case 5:
						prjStatusStr = 'Locked';
						break;				
				}
				jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Edit the Tasks...','E', function(){
					procesMode = 2;
					$('#gnt-process-mode option[value="2"]').attr('selected', 'selected');
					$("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
				});			
			} else {
				procesMode = 0;
			}
		} else {
			if ($("#gnt-process-mode").val() == "1") {
				var prjStatusStr = "";
				if ((prjStatus == 1) || ((prjAgility == 1) && (bakLogShow == 1))) {
					procesMode = 1;
				} else {
					switch (prjStatus) {
						case 0:
							prjStatusStr = 'Pending Approval';
							break;
						case 2:
							prjStatusStr = 'Completed';
							break;
						case 3:
							prjStatusStr = 'On Hold';
							break;
						case 4:
							prjStatusStr = 'Cancelled';
							break;
						case 5:
							prjStatusStr = 'Locked';
							break;				
					}
					jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Update the Task...','E', function(){
						procesMode = 2;
						$('#gnt-process-mode option[value="2"]').attr('selected', 'selected');
						$("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
					});
				}	
			} else if ($("#gnt-process-mode").val() == "2") procesMode = 2;
			clipAction = "";
			clipNode = -1;
			$('#clipboard_ctrl').attr('title', 'Clipboard Empty...').removeClass("clipboard_fill").addClass("clipboard_empty");
		}
		loadProjectGantt('');	
	});	
}

function plannerPrivilegeSet() {
	
	$('#gnt-process-mode').empty().append($('<option>', {value: '0', text : 'Edit'})).append($('<option>', {value: '1', text : 'Update'})).append($('<option>', {value: '2', text : 'View'})).css("display", "none");
	$("#gnt-process-mode option[value='2']").attr("selected","selected");
	$("#project_governance").attr('disabled', 'disabled').removeAttr('title').removeClass("ganttBaklog").addClass("baklog_detach");
	if (bakLogShow == 0) {
		if (user_previlege == 2) $("#gnt-process-mode").css("display", "none");
			else {
				if (user_previlege == 1)  $("#gnt-process-mode option[value='0']").remove();
				$("#gnt-process-mode").css("display", "block");
			} 
	} else {
		if ((user_profile == 'stake') || (user_profile == 'proposal')){
			if (baklog_previlege == 0) $("#gnt-process-mode").css("display", "none");
				else {
					$("#gnt-process-mode option[value='1']").remove();
					$("#gnt-process-mode").css("display", "block");
				}
		} else {
			if (user_previlege != 0) $("#gnt-process-mode").css("display", "none");
				else $("#gnt-process-mode").css("display", "block");
			/* if (user_previlege == 2) $("#gnt-process-mode").css("display", "none");
				else {
					if (user_previlege == 1)  $("#gnt-process-mode option[value='0']").remove();
					$("#gnt-process-mode").css("display", "block");
				} 
			*/	
		}
	}
}



function loadProjectGantt(exception) {
	show_upload_started();
	var pageToLoad = "gantt-load";
	var phpToSeek = "phpGanttLoad.php";
	if (prjAgility == 1) {
		
		if (bakLogShow == 0) {
			phpToSeek = "phpSprintLoad.php";
			pageToLoad = "agile-load";
		} else {
			phpToSeek = "phpAgileLoad.php";
			pageToLoad = "baklog-load";
		}	
	}	
	
	$.ajax({
		url: phpToSeek,
		type: 'POST',
		data: {"page": pageToLoad, 
				"project-id": $('#gantt-select-devp').val(), 
				"except-node": exception, 
				"user-id": user_id, 
				"user-profile": user_profile,
				"user-previlege": user_previlege,
				"user-public": publicView,
				"user-mode": procesMode
		},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);  //MSD
			hide_all_errors();
			hide_upload_started();

			prjkt = jQuery.parseJSON(response);
			
			if (prjAgility == 0) {
				$(".window_name").css("display","none");
				$('#ganttsave_ctrl').removeClass("ganttBacklog").removeClass("ganttPlanner").addClass("ganttSaveAs").attr("title", "Save As WBS");
				if (first_time_load == true) {
					first_time_load = false;
					ColOrder = ColGantter;
					$("#window_name").text("Planner");
				}	
				sgMode = 0;
				$(".Agility0").css("display","block");
				$(".Agility1").css("display","none");
				$("#sCTask-Agile").html("&nbsp&nbspTasks");
				$("#sCWork-Agile").html("&nbsp&nbspWork");
				$('#Gantt-coverage-lbl, #Gantt-coverage').css('display', 'block');
				$('#Gantt-coverage option[value="1"]').attr("selected", "selected");
				$('#Gantt-type').attr("disabled", "disabled").addClass('disabled_fld');
				$("#print_ctrl").removeAttr('disabled').attr('title', 'Print Gantt chart').removeClass("printer_detach").addClass("ganttPrint");
				$("#ganttview_ctrl").css("display","block");
				reDrawGantt();
			} else {
				$(".window_name").css("display","block");
				if (bakLogShow == 0) {
					$('#ganttsave_ctrl').removeClass("ganttSaveAs").removeClass("ganttPlanner").addClass("ganttBacklog").attr("title", "Switch to product storyboard");
					$("#window_name").text("Planner");
					if (first_time_load == true) {
						plannerPrivilegeSet();
						first_time_load = false;
						ColOrder = ColAgiler;
					} 
					sgMode = 1;
					$(".Agility0").css("display","none");
					$(".Agility1").css("display","block");
					$("#sCTask-Agile").html("&nbsp&nbspDescription");
					$("#sCWork-Agile").html("&nbsp&nbspPicked Work");
					$('#Gantt-coverage option[value="2"]').attr("selected", "selected");
					$('#Gantt-coverage-lbl, #Gantt-coverage').css('display', 'block');
					$('#Gantt-type').attr("disabled", "disabled").addClass('disabled_fld');
					$("#print_ctrl").removeAttr('disabled').attr('title', 'Print Gantt chart').removeClass("printer_detach").addClass("ganttPrint");
					$("#ganttview_ctrl").css("display","block");
					reDrawAgile();
				} else {
					$('#ganttsave_ctrl').removeClass("ganttSaveAs").removeClass("ganttBacklog").addClass("ganttPlanner").attr("title", "Switch to sprint planner");
					$("#window_name").text("Storyboard");
					if (first_time_load == true){
						plannerPrivilegeSet();
						first_time_load = false; //  && (bakLogShow == 1)) 
						ColOrder = ColBaklog;
					}
					sgMode = 1;
					$(".Agility0").css("display","none");
					$(".Agility1").css("display","block");
					$("#sCTask-Agile").html("&nbsp&nbspDescription");
					$("#sCWork-Agile").html("&nbsp&nbspPicked Work");
					$('#Gantt-coverage option[value="2"]').attr("selected", "selected");
					$('#Gantt-coverage-lbl, #Gantt-coverage, #Gantt-type-div').css('display', 'none');
					$('#Gantt-type').attr("disabled", "disabled").addClass('disabled_fld');
					$("#Gantt-PWTrack-lbl, #Gantt-PWTrack").css('display', 'none');
					$("#print_ctrl").removeAttr('disabled').attr('title', 'Print Gantt chart').removeClass("printer_detach").addClass("ganttPrint");
					$("#ganttview_ctrl").css("display","block");
					reDrawAgile();
				}
			}
			
			actionGntClip();
			//fnProjectSelectorMenu( false );
			if ((user_profile == 'stake') || (user_profile == 'proposal')){
				$('.HideStakeMenu').css("display","none");
			}			
			
			if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
				$('.HideFinanceMenu').css("display","none");
				
			} else if (((user_profile == 'stake') || (user_profile == 'proposal')) && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
				$('.HideActualsMenu').css("display","none");
			}

			
			
			
			if (procesMode != 0) $("[id^='gntMlnode_']").disableContextMenu();
				else $("[id^='gntMlnode_']").enableContextMenu();
				
			//if (publicView > 0) $("#report_create, #story_use, #resource_use, #ca_use").css("display", "none");
				
		}
	});
	

}
/*
function isRecurTask(node_ID) {
	var isRecur = 0;
	for (i=0; i < prjkt.length; i++) {
		if (parseInt(prjkt[i]["pID"]) == node_ID)
		 if (parseInt(prjkt[i]["pRtask"]) > 0) {
			isRecur = 1;
			break;
		 }
    }
	return isRecur;
}

*/

/*------------- END of Project Gantt Chart Load --------------     */

/*------------- Project Gantt Chart Nodes Edit --------------     */ 

function actionGanttDevp(action, node_ID, node_type) {
	var nodeId = node_ID.split('_');
	var elementID = parseInt(nodeId[1]);
	//alert(action+" - "+elementID+" - "+node_type);
	selNodeType = node_type;
	if (action == "add") {
		jgfForms('GntTaskAdd', elementID,'Add Task...');	
	} else if (action == "insert") {
		jgfForms('GntTaskInsert', elementID,'Insert Task...');
	} else if (action == "edit") {
		jgfForms('GntTaskEdit', elementID,'Edit Task...');
	} else if (action == "cut") {
		clipAction = "cut";
		clipNode = elementID;
		actionGntClip();
		loadProjectGantt(elementID);
	} else if (action == "copy") {
		clipAction = "copy";
		clipNode = elementID;
		actionGntClip();
		loadProjectGantt('');
	} else if (action == "inactive") {
		//alert("-- inactive --");
		var alrTitle = 'Inactivate';
		var alrMsg = 'Inactivate Project Task(s)<b>?</b> Confirm...';
		var Node_Info = getNodeInfo(elementID);
		if (Node_Info["story-active"] == 2) {
			alrTitle = 'Activate';
			alrMsg = 'Activate Project Task(s)<b>?</b> Confirm...';
		}
		
				jConfirm(alrMsg, '', function(user_act) {
					if (user_act) {
						show_upload_started();
						
						$.ajax({
							url: "phpGanttService.php",
							type: 'POST',
							data: {"page": 'gnt-node-inactive',
								   "project-id": $('#gantt-select-devp').val(), 
								   "node":elementID,
								   "user-id": user_id
							},
							timeout: xhr_timeout * 10,
							error: function () {
								hide_all_errors(); //
								hide_upload_started(); //
								jAlert('Could not connect to server...','T');
							},
							success: function(response) {
								//alert(response);
								
								response = $.parseJSON(response); 
								if (response[0][0].status == "error") {
									hide_upload_started();
									hide_message_box("gntFl-message-box");
									jAlert(response[0][0].data['messg'],'E', function() {
										loadProjectGantt('');
									});
								} else if (response[0][0].status == "success") {
									hide_upload_started();
									if (response[0][0].data['node-id'] != '-1') {
										loadProjectGantt('');
									} else {
										jAlert(response[0][0].data['messg'],'E');
									}  
								}
							}
						});			
					} else {
						return false;
					};
				});
		
	} else if (action == "delete") {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-node-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node":elementID,
							   "user-id": user_id
						},
						timeout: xhr_timeout * 10,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							
							response = $.parseJSON(response); 

							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntFl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
									loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									loadProjectGantt('');
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
							response = undefined;
						}
					});			
					
				} else {
					return false;
				};
			});
	} else if (action == "paste") {
				show_upload_started();
				$.ajax({
					url: "phpGanttService.php",
					type: 'POST',
					data: {"page": 'gnt-node-paste', 
						   "project-id": $('#gantt-select-devp').val(), 
						   "node": elementID, 
						   "clip-action": clipAction,
						   "clip-node": clipNode,
						   "user-id": user_id}, //set action accordingly copy or cut
					timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					}, 
					success: function(response) {
						
						//alert(response);
					
						response = $.parseJSON(response);
						if (response[0][0].status == "error") {
							hide_upload_started();
							hide_message_box("gntFl-message-box");
							jAlert(response[0][0].data['messg'],'E', function() {
								clipAction = "";
								clipNode = -1;
								actionGntClip();
								loadProjectGantt('');
							});
						} else if (response[0][0].status == "success") {
							// --- check  and correct
							hide_upload_started();
							if (response[0][0].data[0]['node-id'] != '-1') {
								clipAction = "";
								clipNode = -1;
								actionGntClip();
								loadProjectGantt('');
							} else {
								jAlert(response[0][0].data[0]['messg'],'E');
							}   
						}
						response = undefined;
					}
				});	
	} else if (action == "attach") {
				show_upload_started();
				$.ajax({
					url: "phpGanttService.php",
					type: 'POST',
					data: {"page": 'gnt-node-attach', 
						   "project-id": $('#gantt-select-devp').val(), 
						   "node": elementID, 
						   "clip-action": clipAction,
						   "clip-node": clipNode,
						   "user-id": user_id
						}, //set action accordingly copy or cut
					timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					}, 
					success: function(response) {
						
						//alert(response);
					
						response = $.parseJSON(response);
						if (response[0][0].status == "error") {
							hide_upload_started();
							hide_message_box("gntFl-message-box");
							jAlert(response[0][0].data['messg'],'E', function() {
								clipAction = "";
								clipNode = -1;
								actionGntClip();
								loadProjectGantt('');
							});
						} else if (response[0][0].status == "success") {
							// --- check  and correct
							hide_upload_started();
							if (response[0][0].data[0]['node-id'] != '-1') {
								clipAction = "";
								clipNode = -1;
								actionGntClip();
								loadProjectGantt('');
							} else {
								jAlert(response[0][0].data[0]['messg'],'E');
							}   
						}
						response = undefined;
					}
				});	
	}
}


/*-------------------------------------------------   Agile Node EDIT Actions ------------------------------------------*/

function actionAgileDevp(action, node_ID, node_type, source_id) {
	var nodeId = node_ID.split('_');
	var elementID = parseInt(nodeId[1]);
	//alert(action+" - "+elementID+" - "+node_type);
	selNodeType = node_type;
	if (source_id == "planner") {
		if (action == "cut") {
			clipAction = "cut";
			clipNode = elementID;
			actionGntClip();
			loadProjectGantt(elementID);
		} else if (action == "copy") {
			clipAction = "copy";
			clipNode = elementID;
			actionGntClip();
			loadProjectGantt('');
		} else if (action == "add") {
			jgfForms('GntTaskAdd', elementID,'Add Task...');	
		} else if (action == "insert") {
			jgfForms('GntTaskInsert', elementID,'Insert Task...');
		} else if (action == "edit") {
			jgfForms('GntTaskEdit', elementID,'Edit Task...');
		} else if ((action == "delete") || (action == "deletesprint") || (action == "deletestory")) {
				jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
					if (user_act) {
						show_upload_started();
						$.ajax({
							url: "phpGanttService.php",
							type: 'POST',
							data: {"page": 'gnt-node-delete',
								   "project-id": $('#gantt-select-devp').val(), 
								   "node":elementID,
								   "user-id": user_id
							},
							timeout: xhr_timeout * 10,
							error: function () {
								hide_all_errors(); //
								hide_upload_started(); //
								jAlert('Could not connect to server...','T');
							},
							success: function(response) {
								//alert(response);
								
								response = $.parseJSON(response); 
								if (response[0][0].status == "error") {
									hide_upload_started();
									hide_message_box("gntFl-message-box");
									jAlert(response[0][0].data['messg'],'E', function() {
										loadProjectGantt('');
									});
								} else if (response[0][0].status == "success") {
									hide_upload_started();
									if (response[0][0].data[0]['node-id'] != '-1') {
										loadProjectGantt('');
									} else {
										jAlert(response[0][0].data[0]['messg'],'E');
									}  
								}
								response = undefined;
							}
						});			
						
					} else {
						return false;
					};
				});
		} else if (action == "paste") {
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-node-paste', 
							   "project-id": $('#gantt-select-devp').val(), 
							   "node": elementID, 
							   "clip-action": clipAction,
							   "clip-node": clipNode,
							   "user-id": user_id}, //set action accordingly copy or cut
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							
							//alert(response);
						
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntFl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}   
							}
							response = undefined;
						}
					});	
		} else if (action == "attach") {
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-node-attach', 
							   "project-id": $('#gantt-select-devp').val(), 
							   "node": elementID, 
							   "clip-action": clipAction,
							   "clip-node": clipNode,
							   "user-id": user_id
							}, //set action accordingly copy or cut
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							
							//alert(response);
						
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntFl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}   
							}
							response = undefined;
						}
					});	
		} else if (action == "editproject") {
			jgfForms('AglEditStory', elementID,'Edit Project Data...');
		} else if (action == "addsprint") {
			jgfForms('AglAddSprint', elementID,'Add Sprint...');
		} else if (action == "insertsprint") {
			jgfForms('AglInsertSprint', elementID,'Insert Sprint...');
		} else if (action == "editsprint") {
			jgfForms('AglEditSprint', elementID,'Edit Sprint...');
		} else if (action == "pullstory") {
			jgfForms('AglPullStory', elementID,'Pull Story...');
		} else if (action == "editstory") {
			jgfForms('AglEditStory', elementID,'Edit Story...');
		} else if (action == "insertstory") {
			jgfForms('AglInsertStory', elementID,'Pull and Insert Story...');
		} else if (action == "pushstory") {
			jgSforms('AglPushStory', elementID,'Push Story...');
		} else if (action == "addmeeting") {
			jgfForms('GntTaskMeeting', elementID,'Add Meeting...');
		} else if (action == "insertmeeting") {
			jgfForms('GntInsertMeeting', elementID,'Insert Meeting...');
		} else if (action == "editmeeting") {
			jgfForms('GntEditMeeting', elementID,'Edit Meeting...');
		};
	} else {
		if (action == "cut") {
			clipAction = "cut";
			clipNode = elementID;
			actionGntClip();
			loadProjectGantt(elementID);
		} else if (action == "add") {
			jgfForms('BakStoryAdd', elementID,'Add Story...');	
		} else if (action == "insert") {
			jgfForms('BakStoryInsert', elementID,'Insert Story...');
		} else if (action == "edit") {
			jgfForms('BakStoryEdit', elementID,'Edit Story...');
		} else if (action == "delete") {
				var alrTitle = 'Delete';
				var alrMsg = 'Delete Story(s)<b>?</b> Confirm...';
				var Node_Info = getNodeInfo(elementID);
				if (Node_Info["story-active"] == 2) {
					alrTitle = 'Undelete';
					alrMsg = 'Undelete Story(s)<b>?</b> Confirm...';
				}
				jConfirm(alrMsg, '', function(user_act) {
					if (user_act) {
						show_upload_started();
						
						$.ajax({
							url: "phpBacklogService.php",
							type: 'POST',
							data: {"page": 'sty-node-delete',
								   "project-id": $('#gantt-select-devp').val(), 
								   "node":elementID,
								   "user-id": user_id
							},
							timeout: xhr_timeout * 10,
							error: function () {
								hide_all_errors(); //
								hide_upload_started(); //
								jAlert('Could not connect to server...','T');
							},
							success: function(response) {
								//alert(response);
								
								response = $.parseJSON(response); 
								if (response[0][0].status == "error") {
									hide_upload_started();
									hide_message_box("gntFl-message-box");
									jAlert(response[0][0].data['messg'],'E', function() {
										loadProjectGantt('');
									});
								} else if (response[0][0].status == "success") {
									hide_upload_started();
									if (response[0][0].data['node-id'] != '-1') {
										loadProjectGantt('');
									} else {
										jAlert(response[0][0].data['messg'],'E');
									}  
								}
							}
						});			
						
					} else {
						return false;
					};
				});
		} else if (action == "purge") {
				var Node_Info = getNodeInfo(elementID);
				if (Node_Info["story-active"] == 2) {
					jConfirm('Permanently Delete Story(s)<b>? Action cannot be reverted!</b> Confirm...', '', function(user_act) {
						if (user_act) {
							show_upload_started();
							
							$.ajax({
								url: "phpBacklogService.php",
								type: 'POST',
								data: {"page": 'sty-node-purge',
									   "project-id": $('#gantt-select-devp').val(), 
									   "node":elementID,
									   "user-id": user_id
								},
								timeout: xhr_timeout * 10,
								error: function () {
									hide_all_errors(); //
									hide_upload_started(); //
									jAlert('Could not connect to server...','T');
								},
								success: function(response) {
									//alert(response);
									
									response = $.parseJSON(response); 
									if (response[0][0].status == "error") {
										hide_upload_started();
										hide_message_box("gntFl-message-box");
										jAlert(response[0][0].data['messg'],'E', function() {
											loadProjectGantt('');
										});
									} else if (response[0][0].status == "success") {
										hide_upload_started();
										if (response[0][0].data['node-id'] != '-1') {
											loadProjectGantt('');
										} else {
											jAlert(response[0][0].data['messg'],'E');
										}  
									}
								}
							});			
							
						} else {
							return false;
						};
					});
				} else {
					jAlert('Only <b><i>Deleted</i></b> Story(s) can be purged!','E', function() {
						return false;
					});
				}
		} else if (action == "paste") {
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'sty-node-paste', 
							   "project-id": $('#gantt-select-devp').val(), 
							   "node": elementID, 
							   "clip-action": clipAction,
							   "clip-node": clipNode,
							   "user-id": user_id}, //set action accordingly copy or cut
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							
							//alert(response);
						
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntFl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}   
							} 
						}
					});	
		} else if (action == "attach") {
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'sty-node-attach', 
							   "project-id": $('#gantt-select-devp').val(), 
							   "node": elementID, 
							   "clip-action": clipAction,
							   "clip-node": clipNode,
							   "user-id": user_id
							}, //set action accordingly copy or cut
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							
							//alert(response);
						
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntFl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									clipAction = "";
									clipNode = -1;
									actionGntClip();
									loadProjectGantt('');
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}   
							} 
						}
					});	
		}	
	
	}
	return false;
}




/*-------------------------------------------------   END OF Agile Node EDIT Actions ------------------------------------------*/

function popupvanish() {
	var e = jQuery.Event("keydown");
	e.which = 27; // # Esc key code value
	$('body').trigger(e);

}

function actionGntClip() {
	if (prjAgility == 1) {
		if (clipAction == "") {
			$('#clipboard_ctrl').attr('title', 'Clipboard Empty...').removeClass("clipboard_fill").addClass("clipboard_empty");
			// Disable paste
			$('#myMenuAgile, #myMenuSprntAgile, #myMenuStoryAgile').disableContextMenuItems('#paste,#attach');
			$('#myMenuRootAgile').disableContextMenuItems('#attach');
			//$('#myMenuRGrpAgile, #myMenuMileAgile').disableContextMenuItems('#paste');
		} else {
			$('#clipboard_ctrl').attr('title', 'Clipboard Data, Click to Empty...').removeClass("clipboard_empty").addClass("clipboard_fill");
			
			// Enable cut/copy
			$('#myMenuAgile, #myMenuSprntAgile, #myMenuStoryAgile').enableContextMenuItems('#paste,#attach'); 
			$('#myMenuRootAgile').enableContextMenuItems('#paste,#attach'); 
			//$('#myMenuRGrpAgile, #myMenuMileAgile').enableContextMenuItems('#paste');
			$("#clipboard_ctrl").click(function() {
				clipAction = "";
				clipNode = -1;
				loadProjectGantt('');
			});
		}
	} else {
		if (clipAction == "") {
			$('#clipboard_ctrl').attr('title', 'Clipboard Empty...').removeClass("clipboard_fill").addClass("clipboard_empty");
			// Disable paste
			$('#myMenu').disableContextMenuItems('#paste,#attach');
			$('#myMenuRoot').disableContextMenuItems('#attach');
			$('#myMenuRGrp, #myMenuMile').disableContextMenuItems('#paste');
		} else {
			$('#clipboard_ctrl').attr('title', 'Clipboard Data, Click to Empty...').removeClass("clipboard_empty").addClass("clipboard_fill");
			
			// Enable cut/copy
			$('#myMenu').enableContextMenuItems('#paste,#attach'); 
			$('#myMenuRoot').enableContextMenuItems('#paste,#attach'); 
			$('#myMenuRGrp, #myMenuMile').enableContextMenuItems('#paste');
			$("#clipboard_ctrl").click(function() {
				clipAction = "";
				clipNode = -1;
				loadProjectGantt('');
			});
		}
	}	
}

function TaskController(node_ID, action) {
	$("html, body").animate({ scrollTop: 0 }, "slow");
	help_tab_id = 1;
	$(".taskmenu > li").click(function(e){
		switch(e.target.id){ 
			case "tab_general": 
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 1;
				$("#tab_general").addClass("active");
				$("#tab_dates, #tab_cost, #tab_predecessor, #tab_resources, #tab_advanced, #tab_documents").removeClass("active");
				$("#content_general").fadeIn();
				$("#content_dates, #content_cost, #content_predecessor, #content_resources, #content_advanced, #content_documents").css("display", "none");
			break;
			case "tab_dates":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 2;
				$("#tab_general, #tab_cost, #tab_predecessor, #tab_resources, #tab_advanced, #tab_documents").removeClass("active");
				$("#tab_dates").addClass("active");
				$("#content_dates").fadeIn();
				$("#content_general, #content_cost, #content_predecessor, #content_resources, #content_advanced, #content_documents").css("display", "none");
			break;
			
			case "tab_cost":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 3;
				$("#tab_general, #tab_dates, #tab_predecessor, #tab_resources, #tab_advanced, #tab_documents").removeClass("active");
				$("#tab_cost").addClass("active");
				$("#content_cost").fadeIn();
				$("#content_general, #content_dates, #content_predecessor, #content_resources, #content_advanced, #content_documents").css("display", "none");
			break; 
			
			case "tab_predecessor":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 4;
				$("#tab_general, #tab_dates, #tab_cost, #tab_resources, #tab_advanced, #tab_documents").removeClass("active");
				$("#tab_predecessor").addClass("active");
				$("#content_predecessor").fadeIn();
				$("#content_general, #content_dates, #content_cost, #content_resources, #content_advanced, #content_documents").css("display", "none");
			break; 
			
			case "tab_documents":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 5;
				$("#tab_general, #tab_dates, #tab_cost, #tab_predecessor, #tab_resources, #tab_advanced").removeClass("active");
				$("#tab_documents").addClass("active");
				$("#content_documents").fadeIn();
				$("#content_general, #content_dates, #content_cost, #content_predecessor, #content_resources, #content_advanced").css("display", "none");
			break; 
			
			case "tab_resources":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 6;
				$("#tab_general, #tab_dates, #tab_cost, #tab_predecessor, #tab_advanced, #tab_documents").removeClass("active");
				$("#tab_resources").addClass("active");
				$("#content_resources").fadeIn();
				$("#content_general, #content_dates, #content_cost, #content_predecessor, #content_documents, #content_advanced").css("display", "none");
			break; 

			case "tab_advanced":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 7;
				$("#tab_general, #tab_dates, #tab_cost, #tab_predecessor, #tab_resources, #tab_documents").removeClass("active");
				$("#tab_advanced").addClass("active");
				$("#content_advanced").fadeIn();
				$("#content_general, #content_dates, #content_cost, #content_predecessor, #content_documents, #content_resources").css("display", "none");
			break; 
		}
		return false;
	});
	$.popgFLfrm._show();
	if (action == 'add') scriptTaskAddIns(action, node_ID); 
		else if (action == 'insert') scriptTaskAddIns(action, node_ID); 
		else if (action == 'edit') scriptTaskEdit(action, node_ID);
		else if (action == 'addsprint') scriptSprintAddIns(action, node_ID); 
		else if (action == 'insertsprint') scriptSprintAddIns(action, node_ID); 
		else if (action == 'editsprint') scriptSprintEdit(action, node_ID);
		else if (action == 'addbakstory') scriptStoryAddIns(action, node_ID);
		else if (action == 'insertbakstory') scriptStoryAddIns(action, node_ID);
		else if (action == 'editbakstory') scriptStoryEdit(action, node_ID);
		else if (action == 'pullstory') scriptStoryPullIns(action, node_ID); 
		else if (action == 'insertstory') scriptStoryPullIns(action, node_ID);
		else if (action == 'editstory') scriptAglEditStory(action, node_ID);
	return true;	
}


/* ------------- Story Edit ----------------------    */


function loadAgileStoryData(node_ID, action) {

	$('#gnt-story-release-sps, #gnt-available-hrs, #tsk-available-hrs, #sprint-velocity').addClass('populate_loading');
	$.ajax({
		url: "phpAgileLoad.php",
		type: 'POST',
		data: {"page": "agile-story-load", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_an) {
			//alert(action + '--' + response_an); 
			$('#gnt-story-release-sps, #gnt-available-hrs, #tsk-available-hrs, #sprint-velocity').removeClass('populate_loading');
			response_an = $.parseJSON(response_an);
			if (parseInt(node_ID) > 1) {
				task_budget = response_an["task-budget"];
				task_allotted = response_an["work-alloted"];
				
				$('#gnt-story-release-sps').spinner( "option", "max", task_budget );
				$('#gnt-story-release-sps').val(response_an["sprint-release-sp"].toFixed(2));
				$('#gnt-available-hrs').val(task_budget.toFixed(2));
				$('#tsk-available-hrs').val((task_budget - task_allotted).toFixed(2));
			} else {
				$('#sprint-velocity').val(response_an["sprint-velocity"]);
				if (response_an["stak-baklog-prim"] == 1) $('#stak-backlog-display').attr('checked', 'checked');
					else $('#stak-backlog-display').removeAttr('checked');
				if (response_an["team-baklog-prim"] == 1) $('#team-backlog-display').attr('checked', 'checked');
					else $('#team-backlog-display').removeAttr('checked');
				if (response_an["sprint-display-prim"] == 1) $('#sprint-open-display').attr('checked', 'checked');
					else $('#sprint-open-display').removeAttr('checked');	
					
			}
		}
	});
}



function scriptAglEditStory(action, node_ID) {
	//$("#gFform_sav, #gFform_del").attr("disabled","disabled"); 
	selNodeID = node_ID;
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	var NodeInfo = getNodeInfo(node_ID);
	$('#gnt-story-release-sps').spinner({min: 0, max: 1000.00, decimals: 2, stepping: 0.25}).val(0);
	$("#sprint-velocity").spinner({min: 1, max: 1000});
	
	loadAgileStoryData(selNodeID, action);	
	
	if (selNodeData != '') {
		switch(selNodeData){ 
			case "Notes": {
				$("#tab_general").trigger("click");
				break;
			}
			case "ID": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Tasks": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Cost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "Progress": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Work": {
				$("#tab_resources").trigger("click");
				break;
			}
			case "FixedCost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "CtrlAccnt": {
				$("#tab_cost").trigger("click");
				break;
			}
			default:
				$("#tab_general").trigger("click");
				break;			
		}
	
	}
	
	if (NodeInfo["grptask"] == 1) {
		$('#chkgnt-Work-Dur-lbl, #gnt-Work-Dur').css("display", "none");
	}
	
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Change Request Details:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
		
	hide_message_box("gntFl-message-box");
	$("#constraint-box").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(ID: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	$('#gntNode-name-dyn').val(getNodeName(node_ID));
	
	$('#gnt-task-notes').val(NodeInfo["notes-desc"]);
	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ca) {
			$('#gnt-CA').removeClass('populate_loading');
			response_ca = $.parseJSON(response_ca);
			if (response_ca.length > 0) {
				for(ij = 0; ij< response_ca.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response_ca[ij]["value"]).text(response_ca[ij]["descr"]));
					if (response_ca[ij]["value"] == NodeInfo["ca"]) var selected_ca = response_ca[ij]["value"]; // value from previous ajax
				};
				$('#gnt-CA option[value='+ selected_ca +']').attr("selected","selected");
			};

		}
	});

		
	// Grid for fixed costs
	$("#flex-fixCost").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskFCLists}, 
			{name: 'Edit', bclass: 'edit flx-prjTaskFFCs-Edit', onpress : taskFCLists},
			{name: 'Delete', bclass: 'delete', onpress : taskFCLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Description', name : 'fc_description', isdefault: true}
			], 
		sortname: "fc_description",
		sortorder: "asc",
		usepager: true,
		title: 'Task Fixed Cost',
		useRp: true,
		onDoubleClick: '.flx-prjTaskFFCs-Edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskfc",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
		
	var WH_display = 'Work Hours';
	if (prjAgility == 1) WH_display = 'Story Points';
	
	// Grid for Resources
/*	$("#flex-task-resources").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Name', name : 'resource_id', width : 360, sortable : true, align: 'left'},
			{display: 'Work Contour', name : 'work_mode', width : 160, sortable : true, align: 'center'},
			{display: 'Work Rate', name : 'work_rate', width : 100, sortable : true, align: 'center'},
			{display: WH_display, name : 'resource_hours', width : 120, sortable : true, align: 'right'},
			{display: 'Cost', name : 'resource_cost', width : 175, sortable : true, align: 'right'},
			{display: 'Progress', name : 'resource_earned_work', width : 100, sortable : true, align: 'right'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskResLists}, 
			{name: 'Edit', bclass: 'edit', onpress : taskResLists},
			{name: 'Delete', bclass: 'delete', onpress : taskResLists},
			{separator: true}
			],
		sortname: "resource_id",
		sortorder: "asc",
		usepager: true,
		title: 'Task Resources',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		singleSelect: true,
		appPage: "project-taskresorce",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); */
	
	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	
	$("#flex-task-documents").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Delete', bclass: 'delete', onpress : taskDelivLists},
			{name: 'Download', bclass: 'download', onpress : taskDelivLists},
			{name: 'View', bclass: 'view flx-prjDelDocss-Vw', onpress : taskDelivLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: false,
		title: 'Task Deliverables',
		useRp: false,
		onDoubleClick: '.flx-prjDelDocss-Vw',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskdelivs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	

	selNodeType = '';
	return true;
}

function submitAglNode1Edit(node_id) {
	empty_message_box("gntFl-message-box");
	var node_id = parseInt(node_id);
	show_upload_started();
	var ValidationStatus = true;
	if ((prjAudit == 1) && (prjStatus == 1)) {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Change Request Details</b></p>').append(MesgStrg);
			}		
	} else {
		var inp = $('#gnt-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
	}
	
	if (ValidationStatus == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {		 
		var sprint_velocity = parseFloat($('#sprint-velocity').val().replace(/[^0-9\-\.]/g, ''));
		var stak_baklog_prime = $('#stak-backlog-display').attr('checked')?1:0;
		var team_baklog_prime = $('#team-backlog-display').attr('checked')?1:0;
		var sprint_open_prime = $('#sprint-open-display').attr('checked')?1:0;
		$.ajax({
			url: "phpAgileService.php",
			type: 'POST',
			data: {
				"page": 'project-node1-edit',
				"project-id": $('#gantt-select-devp').val(),
				"node-id": node_id, 
				"node-notes": $('#gnt-task-notes').val(), 
				"sprint-velocity": sprint_velocity,
				"stak-backlog": stak_baklog_prime,
				"team-backlog": team_baklog_prime,
				"sprint-default": sprint_open_prime,
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				
				//alert(response);
			
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); Save the documents
							selNodeData = '';
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	}
	return true;
}



function submitAglStoryEdit(node_id) {
	empty_message_box("gntFl-message-box");
	var node_id = parseInt(node_id);
	show_upload_started();
	var ValidationStatus = true;
	if ((prjAudit == 1) && (prjStatus == 1)) {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Change Request Details</b></p>').append(MesgStrg);
			}		
	} else {
		var inp = $('#gnt-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
	}
	
	if (ValidationStatus == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {		 
		var story_release = parseFloat($('#gnt-story-release-sps').val().replace(/[^0-9\-\.]/g, ''));
		$.ajax({
			url: "phpAgileService.php",
			type: 'POST',
			data: {
				"page": 'story-node-edit',
				"project-id": $('#gantt-select-devp').val(),
				"node-id": node_id, 
				"task-CA": $('#gnt-CA').val(), 
				"node-notes": $('#gnt-task-notes').val(), 
				"story-release": story_release,
				
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				
				//alert(response);
			
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); Save the documents
							selNodeData = '';
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	}
	return true;
}


/* ----------------- Backlog Story Edit --------------------- */
function scriptStoryEdit(action, node_ID) {
	$("#bak-add-ins-lbl").text("Story Current Title:");
	hide_message_box("gntFl-message-box");
	$('#bakNode-name-curr-dyn').val('(ID: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	var Node_Info = getNodeInfo(node_ID);
	selNodeID = node_ID;
	if (Node_Info["story-active"] == 2) $('#gFform_del').val('Undelete');
		else $('#gFform_del').val('Delete');
	
	//if (node_ID == 1) $("#bak-story-priority").attr("disabled", "disabled");
	//	else $("#bak-story-priority").removeAttr("disabled");
	
	$("#bakNode-id-dyn").val(Node_Info["story-no"]).autocomplete("phpAutocomplete.php", {
		width: 210,
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "baklogstory",
		entity: "story-id"+"^^"+$('#gantt-select-devp').val()
	});	

	$("#bakNode-name-dyn").val(getNodeName(node_ID)).autocomplete("phpAutocomplete.php", {
		width: $('#bakNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "baklogstory",
		entity: "story-name"+"^^"+$('#gantt-select-devp').val()
	});	
	
	
	$("#bak-task-notes").val(Node_Info["notes-desc"]);
	$("#bak-story-priority  option[value="+ Node_Info["priorty"] +"]").attr("selected", "selected");
	
	enableWYSIWYG('bak-story-desc');
	//$("#bak-story-desc").addClass('populate_loading');
	
	$.ajax({
		url: "phpAgileLoad.php",
		type: 'POST',
		data: {"page": "sty-desc-load", "project-id": $('#gantt-select-devp').val(), "node-id":node_ID},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ds) {
			//$('bak-story-desc').removeClass('populate_loading');
			//alert(response_ds);
			response_ds = JSON.parse(response_ds);
			$('#bak-story-desc').wysiwyg('shell').setHTML(response_ds);
		}
	});

	$("#flex-sty-gts").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
			{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [ // function in Gantt_Controls.js
			{name: 'Update', bclass: 'update', onpress : GTLists},
			{name: 'View', bclass: 'view', onpress : GTLists},
			{name: 'Comment', bclass: 'comment flx-prjStyGTss-Cmt', onpress : GTLists},
			{name: 'History', bclass: 'history', onpress : GTLists},
			{name: 'Purge', bclass: 'purge', onpress : GTLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'cr_title', isdefault: true},
			{display: 'Ticket ID', name : 'cr_id'},
			{display: 'Requested by', name : 'requested_by'}
			], 
		sortname: "requested_on",
		sortorder: "desc",
		usepager: true,
		title: 'Story Grooming Tips',
		useRp: true,
		onDoubleClick: '.flx-prjStyGTss-Cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyGTs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 
	
	$("#flex-sty-issues").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
			{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
			{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [  // function in Gantt_Controls.js
			{name: 'Update', bclass: 'update', onpress : BacklogIssueLists}, 
			{name: 'Comment', bclass: 'comment flx-prjStyChng-Cmt', onpress : BacklogIssueLists},
			{name: 'History', bclass: 'history', onpress : BacklogIssueLists},
			{name: 'Purge', bclass: 'purge', onpress : BacklogIssueLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'issue_title', isdefault: true},
			{display: 'Ticket ID', name : 'issue_id'},
			{display: 'Reported by', name : 'raised_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Story Challenges',
		useRp: true,
		onDoubleClick: '.flx-prjStyChng-Cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-story-challenges",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 
	
	
	$("#flex-sty-history").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Updated on', name : 'cr_date', width : 175, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Action', name : 'story_action', width : 120, sortable : true, align: 'left'},
			{display: 'Story ID', name : 'story_number', width : 175, sortable : false, align: 'left'},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'Priority', name : 'node_priority', width : 120, sortable : false, align: 'left'},
			{display: 'Notes', name : 'task_notes ', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'View', bclass: 'view flx-prjStyHstr-vwe', onpress : styEditHistory}, 
			{separator: true}
			],
		searchitems : [
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "cr_date",
		sortorder: "desc",
		usepager: true,
		title: 'Story Edit History',
		useRp: true,
		onDoubleClick: '.flx-prjStyHstr-vwe',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyEdtHistory",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	$("#flex-sprint-history").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Action on', name : 'cr_date', width : 175, sortable : true, align: 'left'},
			{display: 'Action by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Action', name : 'story_action', width : 120, sortable : true, align: 'left'},
			{display: 'Action Notes', name : 'action_desc ', width : 360, sortable : false, align: 'left'}
			],
		searchitems : [
			{display: 'Action by', name : 'updated_by'}
			], 
		sortname: "cr_date",
		sortorder: "desc",
		usepager: true,
		title: 'Story Sprint History',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 203,
		singleSelect: true,
		appPage: "backlog-sprintHistory",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	
	$('#storyToUpload').MultiFile({ 
		list: '#storyUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	
	$("#flex-sty-documents").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Delete', bclass: 'delete', onpress : backlogDocsLists},
			{name: 'Download', bclass: 'download', onpress : backlogDocsLists},
			{name: 'View', bclass: 'view flx-prjStyAttc-vwe', onpress : backlogDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: false,
		title: 'Story Attachments',
		useRp: false,
		onDoubleClick: '.flx-prjStyAttc-vwe',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		appPage: "baklog-storyattach",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+',0'
	}); 
	
	return true;
}

function styEditHistory(com,grid) {
    if (com=='View') { 
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { 
			/* jConfirm('View the Edit History Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('styBakEdtHist', itemlist,'Story Edit History...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }       
}


function backlogDocsLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist ='';
					 for(i=0;i<items.length;i++){
						itemlist+= items[i].id.substr(3)+",";
					} 
					$.ajax({
					   type: "POST",
					   url: "phpFlexService.php",
					   data: {"page": "baklog-sty-attach-delete", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					   	timeout: xhr_timeout * 10,
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						},
					   success: function(data){
						// alert(data);
						$("#flex-sty-documents").flexReload();
					   }
					 }); 
				} else {
					return false;
				};
			});
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='Upload') {
        /*jConfirm('Upload new Document<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntDelivUpload', selNodeID,'Upload Document...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Download') {
        //alert('Download Action');
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			 
			zipDownloader("baklog-sty-attach-dwl", $('#gantt-select-devp').val(), itemlist); 			 
			 
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='View') {
		if ($('.trSelected',grid).length>0) {  
			if ($('.trSelected',grid).length>1) { 
				jAlert('Too many documents selected! Select one...', 'E');	
			} else {
				var items = $('.trSelected',grid); 
				var itemlist ='';
				 for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3);
				} 
				//alert(itemlist);
				$.ajax({
				   type: "POST",
				   url: "phpFlexService.php",
				   data: {"page": "baklog-sty-attach-view", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					timeout: xhr_timeout * 10,
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					},
				   success: function(data){
						response = $.parseJSON(data); 
						var FileName = response[0]["file-to-view"].replace(/ /g, '%20');
						var FileMIME = response[0]["file-mime-type"];
						if(FileMIME != '') {
							var myWindow = window.open("","_blank","fullscreen=yes, location=no, menubar=no, toolbar=no");
							myWindow.document.write('<object data='+ FileName +' type='+ FileMIME +' width="100%" height="100%"><p>Cannot open the document directly.  <a href='+ FileName +'>Click here to download the file...</a></p></object>');
						} else jAlert('Unable to open the document...', 'E');
				   }
				 }); 
			}; 
		
		} else {
			jAlert('Document NOT selected !', 'E');
		}; 
    };
	return true;
}

function submitBakStoryEdit(node_ID) {
	empty_message_box("gntFl-message-box");
	show_upload_started();
	var ValidationStatus = true;
	var MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'bakNode-id-dyn',
			mn_length: 1,
			mx_length: 20,
			strg_type: 'ntext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>New Story ID</b></p>'+MesgStrg);
	}	
	
	var MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'bakNode-name-dyn',
			mn_length: 6,
			mx_length: 300,
			strg_type: 'ctext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>New Story Title</b></p>'+MesgStrg);
	}
	if (node_ID > 1) {
		var inp = $('#bak-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'bak-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
		MesgStrg = '';
		var storyDesc = JSON.stringify($('#bak-story-desc').wysiwyg('shell').getHTML());
		if (storyDesc.length < 10)  MesgStrg = '<p>&#9830; No required number of characters</p>';
			else if (storyDesc.length > 4000)  MesgStrg = '<p>&#9830; More than allowed number of characters</p>';
		if (MesgStrg.length > 0) {
			ValidationStatus = false;
			$("#gntFl-message-box").append('<br/><p><b>User Story Description</b></p>'+MesgStrg);
		}	
	} else {
		$('#bak-task-notes').val('');
		storyDesc = '-';
	}
	
	if (ValidationStatus == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {
		if (node_ID > 1) {
			storyDesc = storyDesc.replace(/'/g, "&#39;");
			storyDesc = storyDesc.replace(/\?/g, "&#63;");
		}	
		//return false;   // REMOVE ---------
		$.ajax({
			url: "phpBacklogService.php",
			type: 'POST',
			data: {
				"page": 'sty-node-edit',
				"project-id": $('#gantt-select-devp').val(),
				"node-id": node_ID, 
				"node-name": $('#bakNode-name-dyn').val(), 
				"node-notes": $('#bak-task-notes').val(), 
				"story-num": $('#bakNode-id-dyn').val(), 
				"task_priority": $('#bak-story-priority').val(), 
				"story-desc": storyDesc,                      
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				//alert(response);
				//return false;
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct errors indicated...','E', function() {
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
							
					});
				} else if (response[0][0].status == "duplicate") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct errors indicated...','E', function() {
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
							
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#storyUploadList').length > 0) {
					//alert('Succ');
						$('#storyUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="story-file" style="display:none"/>');
						$('#storyUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="storyToUpload" style="display:none"/>');
						$('#storyUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadStory').trigger('click'); 	
					}	
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); 
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	};
	return false;
}

function submitBakStoryDelete(node_ID) {

	var alrTitle = 'Delete';
	var alrMsg = 'Delete Story(s)<b>?</b> Confirm...';
	var Node_Info = getNodeInfo(node_ID);
	if (Node_Info["story-active"] == 2) {
		alrTitle = 'Undelete';
		alrMsg = 'Undelete Story(s)<b>?</b> Confirm...';
	}
	jConfirm(alrMsg, '', function(user_act) {
		if (user_act) {
			show_upload_started();
			
			$.ajax({
				url: "phpBacklogService.php",
				type: 'POST',
				data: {"page": 'sty-node-delete',
					   "project-id": $('#gantt-select-devp').val(), 
					   "node":node_ID,
					   "user-id": user_id
				},
				timeout: xhr_timeout * 10,
				error: function () {
					hide_all_errors(); //
					hide_upload_started(); //
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					//alert(response);
					
					response = $.parseJSON(response); 
					if (response[0][0].status == "error") {
						hide_upload_started();
						hide_message_box("gntFl-message-box");
						jAlert(response[0][0].data['messg'],'E', function() {
							loadProjectGantt('');
						});
					} else if (response[0][0].status == "success") {
						hide_upload_started();
						if (response[0][0].data['node-id'] != '-1') {
							loadProjectGantt('');
							$.popgFLfrm._hide();
						} else {
							jAlert(response[0][0].data['messg'],'E');
						}  
					}
				}
			});			
			
		} else {
			return false;
		};
	});


}
/* -------------------- END OF Story EDIT Popup ----------*/

/* ----------------- Story Add and Insert --------------------- */
function scriptStoryAddIns(action, node_ID) {
	if (action == 'addbakstory') $("#bak-add-ins-lbl").text("Story Selected:");
		else if (action == 'insertbakstory') $("#bak-add-ins-lbl").text("Story Selected to Insert at:");
		
	hide_message_box("gntFl-message-box");
	$('#bakNode-name-curr-dyn').val('(ID: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	
	$("#bakNode-id-dyn").autocomplete("phpAutocomplete.php", {
		width: 210,
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "baklogstory",
		entity: "story-id"+"^^"+$('#gantt-select-devp').val()
	});	

	$("#bakNode-name-dyn").autocomplete("phpAutocomplete.php", {
		width: $('#bakNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "baklogstory",
		entity: "story-name"+"^^"+$('#gantt-select-devp').val()
	});	
	
	enableWYSIWYG('bak-story-desc');

	$('#storyToUpload').MultiFile({ 
		list: '#storyUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	return true;
}

// Function to submit (Save) Add or Insert request from dynamic screen

function submitBakStoryAddIns(submitType) {
	empty_message_box("gntFl-message-box");
	show_upload_started();
	var ValidationStatus = true;
	var MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'bakNode-id-dyn',
			mn_length: 1,
			mx_length: 20,
			strg_type: 'ntext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>New Story ID</b></p>'+MesgStrg);
	}	
	
	var MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'bakNode-name-dyn',
			mn_length: 6,
			mx_length: 300,
			strg_type: 'ctext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>New Story Title</b></p>'+MesgStrg);
	}	
	var inp = $('#bak-task-notes').val();
	if (inp.length > 0) {	
		MesgStrg = '';
		MesgStrg += validate({ 
				elem_id: 'bak-task-notes',
				mn_length: 2,
				mx_length: 300,
				strg_type: 'ctext',
				msg_type: 'mesg-box'
			});
		if (MesgStrg.length > 0) {
			ValidationStatus = false;
			$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
		}		
	}
	MesgStrg = '';
	var storyDesc = JSON.stringify($('#bak-story-desc').wysiwyg('shell').getHTML());
	if (storyDesc.length < 10)  MesgStrg = '<p>&#9830; No required number of characters</p>';
		else if (storyDesc.length > 4000)  MesgStrg = '<p>&#9830; More than allowed number of characters</p>';
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>User Story Description</b></p>'+MesgStrg);
	}	
	if (ValidationStatus == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {
		storyDesc = storyDesc.replace(/'/g, "&#39;");
		storyDesc = storyDesc.replace(/\?/g, "&#63;");
		
		//return false;   // REMOVE ---------
		$.ajax({
			url: "phpBacklogService.php",
			type: 'POST',
			data: {
				"page": 'sty-node-add-insert',
				"project-id": $('#gantt-select-devp').val(),
				"submit-action": submitType, 
				"node-id": $('#div-entity-id-edit').val(), 
				"node-name": $('#bakNode-name-dyn').val(), 
				"node-notes": $('#bak-task-notes').val(), 
				"story-num": $('#bakNode-id-dyn').val(), 
				"task_priority": $('#bak-story-priority').val(), 
				"story-desc": storyDesc,                      
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				//alert(response);
				//return false;
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct errors indicated...','E', function() {
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
							
					});
				} else if (response[0][0].status == "duplicate") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct errors indicated...','E', function() {
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
							
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#storyUploadList').length > 0) {
					//alert('Succ');
						$('#storyUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="story-file" style="display:none"/>');
						$('#storyUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="storyToUpload" style="display:none"/>');
						$('#storyUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadStory').trigger('click'); 	
					}	
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); 
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	};
	return false;
}
/* ----------------- END OF Story Add Ins ---------------------------------*/

function submitStoryDelete(node_id) {
	var alrTitle = 'Delete';
	var alrMsg = 'Delete Story(s)<b>?</b> Confirm...';
	var Node_Info = getNodeInfo(node_id);
	if (Node_Info["story-active"] == 2) {
		alrTitle = 'Undelete';
		alrMsg = 'Undelete Story(s)<b>?</b> Confirm...';
	}
	jConfirm(alrMsg, '', function(user_act) {
		if (user_act) {
			show_upload_started();
			$.ajax({
				url: "phpBacklogService.php",
				type: 'POST',
				data: {"page": 'sty-node-delete',
					   "project-id": $('#gantt-select-devp').val(), 
					   "node":node_id,
					   "user-id": user_id
				},
				timeout: xhr_timeout * 10,
				error: function () {
					hide_all_errors(); //
					hide_upload_started(); //
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					//alert(response);
					response = $.parseJSON(response); 
					if (response[0][0].status == "error") {
						hide_upload_started();
						hide_message_box("gntFl-message-box");
						jAlert(response[0][0].data['messg'],'E', function() {
								//$.popgFLfrm._hide();
								loadProjectGantt('');
						});
					} else if (response[0][0].status == "success") {
						hide_upload_started();
						if (response[0][0].data['node-id'] != '-1') {
							loadProjectGantt('');
							jAlert(response[0][0].data['messg'],'S',function() {
								$.popgFLfrm._hide();
							});
						} else {
							jAlert(response[0][0].data['messg'],'E');
						}  
					}
				}
			});			
			
		} else {
			return false;
		};
	});
}





/* ------------------ WYSIWYG Editor Enable END --------------*/

function enableWYSIWYG(element_ID) {
		var element = '#'+element_ID;
        $(element).wysiwyg({
           // classes: 'some-more-classes',
            // 'selection'|'top'|'top-selection'|'bottom'|'bottom-selection'
            toolbar: 'top-selection',
            buttons: {
                // Fontname plugin
                fontname: {
                    title: 'Font',
                    image: '<img src="images/wysiwyg/fonts.png" width="16" height="16" alt="" />',
                    popup: function( $popup, $button ) {
                            var list_fontnames = {
                                    // Name : Font
                                    'Arial, Helvetica' : 'Arial,Helvetica',
                                    'Verdana'          : 'Verdana,Geneva',
                                    'Georgia'          : 'Georgia',
                                    'Courier New'      : 'Courier New,Courier',
                                    'Times New Roman'  : 'Times New Roman,Times'
                                };
                            var $list = $('<div/>').addClass('wysiwyg-toolbar-list')
                                                   .attr('unselectable','on');
                            $.each( list_fontnames, function( name, font ){
                                var $link = $('<a/>').attr('href','#')
                                                    .css( 'font-family', font )
                                                    .html( name )
                                                    .click(function(event){
                                                        $(element).wysiwyg('shell').fontName(font).closePopup();
                                                        // prevent link-href-#
                                                        event.stopPropagation();
                                                        event.preventDefault();
                                                        return false;
                                                    });
                                $list.append( $link );
                            });
                            $popup.append( $list );
                           },
                    //showstatic: true,    // wanted on the toolbar
                    showselection: true     // wanted on selection
                },
                // Fontsize plugin
                fontsize: {
                    title: 'Size',
                    image: '<img src="images/wysiwyg/fsize.png" width="16" height="16" alt="" />',
                    popup: function( $popup, $button ) {
                            var list_fontsizes = {
                                // Name : Size
                                'Huge'    : 7,
                                'Larger'  : 6,
                                'Large'   : 5,
                                'Normal'  : 4,
                                'Small'   : 3,
                                'Smaller' : 2,
                                'Tiny'    : 1
                            };
                            var $list = $('<div/>').addClass('wysiwyg-toolbar-list')
                                                   .attr('unselectable','on');
                            $.each( list_fontsizes, function( name, size ){
                                var $link = $('<a/>').attr('href','#')
                                                    .css( 'font-size', (8 + (size * 3)) + 'px' )
                                                    .html( name )
                                                    .click(function(event){
                                                        $(element).wysiwyg('shell').fontSize(size).closePopup();
                                                        // prevent link-href-#
                                                        event.stopPropagation();
                                                        event.preventDefault();
                                                        return false;
                                                    });
                                $list.append( $link );
                            });
                            $popup.append( $list );
                           },
                    showselection: true    // wanted on selection
                }, 
                // Header plugin
                bold: {
                    title: 'Bold (Ctrl+B)',
                    image: '<img src="images/wysiwyg/bold.png" width="15" height="15" alt="" />',  
                    hotkey: 'b'
                },
                italic: {
                    title: 'Italic (Ctrl+I)',
                    image: '<img src="images/wysiwyg/italic.png" width="15" height="15" alt="" />',  
                    hotkey: 'i'
                },
                underline: {
                    title: 'Underline (Ctrl+U)',
                    image: '<img src="images/wysiwyg/uline.png" width="15" height="15" alt="" />',  
                    hotkey: 'u'
                },
                strikethrough: {
                    title: 'Strikethrough (Ctrl+S)',
                    image: '<img src="images/wysiwyg/sthru.png" width="16" height="16" alt="" />',  
                    hotkey: 's'
                },
                subscript: {
                    title: 'Subscript',
                    image: '<img src="images/wysiwyg/subscript.png" width="16" height="16" alt="" />',  
                    showselection: true    // wanted on selection
                },
                superscript: {
                    title: 'Superscript',
                    image: '<img src="images/wysiwyg/superscript.png" width="16" height="16" alt="" />',  
                    showselection: true    // wanted on selection
                },
                forecolor: {
                    title: 'Text color',
                    image: '<img src="images/wysiwyg/fcolor.png" width="16" height="16" alt="" />',
					showselection: true 
                },
                highlight: {
                    title: 'Background color',
                    image: '<img src="images/wysiwyg/fbakgr.png" width="16" height="16" alt="" />',
					showselection: true 
                }, 
 			    alignleft: {
                    title: 'Left',
                    image: '<img src="images/wysiwyg/lalign.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
                aligncenter: {
                    title: 'Center',
                    image: '<img src="images/wysiwyg/calign.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
                alignright: {
                    title: 'Right',
                    image: '<img src="images/wysiwyg/ralign.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
                alignjustify: {
                    title: 'Justify',
                    image: '<img src="images/wysiwyg/justify.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                }, 
                indent: {
                    title: 'Indent',
                    image: '<img src="images/wysiwyg/indent.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
                outdent: {
                    title: 'Outdent',
                    image: '<img src="images/wysiwyg/outdent.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
              orderedList: {
                    title: 'Ordered list',
                    image: '<img src="images/wysiwyg/ordlist.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                },
                unorderedList: {
                    title: 'Unordered list',
                    image: '<img src="images/wysiwyg/unordlist.png" width="16" height="16" alt="" />',  
                    showselection: false    // wanted on selection
                }, 
                header: {
                    title: 'Header',
                    image: '<img src="images/wysiwyg/header.png" width="16" height="16" alt="" />',  
                    popup: function( $popup, $button ) {
                            var list_headers = {
                                    // Name : Font
                                    'Header 1'     : '<h1>',
                                    'Header 2'     : '<h2>',
                                    'Header 3'     : '<h3>',
                                    'Header 4'     : '<h4>',
                                    'Header 5'     : '<h5>',
                                    'Header 6'     : '<h6>',
                                    'Preformatted' : '<pre>'
                                };
                            var $list = $('<div/>').addClass('wysiwyg-toolbar-list')
                                                   .attr('unselectable','on');
                            $.each( list_headers, function( name, format ){
                                var $link = $('<a/>').attr('href','#')
                                                     .css( 'font-family', format )
                                                     .html( name )
                                                     .click(function(event){
                                                        $(element).wysiwyg('shell').format(format).closePopup();
                                                        // prevent link-href-#
                                                        event.stopPropagation();
                                                        event.preventDefault();
                                                        return false;
                                                    });
                                $list.append( $link );
                            });
                            $popup.append( $list );
                           },
                    showselection: false    // wanted on selection
                },
                removeformat: {
                    title: 'Remove format',
                    image: '<img src="images/wysiwyg/noedit.png" width="16" height="16" alt="" />', 
					showselection: true
                }
            },
        })
      /*  .change(function(){
            if( typeof console != 'undefined' )
                console.log( 'change' );
        })
        .focus(function(){
            if( typeof console != 'undefined' )
                console.log( 'focus' );
        })
        .blur(function(){
            if( typeof console != 'undefined' )
                console.log( 'blur' );
        })*/;
			
}
/* ------------------ WYSIWYG Editor Enable END --------------*/

/* ----------------- Sprint Edit ---------------------------------*/

function loadAgileNodeData(node_ID, action) {

	$('#prnt-available-hrs, #gnt-available-hrs, #tsk-available-hrs').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "agile-node-load", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_an) {
			//alert(action + '--' + response_an);
			$('#prnt-available-hrs, #gnt-available-hrs, #tsk-available-hrs').removeClass('populate_loading');
			response_an = $.parseJSON(response_an);
			par_available = response_an["parent-available"];
			task_budget = response_an["task-budget"];
			task_allotted = response_an["work-alloted"];
			task_picked = response_an["work-picked"];
			
			var max_release = task_budget;
			if (task_allotted < max_release) max_release = task_allotted;
			
			$('#gnt-work-contour option[value='+ response_an["work-contour"] +']').attr("selected","selected");
			$('#prnt-budget-hrs').val(response_an["parent-budget"].toFixed(2));
			$('#prnt-available-hrs').val(par_available.toFixed(2));
			$('#gnt-available-hrs').val(task_budget.toFixed(2));
			$('#tsk-available-hrs').val((task_budget - task_allotted).toFixed(2));
			
			if (action == 'editsprint') {
				$("#gnt-sprint-status  option[value="+ response_an['sprint-status'] +"]").attr("selected", "selected");
				//$("#gnt-sprint-sp-compl").spinner({min: 0, max: max_release, decimals: 2, stepping: 0.25}).val(parseFloat(response_an["sprint-release-sp"]));
				
				Story_release_sps = response_an["stories-sprint"];
				$("#gnt_sprint_sp_compl").append($("<option></option>").attr("value","").text(""));
				if (Story_release_sps.length > 0) {
					for(ij = 0; ij< Story_release_sps.length; ij++) {
						$("#gnt_sprint_sp_compl").append($("<option></option>").attr("value",Story_release_sps[ij]['node-id']).text(Story_release_sps[ij]['node-name']));				
					};
				};
				$("#gnt_sprint_sp_compl").multiSelect({selectAll: false, 
												listHeight: 150, 
												noneSelected: "Select Story(s)", 
												oneOrMoreSelected: '% Story(s) Selected',
												spanWidth: 170, 
												optWidth: 220, 
												resultFld: "gnt_sprint_sp_compl_list"},
												function(el) {
													//alert('here');
													var numStories = $('[name^="rate_"]').length;
													if (numStories != 0) {
														var stry_id = [];
														var release_sp = [];
														$('[name^="rate_"]').each(function() {
																		stry_id.push($(this).attr("id").replace(/[^0-9]/g, ''));
																		release_sp.push($(this).val());
														});	
													} 
													
													$("#spr_story_release_sps").empty();
													var selectStrys = $("#gnt_sprint_sp_compl_list").val().split(",");
													//alert($("#gnt_sprint_sp_compl_list").val().length);
													if ($("#gnt_sprint_sp_compl_list").val().length == 0) {
														$("#spr_story_release_sps").empty();
														return false;
													}
													
													var tbl = $('<table></table>').attr("id","story_releases").attr("class", "rate_table").css("width","96%");
													var row = $('<tr style="font-size: 80%;"></tr>').appendTo(tbl);
													$('<th></th>').css("width","70%").attr("class", "colRes").text("Story Title").appendTo(row);
													$('<th></th>').css("width","30%").text("Released Story Points").appendTo(row);
													var toglClass = 'normal';
													for(i=0; i<selectStrys.length; i++) {
														var indStory = selectStrys[i].split("~");
														var spsSty = getDBStoryReleases(indStory[0]);
														toglClass=(toglClass=='normal')?'odd':'normal';
														row = $('<tr></tr>').attr("class", toglClass).appendTo(tbl);
														$('<td></td>').attr("class", "colRes").attr("class", toglClass).text(indStory[1]).appendTo(row);
														if (numStories != 0) {
															for (j=0; j<stry_id.length; j++) {
																if (indStory[0] == stry_id[j]) {
																	spsSty = release_sp[j];
																	break;
																}
															}
														}  
														$('<td></td>').text('').prepend($("<input type='text'/>").attr("id","rate_"+indStory[0]).attr("name","rate_"+indStory[0]).val(spsSty).css("float","center")).appendTo(row);
													} 
													tbl.appendTo($("#spr_story_release_sps")); 
													for(i=0; i<selectStrys.length; i++) {
														var indStory = selectStrys[i].split("~");
														$("#rate_"+indStory[0]).spinner({decimals:2, min: 0.00, max: getDBStoryBudget(parseInt(indStory[0])), stepping: 0.25});
													} 
												}); 
												
				if (parseInt(response_an["sprint-status"]) >= 2) $('#gnt-sprint-sp-compl-div').css('display', 'block');
					else $('#gnt-sprint-sp-compl-div').css('display', 'none');
												
												
			}
			
			
			
			var max_percent = 100 - ((response_an["parent-budget"] - (par_available + task_budget)) / response_an["parent-budget"] * 100);
			if ($('#gnt-work-contour').val() == 'P') $("#gnt-work-rate").spinner( "option", "max", max_percent ).spinner( "option", "stepping", 1 ).val(response_an["work-rate"]);
				else $("#gnt-work-rate").spinner( "option", "max", par_available + task_budget).spinner( "option", "stepping", 0.25 ).val(response_an["work-rate"]);
			
			$("#gnt-work-rate").on( "spinchange", function( event, ui ) { 
				if ($("#gnt-work-contour").val() == "P") { 
					var act_with_parent = par_available + task_budget;
					var act_work_rate = parseFloat($("#prnt-budget-hrs").val().replace(/[^0-9\-\.]/g, '')) * parseFloat($("#gnt-work-rate").val().replace(/[^0-9\-\.]/g, '')) / 100;
					$("#gnt-available-hrs").val(parseFloat(act_work_rate).toFixed(2));
					var available_with_par = act_with_parent - act_work_rate;
					$("#prnt-available-hrs").val(available_with_par.toFixed(2));
				} else {
					$("#gnt-available-hrs").val(parseFloat($("#gnt-work-rate").val().replace(/[^0-9\-\.]/g, '')).toFixed(2));
					$("#prnt-available-hrs").val((par_available + task_budget - parseFloat($("#gnt-work-rate").val().replace(/[^0-9\-\.]/g, ''))).toFixed(2));
				}
				$("#tsk-available-hrs").val((parseFloat($("#gnt-available-hrs").val()) - task_allotted).toFixed(2));
			});
			
			$('#gnt-work-contour').change(function() {
				if ($('#gnt-work-contour').val() == 'P') {
					$("#gnt-work-rate").spinner( "option", "max", max_percent ).spinner( "option", "stepping", 1 ).val(0);
				} else {
					$("#gnt-work-rate").spinner( "option", "max", par_available + task_budget).spinner( "option", "stepping", 0.25 ).val(0);
					
				}
				$("#prnt-available-hrs").val((par_available + task_budget).toFixed(2));
				$("#gnt-available-hrs").val(0);
				$("#tsk-available-hrs").val((parseFloat($("#gnt-available-hrs").val()) - task_allotted).toFixed(2));
			});	
			
			
		}
	});
}

function getDBStoryReleases(story_ID) {
	var spsSty = "0.00";
	if (Story_release_sps.length > 0) {
		for(ij = 0; ij< Story_release_sps.length; ij++) {
			if (Story_release_sps[ij]['node-id'] == story_ID) {
				spsSty = Story_release_sps[ij]['node-release'].toFixed(2);
				break;
			}
		};
	};
	return spsSty;
}

function getDBStoryBudget(story_ID) {
	var spsSty = "0.00";
	if (Story_release_sps.length > 0) {
		for(ij = 0; ij< Story_release_sps.length; ij++) {
			if (Story_release_sps[ij]['node-id'] == story_ID) {
				spsSty = Story_release_sps[ij]['node-budget'].toFixed(2);
				break;
			}
		};
	};
	return spsSty;
}

function packStoryReleases() {
	var selectStrys = $("#gnt_sprint_sp_compl_list").val().split(",");
	
	var stry_id = [];
	var release_sp = [];
	$('[name^="rate_"]').each(function() {
					stry_id.push($(this).attr("id").replace(/[^0-9]/g, ''));
					release_sp.push($(this).val());
	});	

	var strRels_str = '';
	if ($('[name^="rate_"]').length > 0) {
		for(i=0; i<selectStrys.length; i++){
			strRels_str += stry_id[i]+'*!*'+release_sp[i];
			if (i < selectStrys.length - 1) strRels_str += '*$*';
		}
	}
	//alert('ResPack'+strRels_str+'dss');
	return strRels_str;
}


/* ------------- Sprint Edit ----------------------    */
function scriptSprintEdit(action, node_ID) {
	//$("#gFform_sav, #gFform_del").attr("disabled","disabled"); 
	selNodeID = node_ID;
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	var NodeInfo = getNodeInfo(node_ID);
	
	loadAgileNodeData(selNodeID, action);	
	
	if (selNodeData != '') {
		switch(selNodeData){ 
			case "Notes": {
				$("#tab_general").trigger("click");
				break;
			}
			case "ID": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Tasks": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Cost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "Progress": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Work": {
				$("#tab_resources").trigger("click");
				break;
			}
			case "FixedCost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "CtrlAccnt": {
				$("#tab_cost").trigger("click");
				break;
			}
			default:
				$("#tab_general").trigger("click");
				break;			
		}
	
	}
	
	if (NodeInfo["grptask"] == 1) {
		$('#chkgnt-Work-Dur-lbl, #gnt-Work-Dur').css("display", "none");
	}
	
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Change Request Details:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
		
	hide_message_box("gntFl-message-box");
	$("#constraint-box").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(Task: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	$('#gntNode-name-dyn').val(getNodeName(node_ID)).autocomplete("phpAutocomplete.php", {
		width: $('#gntNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "project",
		entity: "sprint"+"^^"+$('#gantt-select-devp').val()
	});	
	
	if (parseInt(NodeInfo["rTask"]) == 1) {
		$("#chkgnt-milestone-lbl").text("Recurring Task:");
		$('#gnt-milestone').attr('checked', 'checked');
	} else {
		$("#chkgnt-milestone-lbl").text("Milestone:");
		if (parseInt(NodeInfo["milestone"]) == 1) $('#gnt-milestone').attr('checked', 'checked');
			else $('#gnt-milestone').removeAttr('checked');
	}
	
	$('#gnt-task-notes').val(NodeInfo["notes-desc"]);
	
	$("#gnt-sprint-status").change(function () {
		var isComplete = parseInt($('#gnt-sprint-status').val());
		if (isComplete >= 2) $('#gnt-sprint-sp-compl-div').css('display', 'block');
			else {
				$('#gnt-sprint-sp-compl-div').css('display', 'none');
				//$('#gnt-sprint-sp-compl').val(0);
			};
		if (isComplete == 1) $('#gnt-Updt-Allow').attr('checked', 'checked');
			else $('#gnt-Updt-Allow').removeAttr('checked');
	});
	
	
	
	
	if (parseInt(NodeInfo["delivs"]) == 1) $('#gnt-deliverables').attr('checked', 'checked');
		else $('#gnt-deliverables').removeAttr('checked');
		
	if (parseInt(NodeInfo["reviews"]) == 1) $('#gnt-reviews').attr('checked', 'checked');
		else $('#gnt-reviews').removeAttr('checked');
		
	if (parseInt(NodeInfo["meetings"]) == 1) $('#gnt-Meetings').attr('checked', 'checked');
		else $('#gnt-Meetings').removeAttr('checked');
		
	if (parseInt(NodeInfo["reports"]) == 1) $('#gnt-Reports').attr('checked', 'checked');
		else $('#gnt-Reports').removeAttr('checked');
		

	if (parseInt(NodeInfo["sCday"]) == 0) $('#gnt-display-day').attr('checked', 'checked');
		else $('#gnt-display-day').removeAttr('checked');
	
		sprStartDate = getNodeStart(node_ID);
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) {
		prStDte = tranformDate(prjStartDt);
		sprStartDate = tranformDate(sprStartDate);
	} else {
		prStDte = prjStartDt;
	}	
	
	
	
	$('#gnt-start-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			//if ($("#gnt-task-type").val() != "2"){
				if ($('#gnt-start-date').val() == '') {
					$('#gnt-start-date').datepick('option', {defaultDate: prStDte}).val(prStDte);
				}
				updtEndDate();  // Only if Activity and Milestone
				$('#gnt-task-constrain option[value="2"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-start-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
			//}	
		},
		showTrigger: '#calImg-stDate'}).datepick('option', {defaultDate: sprStartDate}).val(sprStartDate);	
	
	$("#gnt-duration").spinner({min: 1, max: 365}).val(NodeInfo["duration"]); 
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	var sprEnDte = $('#gnt-start-date').val();
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var sprEdDte = tranformDate(sprEnDte);
		else var sprEdDte = sprEnDte;
	if(isChecked) {
		sprEnDte = getEndDate(sprEdDte, prjSprDur);
	} else {
		sprEnDte = getCalEndDate(sprEdDte, prjSprDur);
	}
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) sprEnDte = tranformDate(sprEnDte);
	
	
	$('#gnt-end-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-end-date').val() == '') {
				updtEndDate(); 
			}
				updtDuration();  // Only if Activity
				updtWorkDur();
				$('#gnt-task-constrain option[value="5"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-end-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
				if ($('#gnt-constrain-date').val() != '') setStartEndDates(); //  Check putting this here
		},
		showTrigger: '#calImg-enDate'}).datepick('option', {defaultDate: sprEnDte}).datepick('disable').addClass('disabled_fld').val(sprEnDte);
		
		
	// Only if Activity	
	$("#gnt-display-day").change(function(){	
			var prEnDte = $('#gnt-start-date').val();
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prEdDte = tranformDate(prEnDte);
				else var prEdDte = prEnDte;
			var isChecked = $('#gnt-display-day').attr('checked')?true:false;
			if(isChecked) {
				prEnDte = getEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			} else {
				prEnDte = getCalEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			}
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prEnDte = tranformDate(prEnDte);
			$('#gnt-end-date').datepick('option', {defaultDate: prEnDte}).val(prEnDte);
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
	});	
	
	$("#gnt-duration").on( "spinchange", function( event, ui ) { 
			updtEndDate(); 
			updtWorkDur();
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
	});
	
	// to here - Only if Activity
	var spr_velocity = 1;
	if (prjSp2Hrs > 0) spr_velocity = parseInt(NodeInfo["budget-work"]) / prjSp2Hrs;
	
	$("#gnt-sprint-velocity").spinner({min: 1, max: 1000}).val(spr_velocity);  
	$("#gnt-available-hrs").val((parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')) / prjSp2Hrs).toFixed(2));
	$("#tsk-available-hrs").val((parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')) - (parseFloat(NodeInfo["estimate-work"]) / prjSp2Hrs)).toFixed(2));
	
	$("#gnt-sprint-velocity").on( "spinchange", function( event, ui ) {
		$("#gnt-available-hrs").val((parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')) / prjSp2Hrs).toFixed(2));
		$("#tsk-available-hrs").val((parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')) - (parseFloat(NodeInfo["estimate-work"]) / prjSp2Hrs)).toFixed(2));
		// Change ==== 
		$("#tsk-available-hrs-lbl").text('Available Story Points (Approx.):');
	});

	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	$('#gnt-present-cost').val(NodeInfo["cost"]);
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ca) {
			$('#gnt-CA').removeClass('populate_loading');
			response_ca = $.parseJSON(response_ca);
			if (response_ca.length > 0) {
				for(ij = 0; ij< response_ca.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response_ca[ij]["value"]).text(response_ca[ij]["descr"]));
					if (response_ca[ij]["value"] == NodeInfo["ca"]) var selected_ca = response_ca[ij]["value"]; // value from previous ajax
				};
				$('#gnt-CA option[value='+ selected_ca +']').attr("selected","selected");
			};

		}
	});

	if (parseInt(NodeInfo["ot_allowance"]) == 1) $('#gnt-ot-allowance').attr('checked', 'checked');
		else $('#gnt-ot-allowance').removeAttr('checked');
		
		
	// Grid for fixed costs
	$("#flex-fixCost").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskFCLists}, 
			{name: 'Edit', bclass: 'edit flx-prjFFcTsk-edit', onpress : taskFCLists},
			{name: 'Delete', bclass: 'delete', onpress : taskFCLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Description', name : 'fc_description', isdefault: true}
			], 
		sortname: "fc_description",
		sortorder: "asc",
		usepager: true,
		title: 'Task Fixed Cost',
		useRp: true,
		onDoubleClick: '.flx-prjFFcTsk-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskfc",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
		

	if (parseInt(NodeInfo["work_dur_link"]) == 1) $('#gnt-Work-Dur').attr('checked', 'checked');
		else $('#gnt-Work-Dur').removeAttr('checked');
		
	$("#gnt-work").spinner({decimals:2, min: 0.00, stepping: 1.00}).spinner( "disable" ).val(NodeInfo["work"]); 
	
	if (prjAgility == 0) {
		// Grid for Predecessors
		$("#flex-task-predecessors").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Predecessor', name : 'task_node_pid', width : 360, sortable : true, align: 'left'},
				{display: 'Relation', name : ' 	task_pred_rel', width : 160, sortable : true, align: 'center'},
				{display: 'Delay Type', name : 'lag_lead', width : 160, sortable : true, align: 'center'},
				{display: 'Days', name : 'll_days', width : 120, sortable : true, align: 'right'}
				],
			buttons : [
				{name: 'Add', bclass: 'add', onpress : taskPredsLists}, 
				{name: 'Edit', bclass: 'edit flx-prjPPredTsk-edit', onpress : taskPredsLists},
				{name: 'Delete', bclass: 'delete', onpress : taskPredsLists},
				{separator: true}
				],
			sortname: "task_node_pid",
			sortorder: "asc",
			usepager: true,
			title: 'Task Predecessors',
			useRp: true,
			onDoubleClick: '.flx-prjPPredTsk-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			
			singleSelect: true,
			appPage: "project-taskpreds",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID
		}); 
	}
	var WH_display = 'Work Hours';
	if (prjAgility == 1) WH_display = 'Story Points';
	
	// Grid for Resources
	$("#flex-task-resources").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Name', name : 'resource_id', width : 360, sortable : true, align: 'left'},
			{display: 'Work Contour', name : 'work_mode', width : 160, sortable : true, align: 'center'},
			{display: 'Work Rate', name : 'work_rate', width : 100, sortable : true, align: 'center'},
			{display: WH_display, name : 'resource_hours', width : 120, sortable : true, align: 'right'},
			{display: 'Cost', name : 'resource_cost', width : 175, sortable : true, align: 'right'},
			{display: 'Progress', name : 'resource_earned_work', width : 100, sortable : true, align: 'right'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskResLists}, 
			{name: 'Edit', bclass: 'edit flx-prjRresTsk-edit', onpress : taskResLists},
			{name: 'Delete', bclass: 'delete', onpress : taskResLists},
			{separator: true}
			],
		sortname: "resource_id",
		sortorder: "asc",
		usepager: true,
		title: 'Task Resources',
		useRp: true,
		onDoubleClick: '.flx-prjRresTsk-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskresorce",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	$("#gnt-ot-hours").spinner({min: 0, max: (24 - hoursAday)}).val(NodeInfo["ot_hours"]);
	
	// Only if Activity
	$("#gnt-work, #gnt-ot-hours").focusout(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) {
			var MinDur=(getMinDuration()>= 1 )?getMinDuration():1;
			$("#gnt-duration").val(MinDur);
			updtEndDate();
			updtWorkDur();
		}
	});
	
	$("#gnt-Work-Dur").change(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (isChecked == true) $('#gnt-work').trigger('focusout');
	});
	// to here - Only if Activity  
	
	$("#gnt-priority").spinner({min: 0, max: 999}).val(NodeInfo["priorty"]);	
	$('#gnt-task-constrain option[value='+ NodeInfo["constrnt"] +']').attr("selected","selected");
	
	$("#gnt-task-constrain").change(function () {
		$('#gnt-constrain-date').val('');
		if ($(this).val() == "0") {
			$('#gTaskConstain').css("display", "none");
			$("#constraint-box").css("display", "none");
			$('#gnt-constrain-date').val('');
			var prStrDte = prjStartDt;
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStrDte = tranformDate(prjStartDt);
			$('#gnt-start-date').datepick('option', {defaultDate: prStrDte}).val(prStrDte);
			updtEndDate();
		}  else $('#gTaskConstain').css("display", "block");
		if ($('#gnt-constrain-date').val() != '') {
			$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
			$("#constraint-box").css("display", "block");
		} else $("#constraint-box").css("display", "none");	
	});

	$('#gnt-constrain-date').datepick({
		renderer: $.extend({}, $.datepick.defaultRenderer),   // {picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: true,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-constrain-date').val() != '') {
				$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
				$("#constraint-box").css("display", "block");
				setStartEndDates();
			} else $("#constraint-box").css("display", "none");
		},
		showTrigger: '#calImg-conDate'});	
		
	if ($('#gnt-task-constrain').val() == "0") {
		$('#gTaskConstain').css("display", "none");
		$("#constraint-box").css("display", "none");
		$('#gnt-constrain-date').val('');
	}  else {
		$('#gTaskConstain').css("display", "block");
		$('#gnt-constrain-date').datepick('option', {defaultDate: pConstDate}).val(pConstDate);
		$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
		$("#constraint-box").css("display", "block"); 
	}	
		
	$("#gnt-wrTolerance").spinner({min: -100, max: 200}).val(NodeInfo["wr_tolerance"]);	
	if (parseInt(NodeInfo["wr_tolerance"]) != 0) {
		$('.rStar').css('visibility', 'visible');
		$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
	} else {
		$('.rStar').css('visibility', 'hidden');
		$('#gnt-wrTolerance-desc').removeAttr('placeholder');
	}	
	$('#gnt-wrTolerance-desc').val(NodeInfo["tolerance-desc"]);
	
	$("#gnt-wrTolerance").on( "spinchange", function( event, ui ) { 
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$('.rStar').css('visibility', 'visible');
			$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
		} else {
			$('.rStar').css('visibility', 'hidden');
			$('#gnt-wrTolerance-desc').removeAttr('placeholder');
		}	
	});

	if (parseInt(NodeInfo["update_allow"]) == 1) $('#gnt-Updt-Allow').attr('checked', 'checked');
		else $('#gnt-Updt-Allow').removeAttr('checked');
	
	$("#gnt-ot-allowance").change(function () {
		updtskWorkCost();
	});

	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	
	$("#flex-task-documents").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Delete', bclass: 'delete', onpress : taskDelivLists},
			{name: 'Download', bclass: 'download', onpress : taskDelivLists},
			{name: 'View', bclass: 'view flx-prjDDocTsk-vw', onpress : taskDelivLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: false,
		title: 'Task Deliverables',
		useRp: false,
		onDoubleClick: '.flx-prjDDocTsk-vw',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskdelivs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	

	selNodeType = '';
	return true;
}

/* ----------------- END of Sprint Edit & Start of Task Edit ----------------------------------- */

function scriptTaskEdit(action, node_ID) {
	//$("#gFform_sav, #gFform_del").attr("disabled","disabled"); 
	selNodeID = node_ID;
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	var NodeInfo = getNodeInfo(node_ID);
	if ((user_profile == 'stake') || (user_profile == 'proposal')) $(".comp_internal").css("display", "none");
		else $(".comp_internal").css("display", "block");
	//alert(NodeInfo["story-active"]);
	switch(selNodeType){ 
		case "root": {
			$("#tab_dates, #tab_predecessor, #tab_advanced").css("display", "none");
			$("#chkgnt-milestone-lbl, #gnt-milestone, #chkgnt-deliverables-lbl, #gnt-deliverables, #gTaskRecur").css("display", "none");
			break;
		}
		case "nTask": {
			if (prjAgility == 0) {
				if (NodeInfo["grptask"] == 1) {
					$("#gnt-task-constrain option[value='1']").remove();
					$("#gnt-task-constrain option[value='3']").remove();
					$("#gnt-task-constrain option[value='4']").remove();
					$("#gnt-task-constrain option[value='5']").remove();
					$("#gnt-task-constrain option[value='6']").remove();
				}
				$("#gTaskRecur").css("display", "none");
				$("#gTaskInactive").css("display", "block");
			} else {
				// Load data from database
				
				loadAgileNodeData(selNodeID, action);
			}
			break;
		}
		case "rMlTask": {
			$("#gTaskRecur").css("display", "none");
			break;
		}
		case "rgTask": {
			$("#tab_dates, #tab_predecessor, #tab_advanced, #gTaskNonRecur, #gTaskRecur").css("display", "none");
			$("#gTaskInactive").css("display", "block");
			break;
		}
		case "rtTask": {
			$("#tab_dates, #tab_predecessor, #tab_advanced, #gTaskNonRecur").css("display", "none");
			$("#gTaskRecur, #gTaskInactive").css("display", "block");
			break;
		}
	}
	
	if (selNodeData != '') {
		switch(selNodeData){ 
			case "Notes": {
				$("#tab_general").trigger("click");
				break;
			}
			case "ID": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Tasks": {
				$("#tab_general").trigger("click");
				break;
			}
			case "Resource": {
				$("#tab_resources").trigger("click");
				break;
			}
			case "Cost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "Duration": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_dates").trigger("click");
				break;
			}
			case "Progress": {
				$("#tab_general").trigger("click");
				break;
			}
			case "StartDate": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_dates").trigger("click");
				break;
			}
			case "EndDate": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_dates").trigger("click");
				break;
			}
			case "Predecessor": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_predecessor").trigger("click");
				break;
			}
			case "Work": {
				$("#tab_resources").trigger("click");
				break;
			}
			case "Constraints": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_advanced").trigger("click");
				break;
			}
			case "Priority": {
				if ((selNodeType =='root') || (selNodeType =='rgTask') || (selNodeType =='rtTask')) $("#tab_general").trigger("click");
					else $("#tab_advanced").trigger("click");
				break;
			}
			case "FixedCost": {
				$("#tab_cost").trigger("click");
				break;
			}
			case "CtrlAccnt": {
				$("#tab_cost").trigger("click");
				break;
			}
			default:
				$("#tab_general").trigger("click");
				break;			
			
			
			
			
			
			
			
			
			
			
		}
	
	}
	
	if (NodeInfo["grptask"] == 1) {
		$('#chkgnt-Work-Dur-lbl, #gnt-Work-Dur').css("display", "none");
	}
	if (NodeInfo["story-active"] != 2) $('#gnt-inactive').attr("checked", "checked");
		else $('#gnt-inactive').removeAttr("checked");
	
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Change Request Details:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
		//alert($("#gnt-notes-lbl").css("font-size"));
	hide_message_box("gntFl-message-box");
	$("#constraint-box").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(Task: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	$('#gntNode-name-dyn').val(getNodeName(node_ID)).autocomplete("phpAutocomplete.php", {
		width: $('#gntNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "project",
		entity: "task"+"^^"+$('#gantt-select-devp').val()
	});	
	
	
	if (parseInt(NodeInfo["rTask"]) == 1) {
		$("#chkgnt-milestone-lbl").text("Recurring Task:");
		$('#gnt-milestone').attr('checked', 'checked');
	} else {
		$("#chkgnt-milestone-lbl").text("Milestone:");
		if (parseInt(NodeInfo["milestone"]) == 1) $('#gnt-milestone').attr('checked', 'checked');
			else $('#gnt-milestone').removeAttr('checked');
	}
	
	$('#gnt-task-notes').val(NodeInfo["notes-desc"]);
	
	if (parseInt(NodeInfo["delivs"]) == 1) $('#gnt-deliverables').attr('checked', 'checked');
		else $('#gnt-deliverables').removeAttr('checked');
		
	if (parseInt(NodeInfo["reviews"]) == 1) $('#gnt-reviews').attr('checked', 'checked');
		else $('#gnt-reviews').removeAttr('checked');
		
	if (parseInt(NodeInfo["meetings"]) == 1) $('#gnt-Meetings').attr('checked', 'checked');
		else $('#gnt-Meetings').removeAttr('checked');
		
	if (parseInt(NodeInfo["reports"]) == 1) $('#gnt-Reports').attr('checked', 'checked');
		else $('#gnt-Reports').removeAttr('checked');
		

	if (parseInt(NodeInfo["sCday"]) == 0) $('#gnt-display-day').attr('checked', 'checked');
		else $('#gnt-display-day').removeAttr('checked');
	
	var prStDte = '';
	var pStrtDat = NodeInfo["startdate"];
	var pEndDat = NodeInfo["enddate"];
	var pConstDat = NodeInfo["constdate"];
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) {
		prStDte = tranformDate(prjStartDt);
		pStartDate = tranformDate(pStrtDat);
		pEndDate = tranformDate(pEndDat);
		pConstDate = tranformDate(pConstDat);
	} else {
		prStDte = prjStartDt;
		pStartDate = pStrtDat;
		pEndDate = pEndDat;
		pConstDate = pConstDat;
	}	
	
	
	
	$('#gnt-start-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			//if ($("#gnt-task-type").val() != "2"){
				if ($('#gnt-start-date').val() == '') {
					$('#gnt-start-date').datepick('option', {defaultDate: prStDte}).val(prStDte);
				}
				updtEndDate();  // Only if Activity and Milestone
				$('#gnt-task-constrain option[value="2"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-start-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
					$("#constraint-box").css("display", "block");
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
			//}	
		},
		showTrigger: '#calImg-stDate'}).datepick('option', {defaultDate: pStartDate}).val(pStartDate);	
	
	$("#gnt-duration").spinner({min: 1, max: 365});  
	
	$('#gnt-end-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-end-date').val() == '') {
				updtEndDate(); 
			}
				updtDuration();  // Only if Activity
				updtWorkDur();
				$('#gnt-task-constrain option[value="5"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-end-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
					$("#constraint-box").css("display", "block");
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
				if ($('#gnt-constrain-date').val() != '') setStartEndDates(); //  Check putting this here
		},
		showTrigger: '#calImg-enDate'}).datepick('option', {defaultDate: pEndDate}).val(pEndDate);
		
	if ((NodeInfo["milestone"] == '1') || (NodeInfo["grptask"] == '1')){           // Disable Spin and set value 1 if Milestone
			$("#gnt-duration").spinner( "disable" ).val(NodeInfo["duration"]);
			updtEndDate(); 
			$('#gnt-end-date').datepick('disable').addClass('disabled_fld');
	} else {
		$("#gnt-duration").spinner( "enable" ).val(NodeInfo["duration"]);	
		$('#gnt-end-date').datepick('enable').removeClass('disabled_fld');
	}	
		
		
	// Only if Activity	
	$("#gnt-display-day").change(function(){	
			var prEnDte = $('#gnt-start-date').val();
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prEdDte = tranformDate(prEnDte);
				else var prEdDte = prEnDte;
			var isChecked = $('#gnt-display-day').attr('checked')?true:false;
			if(isChecked) {
				prEnDte = getEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			} else {
				prEnDte = getCalEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			}
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prEnDte = tranformDate(prEnDte);
			$('#gnt-end-date').datepick('option', {defaultDate: prEnDte}).val(prEnDte);
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
	});	
	
	$("#gnt-duration").on( "spinchange", function( event, ui ) { 
			updtEndDate(); 
			updtWorkDur();
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
	});
	
	// to here - Only if Activity

	if (prjAgility == 1) $("#gnt-work-rate").spinner({max: 100, decimals:2, min: 0.00, stepping: 1.00});
	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	$('#gnt-present-cost').val(NodeInfo["cost"]);
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ca) {
			$('#gnt-CA').removeClass('populate_loading');
			response_ca = $.parseJSON(response_ca);
			if (response_ca.length > 0) {
				for(ij = 0; ij< response_ca.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response_ca[ij]["value"]).text(response_ca[ij]["descr"]));
					if (response_ca[ij]["value"] == NodeInfo["ca"]) var selected_ca = response_ca[ij]["value"]; // value from previous ajax
				};
				$('#gnt-CA option[value='+ selected_ca +']').attr("selected","selected");
			};

		}
	});

	if (parseInt(NodeInfo["ot_allowance"]) == 1) $('#gnt-ot-allowance').attr('checked', 'checked');
		else $('#gnt-ot-allowance').removeAttr('checked');
		
		
	// Grid for fixed costs
	$("#flex-fixCost").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskFCLists}, 
			{name: 'Edit', bclass: 'edit flx-prjFCTsk-edit', onpress : taskFCLists},
			{name: 'Delete', bclass: 'delete', onpress : taskFCLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Description', name : 'fc_description', isdefault: true}
			], 
		sortname: "fc_description",
		sortorder: "asc",
		usepager: true,
		title: 'Task Fixed Cost',
		useRp: true,
		onDoubleClick: '.flx-prjFCTsk-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskfc",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
		

	if (parseInt(NodeInfo["work_dur_link"]) == 1) $('#gnt-Work-Dur').attr('checked', 'checked');
		else $('#gnt-Work-Dur').removeAttr('checked');
		
	$("#gnt-work").spinner({decimals:2, min: 0.00, stepping: 1.00}).spinner( "disable" ).val(NodeInfo["work"]); 
	
	if (prjAgility == 0) {
		// Grid for Predecessors
		$("#flex-task-predecessors").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Predecessor', name : 'task_node_pid', width : 360, sortable : true, align: 'left'},
				{display: 'Relation', name : ' 	task_pred_rel', width : 160, sortable : true, align: 'center'},
				{display: 'Delay Type', name : 'lag_lead', width : 160, sortable : true, align: 'center'},
				{display: 'Days', name : 'll_days', width : 120, sortable : true, align: 'right'}
				],
			buttons : [
				{name: 'Add', bclass: 'add', onpress : taskPredsLists}, 
				{name: 'Edit', bclass: 'edit flx-prjPredTsk-edit', onpress : taskPredsLists},
				{name: 'Delete', bclass: 'delete', onpress : taskPredsLists},
				{separator: true}
				],
			sortname: "task_node_pid",
			sortorder: "asc",
			usepager: true,
			title: 'Task Predecessors',
			useRp: true,
			onDoubleClick: '.flx-prjPredTsk-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			
			singleSelect: true,
			appPage: "project-taskpreds",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID
		}); 
	}
	var WH_display = 'Work Hours';
	if (prjAgility == 1) WH_display = 'Story Points';
	
	// Grid for Resources
	$("#flex-task-resources").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Name', name : 'resource_id', width : 340, sortable : true, align: 'left'},
			{display: 'Work Contour', name : 'work_mode', width : 160, sortable : true, align: 'center'},
			{display: 'Work Rate', name : 'work_rate', width : 120, sortable : true, align: 'center'},
			{display: WH_display, name : 'resource_hours', width : 120, sortable : true, align: 'right'},
			{display: 'Cost', name : 'resource_cost', width : 175, sortable : true, align: 'right'},
			{display: 'Progress', name : 'resource_earned_work', width : 100, sortable : true, align: 'right'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskResLists}, 
			{name: 'Edit', bclass: 'edit flx-prjResTsk-edit', onpress : taskResLists},
			{name: 'Delete', bclass: 'delete', onpress : taskResLists},
			{separator: true}
			],
		sortname: "resource_id",
		sortorder: "asc",
		usepager: true,
		title: 'Task Resources',
		useRp: true,
		onDoubleClick: '.flx-prjResTsk-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskresorce",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	$("#gnt-ot-hours").spinner({min: 0, max: (24 - hoursAday)}).val(NodeInfo["ot_hours"]);
	
	// Only if Activity
	$("#gnt-work, #gnt-ot-hours").focusout(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) {
			var MinDur=(getMinDuration()>= 1 )?getMinDuration():1;
			$("#gnt-duration").val(MinDur);
			updtEndDate();
			updtWorkDur();
		}
	});
	
	$("#gnt-Work-Dur").change(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (isChecked == true) $('#gnt-work').trigger('focusout');
	});
	// to here - Only if Activity  
	
	$("#gnt-priority").spinner({min: 0, max: 999}).val(NodeInfo["priorty"]);	
	$('#gnt-task-constrain option[value='+ NodeInfo["constrnt"] +']').attr("selected","selected");
	
	$("#gnt-task-constrain").change(function () {
		$('#gnt-constrain-date').val('');
		if ($(this).val() == "0") {
			$('#gTaskConstain').css("display", "none");
			$("#constraint-box").css("display", "none");
			$('#gnt-constrain-date').val('');
			var prStrDte = prjStartDt;
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStrDte = tranformDate(prjStartDt);
			$('#gnt-start-date').datepick('option', {defaultDate: prStrDte}).val(prStrDte);
			updtEndDate();
		}  else $('#gTaskConstain').css("display", "block");
		if ($('#gnt-constrain-date').val() != '') {
			$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
			$("#constraint-box").css("display", "block");
		} else $("#constraint-box").css("display", "none");	
	});

	$('#gnt-constrain-date').datepick({
		renderer: $.extend({}, $.datepick.defaultRenderer),   // {picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: true,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-constrain-date').val() != '') {
				$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
				$("#constraint-box").css("display", "block");
				setStartEndDates();
			} else $("#constraint-box").css("display", "none");
		},
		showTrigger: '#calImg-conDate'});	
		
	if ($('#gnt-task-constrain').val() == "0") {
		$('#gTaskConstain').css("display", "none");
		$("#constraint-box").css("display", "none");
		$('#gnt-constrain-date').val('');
	}  else {
		$('#gTaskConstain').css("display", "block");
		$('#gnt-constrain-date').datepick('option', {defaultDate: pConstDate}).val(pConstDate);
		$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
		$("#constraint-box").css("display", "block"); 
	}	
		
	$("#gnt-wrTolerance").spinner({min: -100, max: 200}).val(NodeInfo["wr_tolerance"]);	
	if (parseInt(NodeInfo["wr_tolerance"]) != 0) {
		$('.rStar').css('visibility', 'visible');
		$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
	} else {
		$('.rStar').css('visibility', 'hidden');
		$('#gnt-wrTolerance-desc').removeAttr('placeholder');
	}	
	$('#gnt-wrTolerance-desc').val(NodeInfo["tolerance-desc"]);
	
	$("#gnt-wrTolerance").on( "spinchange", function( event, ui ) { 
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$('.rStar').css('visibility', 'visible');
			$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
		} else {
			$('.rStar').css('visibility', 'hidden');
			$('#gnt-wrTolerance-desc').removeAttr('placeholder');
		}	
	});

	if (parseInt(NodeInfo["update_allow"]) == 1) $('#gnt-Updt-Allow').attr('checked', 'checked');
		else $('#gnt-Updt-Allow').removeAttr('checked');
	
	$("#gnt-ot-allowance").change(function () {
		updtskWorkCost();
	});

	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	
	$("#flex-task-documents").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Delete', bclass: 'delete', onpress : taskDelivLists},
			{name: 'Download', bclass: 'download', onpress : taskDelivLists},
			{name: 'View', bclass: 'view flx-prjDocTsk-vwe', onpress : taskDelivLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: false,
		title: 'Task Deliverables',
		useRp: false,
		onDoubleClick: '.flx-prjDocTsk-vwe',

		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskdelivs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	

	selNodeType = '';
	return true;
}

/* ----------------- Task Edit Grid Functions ------------------*/

function taskFCLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
					
						url: "phpGanttService.php",
						type: 'POST',
						data: {
							"page": 'gnt-task-fc-delete',
							"project-id": $('#gantt-select-devp').val(),
							"fc-uid": itemlist, 
							"user-id": user_id
						},
						success: function(response) {
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								jAlert(response[0][0].data['messg'],'E', function() {
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										//ProjAddReload(); 
										jQuery("#flex-fixCost").flexReload();
										loadProjectGantt('');
										/* var Node_Info = getNodeInfo(parseInt(response[0][0].data[0]['node-id']));
										alert(parseInt(response[0][0].data[0]['node-id'])+' - '+Node_Info["cost"]);
										$('#gnt-present-cost').val(Node_Info["cost"]); */
									});
								}  
							} else {
								jAlert(response[0][0].data['messg'],'E');
							}   // Change 
						}
					 }); 
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
		var NodeInfo = getNodeInfo(selNodeID);
		if (parseInt(NodeInfo["story-active"]) > 0) jAlert('<b><i>Task Inactive!</i></b> Cannot add Fixed Cost...','E');
			else {
				/* jConfirm('Add new Fixed Costs<b>?</b>', '', function(user_act) {
					if (user_act) { */
						jgSforms('GntTaskFCAdd', selNodeID,'Add Fixed Costs...');	
				/*	} else {
						return false;
					};
				}); */
			}	
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Edit Fixed Cost<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskFCEdit', itemlist,'Edit Task Fixed Cost...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    };
	return true;
}

function taskResLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
 
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {
							"page": 'gnt-task-res-delete',
							"project-id": $('#gantt-select-devp').val(),
							"node-id": selNodeID, 
							"resource-id": itemlist, 
							"user-id": user_id
						},
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							hide_message_box("gntSl-message-box");
							hide_upload_started();
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										//ProjAddReload(); 
										$.popgSLfrm._hide();
										if (prjAgility == 1) {
											$('#tsk-available-hrs').val((response[0][0].sp_available).toFixed(2));
											$("#tsk-available-hrs-lbl").text('Available Story Points:');
										}
										jQuery("#flex-task-resources").flexReload();
										loadProjectGantt('');
										/* var Node_Info = getNodeInfo(parseInt(response[0][0].data[0]['node-id']));
										alert(parseInt(response[0][0].data[0]['node-id'])+' - '+Node_Info["cost"]);
										$('#gnt-present-cost').val(Node_Info["cost"]); */
									});
								}  
							} else {
									jAlert(response[0][0].data[0]['messg'],'E');
							} 
						}
					});	
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
		var NodeInfo = getNodeInfo(selNodeID);
		if (parseInt(NodeInfo["story-active"]) > 0) jAlert('<b><i>Task Inactive!</i></b> Cannot add Resources...','E');
			else {
				/* jConfirm('Add new Resources to Task<b>?</b>', '', function(user_act) {
					if (user_act) { */
						jgIForms('GntTaskResAdd', selNodeID,'Add Resources...');	
				/*	} else {
						return false;
					};
				}); */
			}
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Edit Task Resource<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskResEdit', itemlist,'Edit Task Resource...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }; 
	return true;
}

function taskPredsLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {
							"page": 'gnt-task-pred-delete',
							"project-id": $('#gantt-select-devp').val(),
							"node-id": selNodeID, 
							"node-pid": itemlist, 
							"user-id": user_id
						},
						timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						}, 
						success: function(response) {
							hide_message_box("gntSl-message-box");
							hide_upload_started();
							response = $.parseJSON(response);
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								// --- check  and correct
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										//ProjAddReload(); 
										$.popgSLfrm._hide();
										jQuery("#flex-task-predecessors").flexReload();
										loadProjectGantt('');
										/* var Node_Info = getNodeInfo(parseInt(response[0][0].data[0]['node-id']));
										alert(parseInt(response[0][0].data[0]['node-id'])+' - '+Node_Info["cost"]);
										$('#gnt-present-cost').val(Node_Info["cost"]); */
									});
								}  
							} else {
									jAlert(response[0][0].data[0]['messg'],'E');
							} 
						}
					});	
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
		var NodeInfo = getNodeInfo(selNodeID);
		if (parseInt(NodeInfo["story-active"]) > 0) jAlert('<b><i>Task Inactive!</i></b> Cannot add Predecessors...','E');
			else {
				/* jConfirm('Add Predecessors<b>?</b>', '', function(user_act) {
					if (user_act) { */
						jgSforms('GntTaskPredAdd', selNodeID,'Add Predecessors...');	 
				/*	} else {
						return false;
					};
				}); */
			}	
    } else if (com=='Edit') {
		tab_toggler = true;
		var NodeInfo = getNodeInfo(selNodeID);
		if (parseInt(NodeInfo["story-active"]) > 0) jAlert('<b><i>Task Inactive!</i></b> Cannot edit Predecessors...','E');
			else {
				if ($('.trSelected',grid).length>0) {
						/*	jConfirm('Edit Task Predecessor<b>?</b>', '', function(user_act) {
								if (user_act) { */
									var items = $('.trSelected',grid);
									var itemlist =items[0].id.substr(3);
									jgSforms('GntTaskPredEdit', itemlist,'Edit Task Predecessor...');
							/*	} else {
									return false;
								};
							}); */
				} else {
					jAlert('Record NOT selected !', 'E');
				};
			}	
    };
	return true;	
}

function taskDelivLists(com,grid) {
    if (com=='Delete') {
		// alert('Delete Action');
		/* Adjusting the parameter */
		//jQuery('#flex-emp-docs-edit').flexOptions({fldSelect: 'xxxxx'});
		//jQuery("#flex-emp-docs-edit").flexReload(); 

		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist ='';
					 for(i=0;i<items.length;i++){
						itemlist+= items[i].id.substr(3)+",";
					} 
					$.ajax({
					   type: "POST",
					   url: "phpFlexService.php",
					   data: {"page": "gnt-task-deliv-delete", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					   	timeout: xhr_timeout * 10,
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						},
					   success: function(data){
						// alert(data);
						$("#flex-task-documents").flexReload();
					   }
					 }); 
				} else {
					return false;
				};
			});
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='Download') {
        //alert('Download Action');
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			 
			zipDownloader("gnt-task-deliv-dwl", $('#gantt-select-devp').val(), itemlist); 			 
			 
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='View') {
		if ($('.trSelected',grid).length>0) {  
			if ($('.trSelected',grid).length>1) { 
				jAlert('Too many documents selected! Select one...', 'E');	
			} else {
				var items = $('.trSelected',grid); 
				var itemlist ='';
				 for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3);
				} 
				//alert(itemlist);
				$.ajax({
				   type: "POST",
				   url: "phpFlexService.php",
				   data: {"page": "gnt-task-deliv-view", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					timeout: xhr_timeout * 10,
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					},
				   success: function(data){
						response = $.parseJSON(data); 
						var FileName = response[0]["file-to-view"].replace(/ /g, '%20');
						var FileMIME = response[0]["file-mime-type"];
						if(FileMIME != '') {
							var myWindow = window.open("","_blank","fullscreen=yes, location=no, menubar=no, toolbar=no");
							myWindow.document.write('<object data='+ FileName +' type='+ FileMIME +' width="100%" height="100%"><p>Cannot open the document directly.  <a href='+ FileName +'>Click here to download the file...</a></p></object>');
						} else jAlert('Unable to open the document...', 'E');
				   }
				 }); 
			}; 
		
		} else {
			jAlert('Document NOT selected !', 'E');
		}; 
    };
	return true;
}


/* ---------------- Submit edited task info -------------------*/

function submitTaskDelete(node_id) {
	jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
		if (user_act) {
			show_upload_started();
			$.ajax({
				url: "phpGanttService.php",
				type: 'POST',
				data: {"page": 'gnt-node-delete',
					   "project-id": $('#gantt-select-devp').val(), 
					   "node":node_id,
					   "user-id": user_id
				},
				timeout: xhr_timeout * 10,
				error: function () {
					hide_all_errors(); //
					hide_upload_started(); //
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					
					response = $.parseJSON(response); 
					if (response[0][0].status == "error") {
						hide_upload_started();
						hide_message_box("gntFl-message-box");
						jAlert(response[0][0].data['messg'],'E', function() {
								//$.popgFLfrm._hide();
								loadProjectGantt('');
						});
					} else if (response[0][0].status == "success") {
						hide_upload_started();
						if (response[0][0].data[0]['node-id'] != '-1') {
							jAlert(response[0][0].data[0]['messg'],'S',function() {
								loadProjectGantt('');
								$.popgFLfrm._hide();
							});
						} else {
							jAlert(response[0][0].data[0]['messg'],'E');
						}  
					}
				}
			});			
			
		} else {
			return false;
		};
	});
}

function submitTaskEdit(node_id) {
	empty_message_box("gntFl-message-box");
	var node_id = parseInt(node_id);
	show_upload_started();
	if (validateNodeEditDetails(node_id, 'edit') == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {
		 
		var deliverables = $('#gnt-deliverables').attr('checked')?1:0;
		var reviews = $('#gnt-reviews').attr('checked')?1:0;
		var meetings = $('#gnt-Meetings').attr('checked')?1:0;
		var reports = $('#gnt-Reports').attr('checked')?1:0;
		
		
		var day_display = $('#gnt-display-day').attr('checked')?0:1; // This is reverse in jsGantt if 1 Cal days
		var compute_ot = $('#gnt-ot-allowance').attr('checked')?1:0;
		var wrk_dur = $('#gnt-Work-Dur').attr('checked')?1:0;
		var updt_allow = $('#gnt-Updt-Allow').attr('checked')?1:0;
		
		if (prjAgility == 1) {
			var task_work_contour = $('#gnt-work-contour').val();
			var task_work_rate = parseFloat($('#gnt-work-rate').val().replace(/[^0-9\-\.]/g, ''));
			var task_alloted_work = parseFloat($('#gnt-available-hrs').val().replace(/[^0-9\-\.]/g, ''));
			var gnt_active = 0;
		} else {
			var task_work_contour = 'P';
			var task_work_rate = 0;
			var task_alloted_work = 0;
			var gnt_active = $('#gnt-inactive').attr('checked')?0:2;
		}
		
		//alert(node_id);
		$.ajax({
			url: "phpGanttService.php",
			type: 'POST',
			data: {
				"page": 'gnt-node-edit',
				"project-id": $('#gantt-select-devp').val(),
				"node-id": node_id, 
				"node-name": $('#gntNode-name-dyn').val(), 
				"node-notes": $('#gnt-task-notes').val(), 
				"task-type": $('#gnt-task-type').val(), 
				"deliverables": deliverables,
				"reviews": reviews,
				"gnt-active": gnt_active,
				"day-display": day_display,   //checkbox
				"start-date": $('#gnt-start-date').val(),
				"task-duration": $('#gnt-duration').val(), 
				"end-date": $('#gnt-end-date').val(),                      
				"res-var-costs": $('#gnt-resource-cost').val(),										
				"compute-ot": compute_ot,   //checkbox
				"task-CA": $('#gnt-CA').val(), 
				"work-duration-link": wrk_dur,        //checkbox
				"allowed-ot-hours": $('#gnt-ot-hours').val(), 	
				"task-work": $('#gnt-work').val(), 

				"task_priority": $('#gnt-priority').val(), 
				"task-constraint": $('#gnt-task-constrain').val(),  
				"task-contr-date": $('#gnt-constrain-date').val(),
				"work-ratio-tolerance": $('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, ''), 
				"work-ratio-tolerance-notes": $('#gnt-wrTolerance-desc').val(), 
				"update-permit": updt_allow,
				"meetings": meetings,
				"reports": reports,
				
				"task-work-contour": task_work_contour,
				"task-work-rate": task_work_rate,
				"task-alloted-work": task_alloted_work,
				
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				
				//alert(response);
			
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); Save the documents
							selNodeData = '';
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	}
	
	
	//alert(packFixedCost()); 
	//alert(packActResWork());
	//alert(submitType+' - '+$('#div-entity-id-edit').val());
}


function submitSprintEdit(node_id) {
	empty_message_box("gntFl-message-box");
	var node_id = parseInt(node_id);
	show_upload_started();
	if (validateNodeEditDetails(node_id, 'editsprint') == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {
		 
		var deliverables = $('#gnt-deliverables').attr('checked')?1:0;
		var reviews = $('#gnt-reviews').attr('checked')?1:0;
		var meetings = $('#gnt-Meetings').attr('checked')?1:0;
		var reports = $('#gnt-Reports').attr('checked')?1:0;
		
		var day_display = $('#gnt-display-day').attr('checked')?0:1; // This is reverse in jsGantt if 1 Cal days
		var compute_ot = $('#gnt-ot-allowance').attr('checked')?1:0;
		var wrk_dur = $('#gnt-Work-Dur').attr('checked')?1:0;
		var updt_allow = $('#gnt-Updt-Allow').attr('checked')?1:0;
		
		
		var sprint_status = parseInt($('#gnt-sprint-status').val());
		//var sprint_release = parseFloat($('#gnt-sprint-sp-compl').val().replace(/[^0-9\-\.]/g, ''));
		var sprint_velocity = parseFloat($('#gnt-sprint-velocity').val().replace(/[^0-9\-\.]/g, ''));
		/*
		
		
		Correct and proceed
		
		*/
		//alert(node_id);
		$.ajax({
			url: "phpAgileService.php",
			type: 'POST',
			data: {
				"page": 'sprint-node-edit',
				"project-id": $('#gantt-select-devp').val(),
				"node-id": node_id, 
				"node-name": $('#gntNode-name-dyn').val(), 
				"node-notes": $('#gnt-task-notes').val(), 
				"task-type": $('#gnt-task-type').val(), 
				"deliverables": deliverables,
				"reviews": reviews,
				"day-display": day_display,   //checkbox
				"start-date": $('#gnt-start-date').val(),
				"task-duration": $('#gnt-duration').val(), 
				"end-date": $('#gnt-end-date').val(),                      
				"res-var-costs": $('#gnt-resource-cost').val(),										
				"compute-ot": compute_ot,   //checkbox
				"task-CA": $('#gnt-CA').val(), 
				"work-duration-link": wrk_dur,        //checkbox
				"allowed-ot-hours": $('#gnt-ot-hours').val(), 	
				"task-work": $('#gnt-work').val(), 

				"task_priority": $('#gnt-priority').val(), 
				"task-constraint": $('#gnt-task-constrain').val(),  
				"task-contr-date": $('#gnt-constrain-date').val(),
				"work-ratio-tolerance": $('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, ''), 
				"work-ratio-tolerance-notes": $('#gnt-wrTolerance-desc').val(), 
				"update-permit": updt_allow,
				"meetings": meetings,
				"reports": reports,
				
				"sprint-status": sprint_status,
				"sprint-release": packStoryReleases(),
				"sprint-velocity": sprint_velocity,
				
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				
				//alert(response);
			
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); Save the documents
							selNodeData = '';
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	}
	
	
	//alert(packFixedCost()); 
	//alert(packActResWork());
	//alert(submitType+' - '+$('#div-entity-id-edit').val());
}



function validateNodeEditDetails(node_ID, submitType) {
	var ValidationStatus = true;
	var ValidStatus = [];
	var inp = '';
	
	var inp = $('#gntNode-name-dyn').val();
	if (inp.length > 0) {	
		MesgStrg = '';
		MesgStrg += validate({ 
				elem_id: 'gntNode-name-dyn',
				mn_length: 2,
				mx_length: 240,
				strg_type: 'atext',
				msg_type: 'mesg-box'
			});
		if (MesgStrg.length > 0) {
			ValidationStatus = false;
			$("#gntFl-message-box").append('<br/><p><b>New Task Name</b></p>').append(MesgStrg);
		}
	}
	if ((prjAudit == 1) && (prjStatus == 1)) {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Change Request Details</b></p>').append(MesgStrg);
			}		
	} else {
		var inp = $('#gnt-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
	}
	if (prjAgility == 0) {
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) == 0) {
			var inp = $('#gnt-wrTolerance-desc').val();
			if (inp.length > 0) {	
				MesgStrg = '';
				MesgStrg += validate({ 
						elem_id: 'gnt-wrTolerance-desc',
						mn_length: 2,
						mx_length: 300,
						strg_type: 'ctext',
						msg_type: 'mesg-box'
					});
				if (MesgStrg.length > 0) {
					ValidationStatus = false;
					$("#gntFl-message-box").append('<br/><p><b>Work Ratio Tolerance Basis</b></p>').append(MesgStrg);
				}		
			}
		} else {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-wrTolerance-desc',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Work Ratio Tolerance Basis</b></p>').append(MesgStrg);
			}		
		}
	}
	
	if (prjAgility == 1) {
		var nodeFixHrs = getNodeInfo(node_ID);
		if (submitType == 'editsprint') {
			if (parseFloat($('#gnt-sprint-velocity').val().replace(/[^0-9\-\.]/g, '')) <= 0) {
				$("#gntFl-message-box").append('<br/><p><b>Sprint Velocity</b></p>').append('<p>&#9830; Sprint Velocity not acceptable</p>');
				ValidationStatus = false;
			}	
		} else {
			if (parseFloat($('#prnt-available-hrs').val().replace(/[^0-9\-\.]/g, '')) < 0) {
				$("#gntFl-message-box").append('<br/><p><b>Task Work Allotment</b></p>').append('<p>&#9830; Task has been alloted with Story points greater than available</p>');	
				ValidationStatus = false;
			}
			/* if (parseFloat($('#tsk-available-hrs').val().replace(/[^0-9\-\.]/g, '')) < parseFloat(nodeFixHrs["estimate-fix"])) {
				$("#gntFl-message-box").append('<br/><p><b>Resource Work Allotment</b></p>').append('<p>&#9830; Resources have been alloted with Story points greater than available</p>');	
				ValidationStatus = false;
			} */
		}
	}
	
	
	if (ValidationStatus == false) {
		return false; 
	}; 
	return ValidationStatus;
	
}


/* ----------------- Story Pull and Insert ----------------- */

function scriptStoryPullIns(action, node_ID) {
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	var NodeInfo = getNodeInfo(node_ID);
	if (action == 'pullstory') $("#gnt-add-ins-lbl").text("Sprint Selected:");
		else if (action == 'insertstory') $("#gnt-add-ins-lbl").text("Story Selected to Insert at:");
		
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Notes:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
		
	hide_message_box("gntFl-message-box");
	//$("#constraint-box").css("display", "none");
	//$("#tab_predecessor").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(ID: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	
	// Grid for Backlog Stories selection
	$("#flex-baklogStory").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Story ID', name : 'story_number', width : 120, sortable : true, align: 'left'},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : true, align: 'left'},
			{display: 'Priority', name : 'node_priority', width : 120, sortable : false, align: 'left'},
			{display: 'Remaining Work', name : 'estimate_work_hours', width : 120, sortable : false, align: 'right'},
			{display: 'Sprint Volume', name : 'story_release_sp', width : 120, sortable : false, align: 'right'},
			{display: 'Notes', name : 'task_notes', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add flx-baksty-add', onpress : sprintPullStoryList},
			{separator: true}
			], 
		searchitems : [
			{display: 'Story ID', name : 'story_number', isdefault: true}
			], 
		sortname: "story_number",
		sortorder: "asc",
		usepager: true,
		title: 'Select Story:<span style="color: #cd1800;">&#42;</span>',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		singleSelect: true,
		btnShow: false,
		appPage: "project-sprintstory",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			$('#gnt-CA').removeClass('populate_loading');
			response = $.parseJSON(response);
			if (response.length > 0) {
				for(ij = 0; ij< response.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response[ij]["value"]).text(response[ij]["descr"]));
					if (response[ij]["project-main"] == '1') var proj_main = response[ij]["value"];
				};
				$('#gnt-CA option[value='+ proj_main +']').attr("selected","selected");
			};

		}
	});

	AddFixedCosts();

	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	return true;
}

function sprintPullStoryList(com,grid) {
    if (com=='Add') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist =items[0].id.substr(3);
			$('#selected_story_list').val(itemlist);
		} else $('#selected_story_list').val('');
	}
}	
/* ---------------- END of Story Pull and Insert ------------------- */






/* ----------------- Sprint Add and Insert ----------------- */

function scriptSprintAddIns(action, node_ID) {
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	var NodeInfo = getNodeInfo(node_ID);
	if (action == 'addsprint') $("#gnt-add-ins-lbl").text("Task Selected:");
		else if (action == 'insertsprint') $("#gnt-add-ins-lbl").text("Task Selected to Insert at:");
		
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Change Request Details:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
		
	hide_message_box("gntFl-message-box");
	$("#constraint-box").css("display", "none");
	$("#tab_predecessor").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(Task: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	
	$('#gntNode-name-dyn').autocomplete("phpAutocomplete.php", {
		width: $('#gntNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "project",
		entity: "sprint"+"^^"+$('#gantt-select-devp').val()
	});	
	
	$("#gnt-sprint-status").change(function () {
		var sprSts = parseInt($('#gnt-sprint-status').val());
		if (sprSts == 1) $('#gnt-Updt-Allow').attr('ckecked', 'ckecked');
			else $('#gnt-Updt-Allow').removeAttr('ckecked');
	});
	
	$("#gnt-duration").spinner({min: 1, max: 365}).val(prjSprDur);  
	if ($("#gnt-task-type").val() == "1") {           // Disable Spin and set value 1 if Milestone
			$("#gnt-duration").spinner( "disable" ).val(1);
			updtEndDate(); 
	} else $("#gnt-duration").spinner( "enable" );	
	
	var prStDte = '';
	var pStrtDat = getNodeStart(node_ID);	
	var pEndDat = getNodeEnd(1);
		sprStartDate = getEndDate(pEndDat, 2);
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) {
		prStDte = tranformDate(prjStartDt);
		sprStartDate = tranformDate(sprStartDate);
	} else {
		prStDte = prjStartDt;
	}	
	
	$('#gnt-start-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($("#gnt-task-type").val() != "2"){
				if ($('#gnt-start-date').val() == '') {
					$('#gnt-start-date').datepick('option', {defaultDate: prStDte}).val(prStDte);
				}
				updtEndDate();  // Only if Activity and Milestone
				$('#gnt-task-constrain option[value="2"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-start-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
			}	
		},
		showTrigger: '#calImg-stDate'}).datepick('option', {defaultDate: sprStartDate}).val(sprStartDate);	
	
	$('#gnt-task-constrain option[value="2"]').attr("selected","selected");
	$('#gnt-task-constrain').trigger('change');
	$('#gnt-constrain-date').val($('#gnt-start-date').val());


	
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	var sprEnDte = $('#gnt-start-date').val();
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var sprEdDte = tranformDate(sprEnDte);
		else var sprEdDte = sprEnDte;
	if(isChecked) {
		sprEnDte = getEndDate(sprEdDte, prjSprDur);
	} else {
		sprEnDte = getCalEndDate(sprEdDte, prjSprDur);
	}
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) sprEnDte = tranformDate(sprEnDte);
	
	
	
	
	$('#gnt-end-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-end-date').val() == '') {
				updtEndDate(); 
			}
			if ($("#gnt-task-type").val() == "0") {
				updtDuration();  // Only if Activity
				updtWorkDur();
				$('#gnt-task-constrain option[value="5"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-end-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
				if ($('#gnt-constrain-date').val() != '') setStartEndDates(); //  Check putting this here
			}
		}}).datepick('disable').datepick('option', {defaultDate: sprEnDte}).val(sprEnDte).addClass('readonly');
		
	// Only if Activity	
	$("#gnt-display-day").change(function(){	
		if ($("#gnt-task-type").val() == "0") {
			var isChecked = $('#gnt-display-day').attr('checked')?true:false;
			var prEnDte = $('#gnt-start-date').val();
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prEdDte = tranformDate(prEnDte);
				else var prEdDte = prEnDte;
			if(isChecked) {
				prEnDte = getEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			} else {
				prEnDte = getCalEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			}
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prEnDte = tranformDate(prEnDte);
			$('#gnt-end-date').datepick('option', {defaultDate: prEnDte}).val(prEnDte);
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
		}
	});	
	
	$("#gnt-duration").on( "spinchange", function( event, ui ) { 
		if ($("#gnt-task-type").val() == "0") { // Need to Correct here based on Activity and Milestone
			updtEndDate(); 
			updtWorkDur();
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
		} else if ($("#gnt-task-type").val() == "2") {
		    if (parseInt($("#gnt-duration").val()) > getDateDiff()) {
				jAlert('Duration does not fit within the Start and End Dates','E',function() {
					$("#gnt-duration").val(1);
					updtWorkDur();
				});
			}
			updtWorkDur(); 
		}
	});
	
	$("#gnt-sprint-velocity").spinner({min: 1, max: 1000}).val(prjSprVelocity);  
	$("#gnt-available-hrs, #tsk-available-hrs").val(parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')).toFixed(2));
	$("#gnt-sprint-velocity").on( "spinchange", function( event, ui ) { 
		$("#gnt-available-hrs").val(parseFloat($("#gnt-sprint-velocity").val().replace(/[^0-9\-\.]/g, '')).toFixed(2));
		RecalcResrcWork();
	});
	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			$('#gnt-CA').removeClass('populate_loading');
			response = $.parseJSON(response);
			if (response.length > 0) {
				for(ij = 0; ij< response.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response[ij]["value"]).text(response[ij]["descr"]));
					if (response[ij]["project-main"] == '1') var proj_main = response[ij]["value"];
				};
				$('#gnt-CA option[value='+ proj_main +']').attr("selected","selected");
			};

		}
	});

	AddFixedCosts();
	
	$("#gnt-work").spinner({decimals:2, min: 0.00, stepping: 1.00}).spinner( "disable" ); 
	
	TaskResSelector();
	
	$("#gnt-ot-hours").spinner({min: 0, max: (24 - hoursAday)});
	
	// Only if Activity
	$("#gnt-work, #gnt-ot-hours").focusout(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) {
			var MinDur=(getMinDuration()>= 1 )?getMinDuration():1;
			$("#gnt-duration").val(MinDur);
			updtEndDate();
			updtWorkDur();
		}
	});
	
	$("#gnt-Work-Dur").change(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) $('#gnt-work').trigger('focusout');
	});
	// to here - Only if Activity  
	
	$("#gnt-priority").spinner({min: 0, max: 999});	
	
	$("#gnt-task-constrain").change(function () {
		$('#gnt-constrain-date').val('');
		if ($(this).val() == "0") {
			$('#gTaskConstain').css("display", "none");
			$("#constraint-box").css("display", "none");
			$('#gnt-constrain-date').val('');
			var prStrDte = prjStartDt;
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStrDte = tranformDate(prjStartDt);
			$('#gnt-start-date').datepick('option', {defaultDate: prStrDte}).val(prStrDte);
			updtEndDate();
		}  else $('#gTaskConstain').css("display", "block");
		if ($('#gnt-constrain-date').val() != '') {
			$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
			$("#constraint-box").css("display", "block");
		} else $("#constraint-box").css("display", "none");	
	});

	$('#gnt-constrain-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer),   // {picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: true,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-constrain-date').val() != '') {
				$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
				$("#constraint-box").css("display", "block");
				setStartEndDates();
			} else $("#constraint-box").css("display", "none");
		},
		showTrigger: '#calImg-conDate'});	
		
	$("#gnt-wrTolerance").spinner({min: -100, max: 200});	
	
	$("#gnt-wrTolerance").on( "spinchange", function( event, ui ) { 
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$('.rStar').css('visibility', 'visible');
			$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
		} else {
			$('.rStar').css('visibility', 'hidden');
			$('#gnt-wrTolerance-desc').removeAttr('placeholder');
		}	
			
	});
	
	$("#gnt-ot-allowance").change(function () {
		updtskWorkCost();
	});

	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	return true;
}

/* ---------------- END of Sprint Add and Insert ------------------- */

/* ----------------- Task Add and Insert --------------------- */
function scriptTaskAddIns(action, node_ID) {
	if (prjPayment != 1) $(".paymode-1").css("display", "none");
	if (action == 'add') {
		$("#gnt-add-ins-lbl").text("Task Selected:");
		if (prjAgility == 1) {
			var NodeInfo = getNodeInfo(node_ID);
			$("#prnt-available-hrs").val(((parseFloat(NodeInfo["budget-work"]) - parseFloat(NodeInfo["estimate-work"]))/ prjSp2Hrs).toFixed(2));
			$("#prnt-budget-hrs").val((parseFloat(NodeInfo["budget-work"])/ prjSp2Hrs).toFixed(2));
		}
	} else if (action == 'insert') {
		$("#gnt-add-ins-lbl").text("Task Selected to Insert at:");
			var NodeInfo = getNodeInfo(node_ID);
			var parNode = parseInt(NodeInfo["parent-node"]);
			NodeInfo = getNodeInfo(parNode);
			$("#prnt-available-hrs").val(((parseFloat(NodeInfo["budget-work"]) - parseFloat(NodeInfo["estimate-work"])) / prjSp2Hrs).toFixed(2));
			$("#prnt-budget-hrs").val((parseFloat(NodeInfo["budget-work"])/ prjSp2Hrs).toFixed(2));
	}	
	if (prjAudit == 0) {      
		$("#gnt-notes-lbl").empty().text("Notes:");
	} else {
		if (prjStatus == 1) { 
			$("#gnt-notes-lbl").text("Change Request Details:");
			$("#gnt-notes-lbl").append('<span id="gnt-audit-notes" style="color: #cd1800;">&#42;</span>');
			$("#gnt-task-notes").attr('placeholder', '-- required --'); 
		} else {
			$("#gnt-notes-lbl").empty().text("Notes:");
		}	
	}	
	
	if ((user_profile == 'stake') || (user_profile == 'proposal')) $(".comp_internal").css("display", "none");
		else $(".comp_internal").css("display", "block");
	
	hide_message_box("gntFl-message-box");
	$("#constraint-box").css("display", "none");
	$("#tab_predecessor").css("display", "none");
	$('#gntNode-name-curr-dyn').val('(Task: '+getOrigLink(node_ID)+') '+getNodeName(node_ID));
	
	$('#gntNode-name-dyn').autocomplete("phpAutocomplete.php", {
		width: $('#gntNode-name-dyn').width(),
		matchContains: true,
		selectFirst: false,
		mode: "Edit",
		target: "project",
		entity: "task"+"^^"+$('#gantt-select-devp').val()
	});	
	
	
	$("#week_days").multiSelect({selectAll: false, 
								listHeight: 140, 
								noneSelected: "Select Days", 
								oneOrMoreSelected: '% Day(s) Selected',
								spanWidth: 170, 
								optWidth: 220, 
								resultFld: "week_days_list"} 
								); 

	$("#month_dates").multiSelect({selectAll: false, 
								listHeight: 140, 
								noneSelected: "Select Dates", 
								oneOrMoreSelected: '% Date(s) Selected',
								spanWidth: 170, 
								optWidth: 220, 
								resultFld: "month_dates_list"} 
								); 
								
	$("#gnt-duration").spinner({min: 1, max: 365});  
	if ($("#gnt-task-type").val() == "1") {           // Disable Spin and set value 1 if Milestone
			$("#gnt-duration").spinner( "disable" ).val(1);
			updtEndDate(); 
	} else $("#gnt-duration").spinner( "enable" );	
	
								
	$('#gnt-task-type').change(function(){  // set max and min for Start and End Dates  IMPORTANT  MSD
		if ($('#gnt-task-type').val() == '2') {
			if (prjAgility == 0) {
				$('#gTaskRecur').css("display", "block"); 
				$('#gTaskNonRecur').css("display", "none");
				$('#gnt-deliverables, #gnt-reviews').removeAttr("checked");
				
				$('#gnt-task-recr option[value="0"]').attr('selected', 'selected');
				$("#gnt-priority").spinner( "disable" ).val(500);
				if ($('#gnt-task-recr').val() == '0') $("#gnt-duration").spinner( "disable" ).val(1);
					else $("#gnt-duration").spinner( "enable" ).val(1);
				updtEndDate(); 
				$("#gnt-work").spinner( "disable" );
				$('#gnt-end-date').datepick('enable').removeClass('disabled_fld');
				if ($('[name^="work_"]').length > 0) {
					$('[name^="mode_"] option[value="P"]').attr("selected","selected");
					$('[name^="mode_"]').removeAttr("disabled").removeClass('disabled_fld');
					$('[name^="rate_"]').spinner( "enable" ).val(100);
					updtWorkDur();
				}
				$('#gnt-task-constrain option[value="0"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change').attr("disabled","disabled").addClass('disabled_fld');
				$('#gnt-constrain-date').val('');
				$("#gnt-ot-hours").spinner( "disable" ).val(0);
				$('#gnt-ot-allowance').removeAttr("checked").attr("disabled","disabled").addClass('disabled_fld');
			} else {
				$('#gTaskRecur').css("display", "block"); 
				$('#gTaskNonRecur, #gnt-start-date, #gnt-end-date').css("display", "none"); //-----
				$('#gnt-deliverables, #gnt-reviews').removeAttr("checked");
				
				$('#gnt-task-recr option[value="0"]').attr('selected', 'selected');
				$("#gnt-priority").spinner( "disable" ).val(500);
				if ($('#gnt-task-recr').val() == '0') $("#gnt-duration").spinner( "disable" ).val(1);
					else $("#gnt-duration").spinner( "enable" ).val(1);
				updtEndDate(); 
				$("#gnt-work").spinner( "disable" );
				$('#gnt-end-date').datepick('enable').removeClass('disabled_fld');
				if ($('[name^="work_"]').length > 0) {
					$('[name^="mode_"] option[value="P"]').attr("selected","selected");
					$('[name^="mode_"]').removeAttr("disabled").removeClass('disabled_fld');
					$('[name^="rate_"]').spinner( "enable" ).val(100);
					updtWorkDur();
				}
				$('#gnt-task-constrain option[value="0"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change').attr("disabled","disabled").addClass('disabled_fld');
				$('#gnt-constrain-date').val('');
				$("#gnt-ot-hours").spinner( "disable" ).val(0);
				$('#gnt-ot-allowance').removeAttr("checked").attr("disabled","disabled").addClass('disabled_fld');
			}
		} else {
			$('#gnt-task-constrain option[value="0"]').attr("selected","selected");
			$('#gnt-task-constrain').trigger('change').removeAttr("disabled").removeClass('disabled_fld');
			$('#gnt-constrain-date').val('');
			$("#gnt-priority").spinner( "enable" ).val(500);
			$('#gTaskNonRecur').css("display", "block");
			$('#gTaskRecur,#gTaskRecurWk,#gTaskRecurMn').css("display", "none");
			if ($("#gnt-task-type").val() == "1") {           // Disable Spin and set value 1 if Milestone
					$("#gnt-duration").spinner( "disable" ).val(1);
					$("#gnt-ot-hours").spinner( "disable" ).val(0);
					$('#gnt-ot-allowance').removeAttr("checked").attr("disabled","disabled").addClass('disabled_fld');
					updtEndDate(); 
					$('#gnt-end-date').datepick('disable').addClass('disabled_fld');
					$("#gnt-work").spinner( "disable" ).val('0.00');
						if ($('[name^="work_"]').length > 0) {
							$('[name^="mode_"] option[value="H"]').attr("selected","selected");
							$('[name^="mode_"] option[value="P"]').attr("disabled","disabled");
							$('[name^="rate_"]').val(0);
							$('[name^="work_"]').val(0);
						}	
			} else {
				$("#gnt-duration, #gnt-work, #gnt-ot-hours").spinner( "enable" );	
				$("#gnt-duration").val(1);
				$('#gnt-end-date').datepick('enable').removeClass('disabled_fld');
				$('#gnt-ot-allowance').removeAttr("disabled").removeClass('disabled_fld');
				if ($('[name^="work_"]').length > 0) {
					$('[name^="mode_"] option[value="P"]').attr("selected","selected");
					$('[name^="mode_"]').removeAttr("disabled").removeClass('disabled_fld');
					$('[name^="rate_"]').spinner( "enable" ).val(100);
					updtWorkDur();
				}
				updtEndDate(); 
			}	
		}	
	});		

	$('#gnt-task-recr').change(function(){ 
		if ($('#gnt-task-recr').val() == '1') {
			$('#gTaskRecurWk').css("display", "block"); 
			$('#gTaskRecurMn').css("display", "none"); 
			$("#gnt-duration").spinner( "enable" )
		} else if ($('#gnt-task-recr').val() == '2') {
			$('#gTaskRecurWk').css("display", "none"); 
			$('#gTaskRecurMn').css("display", "block");
			$("#gnt-duration").spinner( "enable" )
		}  else {
			$('#gTaskRecurWk,#gTaskRecurMn').css("display", "none");
			$("#gnt-duration").spinner( "disable" ).val(1);
		}	
	});	
	var prStDte = '';
	var pStrtDat = getNodeStart(node_ID);	
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) {
		prStDte = tranformDate(prjStartDt);
		pStartDate = tranformDate(pStrtDat);
	} else {
		prStDte = prjStartDt;
		pStartDate = pStrtDat;
	}	
	
	$('#gnt-start-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($("#gnt-task-type").val() != "2"){
				if ($('#gnt-start-date').val() == '') {
					$('#gnt-start-date').datepick('option', {defaultDate: prStDte}).val(prStDte);
				}
				updtEndDate();  // Only if Activity and Milestone
				$('#gnt-task-constrain option[value="2"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-start-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
					$("#constraint-box").css("display", "block");
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
			}	
		},
		showTrigger: '#calImg-stDate'}).datepick('option', {defaultDate: pStartDate}).val(pStartDate);	
	
	$('#gnt-end-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-end-date').val() == '') {
				updtEndDate(); 
			}
			if ($("#gnt-task-type").val() == "0") {
				updtDuration();  // Only if Activity
				updtWorkDur();
				$('#gnt-task-constrain option[value="5"]').attr("selected","selected");
				$('#gnt-task-constrain').trigger('change');
				$('#gnt-constrain-date').val($('#gnt-end-date').val());
				if ($('#gnt-constrain-date').val() != '') {    // Check putting this here
					$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
					$("#constraint-box").css("display", "block");
					setStartEndDates();
				} else $("#constraint-box").css("display", "none");
				if ($('#gnt-constrain-date').val() != '') setStartEndDates(); //  Check putting this here
			}
		},
		showTrigger: '#calImg-enDate'}).datepick('option', {defaultDate: pStartDate}).val(pStartDate);
		
	// Only if Activity	
	$("#gnt-display-day").change(function(){	
		if ($("#gnt-task-type").val() == "0") {
			var prEnDte = $('#gnt-start-date').val();
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prEdDte = tranformDate(prEnDte);
				else var prEdDte = prEnDte;
			var isChecked = $('#gnt-display-day').attr('checked')?true:false;
			if(isChecked) {
				prEnDte = getEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			} else {
				prEnDte = getCalEndDate(prEdDte, parseInt($("#gnt-duration").val()));
			}
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prEnDte = tranformDate(prEnDte);
			$('#gnt-end-date').datepick('option', {defaultDate: prEnDte}).val(prEnDte);
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
		}
	});	
	
	$("#gnt-duration").on( "spinchange", function( event, ui ) { 
		if ($("#gnt-task-type").val() == "0") { // Need to Correct here based on Activity and Milestone
			updtEndDate(); 
			updtWorkDur();
			if ($('#gnt-constrain-date').val() != '') setStartEndDates();  //  Check putting this here
		} else if ($("#gnt-task-type").val() == "2") {
		    if (parseInt($("#gnt-duration").val()) > getDateDiff()) {
				jAlert('Duration does not fit within the Start and End Dates','E',function() {
					$("#gnt-duration").val(1);
					updtWorkDur();
				});
			}
			updtWorkDur(); 
		}
	});
	
	// to here - Only if Activity
	
	if (prjAgility == 1) {
		$("#gnt-work-rate").spinner({max: 100, decimals:2, min: 0.00, stepping: 1.00});
		
		var max_percent = 100 - ((parseFloat($("#prnt-budget-hrs").val()) - parseFloat($("#prnt-available-hrs").val()) ) / parseFloat($("#prnt-budget-hrs").val()) * 100);
		if ($('#gnt-work-contour').val() == 'P') $("#gnt-work-rate").spinner( "option", "max", max_percent ).spinner( "option", "stepping", 1 ).val(0);
			else $("#gnt-work-rate").spinner( "option", "max", parseFloat($("#prnt-available-hrs").val())).spinner( "option", "stepping", 0.25 ).val(0);
		
		$("#gnt-work-rate").on( "spinchange", function( event, ui ) { 
			if ($("#gnt-work-contour").val() == "P") { 
				var act_work_rate = parseFloat($("#prnt-budget-hrs").val()) * parseFloat($("#gnt-work-rate").val().replace(/[^0-9\-\.]/g, '')) / 100;
				$("#gnt-available-hrs").val(parseFloat(act_work_rate).toFixed(2));
			} else {
				$("#gnt-available-hrs").val(parseFloat($("#gnt-work-rate").val().replace(/[^0-9\-\.]/g, '')).toFixed(2));
			}
			RecalcResrcWork();
			// adjust the value in $("#gnt-available-hrs").val();   getTotResWork()
			//$("#gnt-available-hrs").val();
		});
		
		$('#gnt-work-contour').change(function() {
			if ($('#gnt-work-contour').val() == 'P') {
					$("#gnt-work-rate").spinner( "option", "max", max_percent ).spinner( "option", "stepping", 1 ).val(0);
				} else {
					$("#gnt-work-rate").spinner( "option", "max", parseFloat($("#prnt-available-hrs").val())).spinner( "option", "stepping", 0.25 ).val(0);
					
				}
			$("#gnt-available-hrs").val(0);
			RecalcResrcWork();
			// adjust the value in $("#gnt-available-hrs").val(); decimals:2, min: 0.00, stepping: 1.00
		});	
	}
	
	//$('#gnt-currency').val(currency);
	$('#gnt-currency').text(" ("+currency+")");
	
	$('#gnt-CA').addClass('populate_loading');
	$.ajax({
		url: "phpGanttLoad.php",
		type: 'POST',
		data: {"page": "gantt-CA-load", "project-id": $('#gantt-select-devp').val()},
		timeout: xhr_timeout * 10,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			$('#gnt-CA').removeClass('populate_loading');
			response = $.parseJSON(response);
			if (response.length > 0) {
				for(ij = 0; ij< response.length; ij++) {
					$('#gnt-CA').append($('<option></option>').attr('value', response[ij]["value"]).text(response[ij]["descr"]));
					if (response[ij]["project-main"] == '1') var proj_main = response[ij]["value"];
				};
				$('#gnt-CA option[value='+ proj_main +']').attr("selected","selected");
			};

		}
	});

	AddFixedCosts();
	
	$("#gnt-work").spinner({decimals:2, min: 0.00, stepping: 1.00}).spinner( "disable" ); 
	
	TaskResSelector();
	
	$("#gnt-ot-hours").spinner({min: 0, max: (24 - hoursAday)});
	
	// Only if Activity
	$("#gnt-work, #gnt-ot-hours").focusout(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) {
			var MinDur=(getMinDuration()>= 1 )?getMinDuration():1;
			$("#gnt-duration").val(MinDur);
			updtEndDate();
			updtWorkDur();
		}
	});
	
	$("#gnt-Work-Dur").change(function () {
		var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
		if (($("#gnt-task-type").val() == "0") && (isChecked == true)) $('#gnt-work').trigger('focusout');
	});
	// to here - Only if Activity  
	
	$("#gnt-priority").spinner({min: 0, max: 999});	
	
	$("#gnt-task-constrain").change(function () {
		$('#gnt-constrain-date').val('');
		if ($(this).val() == "0") {
			$('#gTaskConstain').css("display", "none");
			$("#constraint-box").css("display", "none");
			$('#gnt-constrain-date').val('');
			var prStrDte = prjStartDt;
			if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStrDte = tranformDate(prjStartDt);
			$('#gnt-start-date').datepick('option', {defaultDate: prStrDte}).val(prStrDte);
			updtEndDate();
		}  else $('#gTaskConstain').css("display", "block");
		if ($('#gnt-constrain-date').val() != '') {
			$("#constraint-box").empty().append('<p><b>Contraint: </b>'+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
			$("#constraint-box").css("display", "block");
		} else $("#constraint-box").css("display", "none");	
	});

	$('#gnt-constrain-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer),   // {picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}
		dateFormat: prjDtIn,
		minDate: prStDte,
		showOnFocus: true,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		onClose: function(dates) { 
			if ($('#gnt-constrain-date').val() != '') {
				$("#constraint-box").empty().append('<p><b>Contraint: </b> '+$('#gnt-task-constrain option:selected').text()+' '+$('#gnt-constrain-date').val()+'</p>');
				$("#constraint-box").css("display", "block");
				setStartEndDates();
			} else $("#constraint-box").css("display", "none");
		},
		showTrigger: '#calImg-conDate'});	
		
	$("#gnt-wrTolerance").spinner({min: -100, max: 200});	
	
	$("#gnt-wrTolerance").on( "spinchange", function( event, ui ) { 
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$('.rStar').css('visibility', 'visible');
			$('#gnt-wrTolerance-desc').attr('placeholder', '-- required --');
		} else {
			$('.rStar').css('visibility', 'hidden');
			$('#gnt-wrTolerance-desc').removeAttr('placeholder');
		}	
			
	});
	
	$("#gnt-ot-allowance").change(function () {
		updtskWorkCost();
	});

	$('#delivToUpload').MultiFile({ 
		list: '#delivUploadList',
		max: 5,
		accept: deliv_extns,  
		STRING: {
			remove: '<img src="images/fileupload/remove.jpg" height="16" width="16" alt="x"/>'
		}
	}); 
	return true;
}
// Functions for control AddIns dynamic screen elements 
function updtWorkDur() {
	if ($('[name^="work_"]').length > 0) {
		$('[name^="work_"]').each(function() {
			var indResource = $(this).attr('id').split("_");
			updtIndWork(indResource[1])
		});
	}	
}

function AddFixedCosts() {
    counter = 1;
	var set_num = 1;
	$("#addButton").click(function () {
		if(counter>10){
				jAlert("Only ten Entries of Fixed Cost are allowed now. More can be added through <b>Edit</b> function !", "Error");
				return false;
		}   
		$("#fix-cost-group").append($("<div></div>").attr("id",'fix-cost' + set_num).attr("name", "fix-cost"));
		$("#fix-cost" + set_num).append($("<br/>"));
		$("#fix-cost" + set_num).append($("<label class='label'>Description: </label>"));
		$("#fix-cost" + set_num).append($("<input type='text' class='inputs'/>").attr("id","cost-desc"+set_num).attr("name","cost-desc"+set_num));
		$("#fix-cost" + set_num).append($("<label class='label'>Amount: </label>"));
		$("#fix-cost" + set_num).append($("<div></div>").attr("id",'fcd-cost' + set_num));            
		var tbl = $('<table></table>').attr("id","fc_tbl_" + set_num);
		var row = $('<tr style="font-size: 80%;"></tr>').appendTo(tbl);
		$('<td></td>').attr("id", "fc_amt_"+ set_num).text('').prepend($("<input type='text' style='width: 90%;'/>").attr("id","cost-amt"+set_num).attr("name","cost-amt"+set_num)).appendTo(row);
		$('<td></td>').attr("id", "fc_amtB_"+ set_num).text('').prepend($("<button class='button gray smlbut'/>").attr("id","fc-butn"+set_num).attr("name","fc-butn"+set_num).text("Remove").attr("onclick","remove_fc("+set_num+")")).appendTo(row);
		tbl.appendTo($("#fcd-cost" + set_num)); 
		$("#cost-amt" + set_num).spinner({decimals:2, min: 0.00, stepping: 0.25});
		$("#fix-cost" + set_num).append($("<br/>"));
		counter++;
		set_num++;
    });
	
}

function remove_fc(set_num) {
	$("#fix-cost" + set_num).remove();
	counter--;
}

function getDateDiff() {
	var prDur = 0;
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	if(isChecked) {
		prDur = getBuzdays($('#gnt-start-date').val(), $('#gnt-end-date').val());
	} else {
		prDur = getCdays($('#gnt-start-date').val(), $('#gnt-end-date').val());
	}
	if (prDur > 1) return (parseInt(prDur));
		else  return(1);
}

function updtDuration() {
	var prDur = $("#gnt-duration").val();
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	if(isChecked) {
		prDur = getBuzdays($('#gnt-start-date').val(), $('#gnt-end-date').val());
	} else {
		prDur = getCdays($('#gnt-start-date').val(), $('#gnt-end-date').val());
	}
	if (prDur > 1) $("#gnt-duration").val(prDur);
		else  $("#gnt-duration").val('1');
}

function updtEndDate() {
	var prEnDte = $('#gnt-start-date').val();
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prEdDte = tranformDate(prEnDte);
		else var prEdDte = prEnDte;
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	if(isChecked) {
		prEnDte = getEndDate(prEdDte, parseInt($("#gnt-duration").val()));
	} else {
		prEnDte = getCalEndDate(prEdDte, parseInt($("#gnt-duration").val()));
	}
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prEnDte = tranformDate(prEnDte);
	$('#gnt-end-date').datepick('option', {defaultDate: prEnDte}).val(prEnDte);
	if(prjEndDt != '') {
		var tprFnDte = new Date(Date.parse(prjEndDt));
		var newFinDt = prEnDte;
		if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) newFinDt = tranformDate(newFinDt);
		newFinDt = new Date(Date.parse(newFinDt));
		if (newFinDt > tprFnDte) jAlert("Task End Date crosses the Project Deadline Date.... !", "Alert");
	}
}

function updtStartDate() {
	
	var prStDte = $('#gnt-end-date').val();
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var prSdDte = tranformDate(prStDte);
		else var prSdDte = prStDte;
	var isChecked = $('#gnt-display-day').attr('checked')?true:false;
	if(isChecked) {
		prStDte = getStartDate(prSdDte, parseInt($("#gnt-duration").val()));
	} else {
		prStDte = getCalStartDate(prSdDte, parseInt($("#gnt-duration").val()));
	}
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStDte = tranformDate(prStDte);
	
	var prStrDte = prjStartDt;
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) prStrDte = tranformDate(prjStartDt);
	var tprStDte = new Date(Date.parse(prStrDte)); // Project Start Date
	
	var newStrt = prStDte;
	//if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) newStrt = tranformDate(newStrt);
	newStrt = new Date(Date.parse(newStrt)); // New Task Start Date
	
	
	
	if (newStrt < tprStDte) {
		
		var cDiff = getCdays(prStDte, prStrDte);
		//alert(prStrDte+ ' Task : '+ prStDte +' Diff: '+ cDiff);
		
		
		var prDur = $("#gnt-duration").val();
		var isChecked = $('#gnt-display-day').attr('checked')?true:false;
		if(isChecked) {
			prDur = getBuzdays(prStrDte, $('#gnt-end-date').val());
		} else {
			prDur = getCdays(prStrDte, $('#gnt-end-date').val());
		}
		$('#gnt-start-date').datepick('option', {defaultDate: prStrDte}).val(prStrDte);
		if (prDur > 1) $("#gnt-duration").val(prDur);
			else  $("#gnt-duration").val('1');
		updtWorkDur();
	
	} else $('#gnt-start-date').datepick('option', {defaultDate: prStDte}).val(prStDte);
}

//----------------------------------------------------------------------------

function TaskResSelector() {
			$('#gnt_task_resources').addClass('populate_loading');
			$.ajax({
				url: "phpPopulate.php",
				type: 'POST',
				data: {"page": "project-gantt-resources", "field":$('#gantt-select-devp').val()},
				timeout: xhr_timeout * 10,
				error: function () {
					hide_all_errors();
					hide_upload_started();
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					//alert(response);
					response = $.parseJSON(response);
					prjktResRate = response;   // Saving the resource rates
					$("#gnt_task_resources").append($("<option></option>").attr("value","").text(""));
					if (response.length > 0) {
						for(ij = 0; ij< response.length; ij++) {
							if (!$('#optg_'+response[ij]["dept-no"]).length)  $('#gnt_task_resources').append($("<optgroup></optgroup>").attr('id','optg_'+ response[ij]["dept-no"]).attr('label', response[ij]["dept-name"]));
							$('#optg_'+response[ij]["dept-no"]).append($('<option></option>').attr('value', response[ij]["value"]).text(response[ij]["descr"]));
						
						};
					};
					$("#gnt_task_resources").multiSelect({selectAll: false, 
													listHeight: 150, 
													noneSelected: "Assign Resources", 
													oneOrMoreSelected: '% Resource(s) Assigned',
													spanWidth: 170, 
													optWidth: 220, 
													resultFld: "gnt_task_resources_list"}, 
													function(el) {
														var numResources = $('[name^="rate_"]').length;
														if (numResources != 0) {
															var resource_id = [];
															var resource_rate = [];
															$('[name^="rate_"]').each(function() {
																			resource_id.push($(this).attr("id").replace(/[^0-9]/g, ''));
																			resource_rate.push($(this).val());
															});	
															var resource_work = [];
															$('[name^="work_"]').each(function() {
																			resource_work.push($(this).val());
															});	
															var resource_mode = [];
															$('[name^="mode_"]').each(function() {
																			resource_mode.push($(this).val());
															});	
														} 
														$("#gnt_task_resources_work").empty();
														var selectRes = $("#gnt_task_resources_list").val().split(",");
														if ($("#gnt_task_resources_list").val().length == 0) {
															$("#gnt_task_resources_work").empty();
															$("#gnt-work").spinner( "disable" ).val('0.00');
															return false;
														}
														var tbl = $('<table></table>').attr("id","task_resources_1").attr("class", "rate_table");
														var row = $('<tr style="font-size: 80%;"></tr>').appendTo(tbl);
														$('<th></th>').css("width","150px").attr("class", "colRes").text("Resource Name").appendTo(row);
														$('<th></th>').text("Work Contour").appendTo(row);
														$('<th></th>').text("Work Rate").appendTo(row);
														if (prjAgility == 0) $('<th></th>').text("Work Hours").appendTo(row);
															else $('<th></th>').text("Story Points").appendTo(row);
														var toglClass = 'normal';
														for(i=0; i<selectRes.length; i++) {
															var indResource = selectRes[i].split("~");
															var rateRes = "1";
															var workRes = "0";
															toglClass=(toglClass=='normal')?'odd':'normal';
															row = $('<tr></tr>').attr("class", toglClass).appendTo(tbl);
															$('<td></td>').attr("class", "colRes").attr("class", toglClass).text('').css("width","250px").prepend($("<a></a>").attr("href","#").attr("onclick","showResAvail("+indResource[0]+", "+$('#gantt-select-devp').val()+")").text(indResource[1])).appendTo(row);
															$('<td></td>').text('').prepend($("<select/>").attr("id","mode_"+indResource[0]).attr("name","mode_"+indResource[0]).css("float","center").css("width","125px")).appendTo(row); /* .css("font-size","90%")*/
															$('<td></td>').text('').prepend($("<input type='text'/>").attr("id","rate_"+indResource[0]).attr("name","rate_"+indResource[0]).val(rateRes).css("float","center").css("width","75px")).appendTo(row);
															$('<td></td>').text('').prepend($("<input type='text'/>").attr("id","work_"+indResource[0]).attr("name","work_"+indResource[0]).val(workRes).attr("class", "inputs").attr("readonly", "readonly").css("float","center").css("width","75px")).appendTo(row);	
														} 
														tbl.appendTo($("#gnt_task_resources_work")); 
														for(i=0; i<selectRes.length; i++) {
															var indResource = selectRes[i].split("~");
															if (prjAgility == 0) $("#rate_"+indResource[0]).spinner({min: 0, max: 100}).val(100);
																else $("#rate_"+indResource[0]).spinner({min: 0, max: 100, decimals: 2, stepping: 1.00}).val(0);
															$('#mode_'+indResource[0]).append($('<option></option>').attr('value', 'P').text('Flat - Percentage').attr('selected', 'selected'));															
															if (prjAgility == 0) $('#mode_'+indResource[0]).append($('<option></option>').attr('value', 'H').text('Fixed Hours'));
																else $('#mode_'+indResource[0]).append($('<option></option>').attr('value', 'H').text('Fixed Story Points'));
														} 
														for(i=0; i<selectRes.length; i++) {
															var indResource = selectRes[i].split("~");
															if (numResources != 0) {
																for (j=0; j<resource_id.length; j++) {
																	if (indResource[0] == resource_id[j]) {
																		if (resource_mode[j] == 'P') {
																			$("#rate_"+indResource[0]).spinner( "option", "max", 100 );
																		} else {
																			if (prjAgility == 0) $("#rate_"+indResource[0]).spinner( "option", "max", 510 );
																				else $("#rate_"+indResource[0]).spinner( "option", "max", parseFloat($("#gnt-available-hrs").val()));
																		}	
																		$("#rate_"+indResource[0]).val(resource_rate[j]);
																		$("#work_"+indResource[0]).val(resource_work[j]);
																		$('#mode_'+ indResource[0] +' option[value='+ resource_mode[j] +']').attr('selected', 'selected');
																		break;
																	}
																}
															}   
														}
														$('[name^="mode_"]').each(function() {
															var indResource = $(this).attr('id').split("_");
															updtIndWork (indResource[1]);
															UpdateTaskAvailableWork();
														});	
														
														$('[name^="mode_"]').change(function() {
															var indResource = $(this).attr('id').split("_");
															if ($('#mode_'+indResource[1]).val() == 'P') {
																if (prjAgility == 0) $("#rate_"+indResource[1]).spinner( "option", "max", 100 ).val(100);
																	else $("#rate_"+indResource[1]).spinner( "option", "max", 100 ).spinner( "option", "stepping", 1.00).val(0);
															} else {
																if (prjAgility == 0) $("#rate_"+indResource[1]).spinner( "option", "max", 510 ).val(0);
																	else $("#rate_"+indResource[1]).spinner( "option", "max", parseFloat($("#gnt-available-hrs").val())).spinner( "option", "stepping", 0.25).val(0);
															}
															updtIndWork (indResource[1]);
															UpdateTaskAvailableWork();
														});	
														$('[name^="rate_"]').on( "spinchange", function( event, ui ){
															var indResource = $(this).attr('id').split("_");
															updtIndWork (indResource[1]);
															UpdateTaskAvailableWork();
														});	
														
														if ($("#gnt-task-type").val() == "1") { 
															//$("#gnt-work").spinner( "disable" ).val('0.00');
															$('[name^="mode_"] option[value="H"]').attr("selected","selected");
															$('[name^="mode_"] option[value="P"]').attr("disabled","disabled");
															$('[name^="rate_"]').val(0);
															$('[name^="work_"]').val(0);
														}														
														if (prjAgility == 1) UpdateTaskAvailableWork();
													}); // , oneOrMoreSelected: '*' 
				}
			});


}

function updtIndWork (dynID) {
	if (prjAgility == 0) {
		var wrkHrs = hoursAday + parseInt($("#gnt-ot-hours").val());
		if ($('#mode_'+dynID).val() == 'P') {
			var indWork = parseInt($("#gnt-duration").val())* wrkHrs * parseInt($("#rate_"+dynID).val()) / 100;
			$("#work_"+dynID).val( indWork );
		} else {
			$("#work_"+dynID).val(parseInt($("#rate_"+dynID).val())); 
			//var isChecked = $('#gnt-Work-Dur').attr('checked')?true:false;
			if (parseInt($("#rate_"+dynID).val()) > (parseInt($("#gnt-duration").val())* 24)) {
				var newDuration = Math.ceil(parseInt($("#rate_"+dynID).val()) / 24);
				$("#gnt-duration").val(newDuration);
				updtEndDate();
				updtWorkDur();
			}              
		}
	} else {
		var wrkHrs = parseFloat($("#gnt-available-hrs").val());
		if ($('#mode_'+dynID).val() == 'P') {
			var indWork = parseFloat(wrkHrs * parseFloat($("#rate_"+dynID).val()) / 100).toFixed(2);
			$("#work_"+dynID).val( indWork );
		} else {
			$("#work_"+dynID).val(parseFloat($("#rate_"+dynID).val()).toFixed(2)); 
			//alert($("#work_"+dynID).val());
		}
	}
	if (prjAgility == 0) updtskWorkCost();
}

function updtskWorkCost() {
	var colectWork = 0;
	var colFWork = 0;
	var colWorkCost = 0;
	var isChecked = $('#gnt-ot-allowance').attr('checked')?true:false;
	$('[name^="work_"]').each(function() {
		var indResource = $(this).attr('id').split("_");
		colectWork +=  parseFloat($("#work_"+indResource[1]).val());
		if ($('#mode_'+indResource[1]).val() == 'H') colFWork +=  parseInt($("#work_"+indResource[1]).val());
		
		if (isChecked) {
			var expDailyHours = parseInt($("#gnt-duration").val()) * hoursAday;
			if (parseFloat($("#work_"+indResource[1]).val()) < expDailyHours) colWorkCost += parseFloat($("#work_"+indResource[1]).val()) * getResourceRate(indResource[1]);
			 else colWorkCost += expDailyHours * getResourceRate(indResource[1]) + (parseFloat($("#work_"+indResource[1]).val()) - expDailyHours) * getResOTRate(indResource[1]);
		} else {
			colWorkCost += parseFloat($("#work_"+indResource[1]).val()) * getResourceRate(indResource[1]);
		}
	});
	
	$("#gnt-work").spinner( "option", "min", colFWork ).val(parseFloat(colectWork).toFixed(2));   // Removed getUBWork
	$("#gnt-resource-cost").val(parseFloat(colWorkCost).toFixed(2));
	
	if ((colectWork - colFWork) == 0) $("#gnt-work").spinner( "disable" );
		else {
			if ($("#gnt-task-type").val() == "0") $("#gnt-work").spinner( "enable" );
		}	

}

function getResourceRate(resource_id) {
	var res_rate = 0;
	
	for (i=0; i<prjktResRate.length; i++) {
		if (parseInt(prjktResRate[i]['value']) == parseInt(resource_id)) {
			res_rate = parseFloat(prjktResRate[i]['hr-rate']);
			break;
		}
	}
	return (res_rate);
}

function getResOTRate(resource_id) {
	var res_otrate = 0;
	for (i=0; i<prjktResRate.length; i++) {
		if (parseInt(prjktResRate[i]['value']) == parseInt(resource_id)) {
			if (parseFloat(prjktResRate[i]['ot-rate']) == 0) res_otrate = parseFloat(prjktResRate[i]['hr-rate']);
				else res_otrate = parseFloat(prjktResRate[i]['ot-rate']);
			break;
		}
	}
	return (res_otrate);
}

function getMinDuration() {
	var minDuration = 0;
	var durArray = [];
	var minPDur = 0;
	var colectFWork = 0;
	var colectPWork = 0;
	var colectPRate = 0;
	var wrkHrs = hoursAday + parseInt($("#gnt-ot-hours").val());
	$('[name^="work_"]').each(function() {
		var indResource = $(this).attr('id').split("_");
		if ($('#mode_'+indResource[1]).val() == 'H') {
			if (wrkHrs > 0) durArray.push(Math.ceil(parseFloat($("#work_"+indResource[1]).val()) / wrkHrs));
			colectFWork += parseFloat($("#work_"+indResource[1]).val());
		} else {
			colectPRate += parseInt($("#rate_"+indResource[1]).val());
		} 
	});
	colectPWork = Math.ceil(($("#gnt-work").val())) - colectFWork;
	if ((colectPRate > 0) && (wrkHrs > 0)) minPDur = Math.round(parseFloat(colectPWork / wrkHrs * 100 / colectPRate));
		else minPDur = 0;
	durArray.push(minPDur);
	for (i = 0; i< durArray.length; i++) {
		if (durArray[i] > minDuration) minDuration = durArray[i];
	}
	return (minDuration);
}

function setStartEndDates() {
	//alert("Setting");
	if ($('#gnt-constrain-date').val() != '') {
		var tskStartDate = $('#gnt-start-date').val();
		if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) tskStDate = tranformDate(tskStartDate);
			else tskStDate = tskStartDate;
		tskStDate = new Date(Date.parse(tskStDate));
		
		var tskEndDate = $('#gnt-end-date').val();
		if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) tskEnDate = tranformDate(tskEndDate);
			else tskEnDate = tskEndDate;
		tskEnDate = new Date(Date.parse(tskEnDate));
			
		var tskConsDate = $('#gnt-constrain-date').val();
		if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) tskCnDate = tranformDate(tskConsDate);
			else tskCnDate = tskConsDate;
		tskCnDate = new Date(Date.parse(tskCnDate));
		
		var tskConstraint = parseInt($('#gnt-task-constrain').val());
		
		// alert(tskStDate+"<> "+tskCnDate+"<> "+tskEnDate);
		
		switch(tskConstraint){  // Ensure NO change to Duration
					
			case 0:
				 // Do Nothing since ASAP selected
				break;
			case 1:
				if (tskStDate > tskCnDate) {
					//alert("S No L - Action");
					$('#gnt-start-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtEndDate();
				}
				break;
			case 2:
				if (tskStDate < tskCnDate) {
					//alert("S No E - Action");
					$('#gnt-start-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtEndDate();
				}
				break;
			case 3:
				if (tskStDate != tskCnDate) {
					//alert("S Mst - Action");
					$('#gnt-start-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtEndDate();
				}
				break;
			case 4:
				if (tskEnDate > tskCnDate) {
					//alert("F No L - Action");
					$('#gnt-end-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtStartDate();
				}
				break;
			case 5:
				if (tskEnDate < tskCnDate) {
					//alert("F No E - Action");
					$('#gnt-end-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtStartDate();
				}
				break;
			case 6:
				if (tskEnDate != tskCnDate) {
					//alert("F Mst - Action");
					$('#gnt-end-date').datepick('option', {defaultDate: tskConsDate}).val(tskConsDate);
					updtStartDate();
				}
				break;
			case 7:
				//if (tskEnDate != tskCnDate) {
					//alert("Start AS Late AS - Action");
				//}
				break;
			default:
				 // Do Nothing since ASAP selected
				break;			
		}	
	}
}

// Function to submit (Save) Story Pull or Insert request from dynamic screen

function submitStoryPullIns(submitType) {
	empty_message_box("gntFl-message-box");
	show_upload_started(); 

	$(".flx-baksty-add").trigger("click"); // .hiddenFlexBtn
	var ValidationStatus = true;
	var inp = '';
	MesgStrg = '';
	if ($('#selected_story_list').val() == '') MesgStrg = '<p>&#9830; Story not selected</p>';
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>Select Story</b></p>').append(MesgStrg);
	}
	
	if ((prjAudit == 1) && (prjStatus == 1)) {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
	} else {
		var inp = $('#gnt-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
	}
	
	if (ValidationStatus == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
		
	} else {
		//$('#selected_story_list').val(0);
		$.ajax({
			url: "phpAgileService.php",
			type: 'POST',
			data: {
				"page": 'sprint-story-pull-insert',
				"project-id": $('#gantt-select-devp').val(),
				"submit-action": submitType, 
				"node-id": $('#div-entity-id-edit').val(), 
				"node-notes": $('#gnt-task-notes').val(),
				"sty-node-id": $('#selected_story_list').val(),
				"fixed-cost": packFixedCost(),    
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				//alert(response);
				//return false;
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct the errors indicated...','E', function() {
							//$.popgFLfrm._hide();
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
					});
				} else if (response[0][0].status == "noExist") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							//$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	}
}



// Function to submit (Save) Sprint Add or Insert request from dynamic screen

function submitSprintAddIns(submitType) {
	empty_message_box("gntFl-message-box");
	show_upload_started();
	if (validateNodeDetails(submitType) == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else {
		 
		var deliverables = 0;
		var reviews = 0;
		var recur_meeting = 0;
		var recur_report = 0;
		var day_display = $('#gnt-display-day').attr('checked')?0:1; // This is reverse in jsGantt if 1 Cal days
		var compute_ot = 0;
		var wrk_dur = 0;
		var updt_allow = $('#gnt-Updt-Allow').attr('checked')?1:0;
		
		//var sprint_status = parseInt($('#gnt-sprint-status').val());
		var sprint_velocity = parseFloat($('#gnt-sprint-velocity').val().replace(/[^0-9\-\.]/g, ''));
		
		//	alert(submitType);


		//return false;   // REMOVE ---------
		$.ajax({
			url: "phpAgileService.php",
			type: 'POST',
			data: {
				"page": 'sprint-node-add-insert',
				"project-id": $('#gantt-select-devp').val(),
				"submit-action": submitType, 
				"node-id": $('#div-entity-id-edit').val(), 
				"node-name": $('#gntNode-name-dyn').val(), 
				"node-notes": $('#gnt-task-notes').val(), 
				"task-type": $('#gnt-task-type').val(), 
				"deliverables": deliverables,
				"reviews": reviews,
				"recurance-basis": $('#gnt-task-recr').val(), 
				"recur-week-days": $('#week_days_list').val(),                      
				"recur-month-date": $('#month_dates_list').val(),
				"recur-meetings": recur_meeting,   //checkbox
				"recur-reports": recur_report,   //checkbox
				"day-display": day_display,   //checkbox
				"start-date": $('#gnt-start-date').val(),
				"task-duration": $('#gnt-duration').val(), 
				"end-date": $('#gnt-end-date').val(),                      
				"res-var-costs": $('#gnt-resource-cost').val(),										
				"compute-ot": compute_ot,   //checkbox
				"task-CA": $('#gnt-CA').val(), 
				"fixed-cost": packFixedCost(),    
				"work-duration-link": wrk_dur,        //checkbox      
				"allowed-ot-hours": $('#gnt-ot-hours').val(), 	
				"task-work": $('#gnt-work').val(), 

				"res-mode-rate":  packActResWork(),
				"task_priority": $('#gnt-priority').val(), 
				"task-constraint": $('#gnt-task-constrain').val(),  
				"task-contr-date": $('#gnt-constrain-date').val(),
				"work-ratio-tolerance": $('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, ''), 
				"work-ratio-tolerance-notes": $('#gnt-wrTolerance-desc').val(), 
				"update-permit": updt_allow,
				
				//"sprint-status": sprint_status,
				"sprint-velocity": sprint_velocity,
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				//alert(response);
				//return false;
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "noExist") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							//$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); 
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	}
	
	
	//alert(packFixedCost()); 
	//alert(packActResWork());
	//alert(submitType+' - '+$('#div-entity-id-edit').val());
}




// Function to submit (Save) Add or Insert request from dynamic screen

function submitTaskAddIns(submitType) {
	empty_message_box("gntFl-message-box");
	show_upload_started();
	if (validateNodeDetails(submitType) == false) {
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E');
	} else { 
		 
		var deliverables = $('#gnt-deliverables').attr('checked')?1:0;
		var reviews = $('#gnt-reviews').attr('checked')?1:0;
		var recur_meeting = $('#gnt-recur-meeting').attr('checked')?1:0;
		var recur_report = $('#gnt-recur-report').attr('checked')?1:0;
		var day_display = $('#gnt-display-day').attr('checked')?0:1; // This is reverse in jsGantt if 1 Cal days
		var compute_ot = $('#gnt-ot-allowance').attr('checked')?1:0;
		var wrk_dur = $('#gnt-Work-Dur').attr('checked')?1:0;
		var updt_allow = $('#gnt-Updt-Allow').attr('checked')?1:0;
		
		var task_work_contour = "P";
		var task_work_rate = 0;
		var task_alloted_work = 0;
		var res_total_work = 0;
		
		if ((prjAgility == 1) && (parseInt($('#gnt-task-type').val()) == 0)){
			task_work_contour = $('#gnt-work-contour').val();
			task_work_rate = parseFloat($('#gnt-work-rate').val().replace(/[^0-9\-\.]/g, ''));
			task_alloted_work = parseFloat($('#gnt-available-hrs').val().replace(/[^0-9\-\.]/g, ''));
			res_total_work = GetResourceTotalWork();
		}


		//return false;   // REMOVE ---------
		$.ajax({
			url: "phpGanttService.php",
			type: 'POST',
			data: {
				"page": 'gnt-node-add-insert',
				"project-id": $('#gantt-select-devp').val(),
				"submit-action": submitType, 
				"node-id": $('#div-entity-id-edit').val(), 
				"node-name": $('#gntNode-name-dyn').val(), 
				"node-notes": $('#gnt-task-notes').val(), 
				"task-type": $('#gnt-task-type').val(), 
				"deliverables": deliverables,
				"reviews": reviews,
				"recurance-basis": $('#gnt-task-recr').val(), 
				"recur-week-days": $('#week_days_list').val(),                      
				"recur-month-date": $('#month_dates_list').val(),
				"recur-meetings": recur_meeting,   //checkbox
				"recur-reports": recur_report,   //checkbox
				"day-display": day_display,   //checkbox
				"start-date": $('#gnt-start-date').val(),
				"task-duration": $('#gnt-duration').val(), 
				"end-date": $('#gnt-end-date').val(),                      
				"res-var-costs": $('#gnt-resource-cost').val(),										
				"compute-ot": compute_ot,   //checkbox
				"task-CA": $('#gnt-CA').val(), 
				"fixed-cost": packFixedCost(),    
				"work-duration-link": wrk_dur,        //checkbox      
				"allowed-ot-hours": $('#gnt-ot-hours').val(), 	
				"task-work": $('#gnt-work').val(), 

				"res-mode-rate":  packActResWork(),
				"task_priority": $('#gnt-priority').val(), 
				"task-constraint": $('#gnt-task-constrain').val(),  
				"task-contr-date": $('#gnt-constrain-date').val(),
				"work-ratio-tolerance": $('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, ''), 
				"work-ratio-tolerance-notes": $('#gnt-wrTolerance-desc').val(), 
				"update-permit": updt_allow,
				
				"task-work-contour": task_work_contour,
				"task-work-rate": task_work_rate,
				"task-alloted-work": task_alloted_work,
				"res-total-work": res_total_work,
				"user-id": user_id
			},
			timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			}, 
			success: function(response) {
				hide_message_box("gntFl-message-box");
				//alert(response);
				//return false;
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() { // multiple errors in data array
							$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "noExist") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							//$.popgFLfrm._hide();
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					if ($('a.MultiFile-remove','#delivUploadList').length > 0) {
					//alert('Succ');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-elf" name="element" value="deliverable-file" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entityf" name="page" value="delivToUpload" style="display:none"/>');
						$('#delivUploadData').append('<input type="text"  id="deliv-entity-idf" name="field" style="display:none" value="'+$('#gantt-select-devp').val()+'^'+response[0][0].data[0]['node-id']+'"/>'); 
						$('#btnUploadDeliv').trigger('click'); 	
					}	
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							//ProjAddReload(); 
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					}   
				} 
			}
		});	
	
	}
	
	
	//alert(packFixedCost()); 
	//alert(packActResWork());
	//alert(submitType+' - '+$('#div-entity-id-edit').val());
}


function validateNodeDetails(submitType) {
	var ValidationStatus = true;
	var ValidStatus = [];
	var inp = '';
	MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'gntNode-name-dyn',
			mn_length: 2,
			mx_length: 240,
			strg_type: 'atext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidationStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>New Task Name</b></p>').append(MesgStrg);
	}
	
	if ((prjAudit == 1) && (prjStatus == 1)) {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Change Request Details</b></p>').append(MesgStrg);
			}		
	} else {
		var inp = $('#gnt-task-notes').val();
		if (inp.length > 0) {	
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-task-notes',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Notes</b></p>').append(MesgStrg);
			}		
		}
	}
	if ($('#gnt-task-type').val() == '2') {               
		if ($('#gnt-task-recr').val() == '1') {  // weekly selected
			if ($("#week_days_list").val().length == 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Reccurrance Basis</b></p>').append('<p>&#9830; Week Days not selected</p>');
			}		
		} else if ($('#gnt-task-recr').val() == '2') { // monthly selected
			if ($("#month_dates_list").val().length == 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Reccurrance Basis</b></p>').append('<p>&#9830; Monthly Dates not selected</p>');
			}		
		} 
	}
	if (prjAgility == 0) {
		if (parseInt($('#gnt-wrTolerance').val().replace(/[^0-9\-\.]/g, '')) == 0) {
			var inp = $('#gnt-wrTolerance-desc').val();
			if (inp.length > 0) {	
				MesgStrg = '';
				MesgStrg += validate({ 
						elem_id: 'gnt-wrTolerance-desc',
						mn_length: 2,
						mx_length: 300,
						strg_type: 'ctext',
						msg_type: 'mesg-box'
					});
				if (MesgStrg.length > 0) {
					ValidationStatus = false;
					$("#gntFl-message-box").append('<br/><p><b>Work Ratio Tolerance Basis</b></p>').append(MesgStrg);
				}		
			}
		} else {
			MesgStrg = '';
			MesgStrg += validate({ 
					elem_id: 'gnt-wrTolerance-desc',
					mn_length: 2,
					mx_length: 300,
					strg_type: 'ctext',
					msg_type: 'mesg-box'
				});
			if (MesgStrg.length > 0) {
				ValidationStatus = false;
				$("#gntFl-message-box").append('<br/><p><b>Work Ratio Tolerance Basis</b></p>').append(MesgStrg);
			}		
		}
	}
	if (prjAgility == 1) {
		if ((submitType == 'addsprint') || (submitType == 'insertsprint')){
			if (parseFloat($('#gnt-sprint-velocity').val().replace(/[^0-9\-\.]/g, '')) <= 0) {
				$("#gntFl-message-box").append('<br/><p><b>Sprint Velocity</b></p>').append('<p>&#9830; Sprint Velocity not acceptable</p>');	
			}	
		} else {
			if (parseFloat($('#gnt-available-hrs').val().replace(/[^0-9\-\.]/g, '')) > parseFloat($('#prnt-available-hrs').val().replace(/[^0-9\-\.]/g, ''))) {
				$("#gntFl-message-box").append('<br/><p><b>Task Work Allotment</b></p>').append('<p>&#9830; Task has been alloted with Story points greater than available</p>');	
			}	
		}
		if (parseFloat($('#tsk-available-hrs').val().replace(/[^0-9\-\.]/g, '')) < 0) {
			$("#gntFl-message-box").append('<br/><p><b>Resource Work Allotment</b></p>').append('<p>&#9830; Resources have been alloted with Story points greater than available</p>');	
		}
	}
	
	if (ValidationStatus == false) {
		return false; 
	}; 
	
	ValidationStatus = validateFixedCost();
	
	if (ValidationStatus == false) {
		return false; 
	}; 
	
	return ValidationStatus;
	
}

function validateFixedCost() {
	
	var numItems = $('[name^="fix-cost"]').length;
	var cost_amt_id = [];
	var cost_amt_val = [];
	$('[name^="cost-amt"]').each(function() {
					cost_amt_id.push($(this).attr("id")); 
					cost_amt_val.push($(this).val().replace(/[^0-9\-\.]/g, ''));
	});
	var cost_desc_id = [];
	var cost_desc_val = [];
	$('[name^="cost-desc"]').each(function() {
					cost_desc_id.push($(this).attr("id")); 
					cost_desc_val.push($(this).val());
	});
	//hide_all_errors();
	
	var ValidationStatus = true;
	var ValidStatus = [];
	var inp = '';
	for(i=0; i<numItems; i++){
		
		var dispNum = i+1;
		var MesgStrg = '';
		MesgStrg += validate({
				elem_id: cost_desc_id[i],
				mn_length: 2,
				mx_length: 120,
				strg_type: 'ctext',
				msg_type: 'mesg-box'
			});
		if (parseFloat(cost_amt_val[i]) <= 0) {	
			MesgStrg += '<p>&#9830; Fixed Cost left as Zero (0)</p>';
		}; 
		if (MesgStrg.length > 0) {
			ValidStatus.push(false);
			$("#gntFl-message-box").append('<br/><p><b>Fixed Cost Description</b>&nbsp;-&nbsp'+dispNum+'</p>').append(MesgStrg);
		};	
	};
	
	for(i=0; i<ValidStatus.length; i++){
		if (ValidStatus[i] == false) {
			ValidationStatus = false;
			break;
		};
	};
	return ValidationStatus;
}

function packFixedCost() {        

	var numItems = $('[name^="fix-cost"]').length;
	var cost_amt_id = [];
	var cost_amt_val = [];
	$('[name^="cost-amt"]').each(function() {
					cost_amt_id.push($(this).attr("id")); 
					cost_amt_val.push($(this).val().replace(/[^0-9\-\.]/g, ''));
	});
	var cost_desc_id = [];
	var cost_desc_val = [];
	$('[name^="cost-desc"]').each(function() {
					cost_desc_id.push($(this).attr("id")); 
					cost_desc_val.push($(this).val());
	});
	var fc_str = '';
	if ($('[name^="cost-amt"]').length > 0) {
		for(i=0; i<numItems; i++){
			fc_str += cost_desc_val[i]+'*!*'+cost_amt_val [i];
			if (i < numItems - 1) fc_str += '*$*';
		}
	}
	return fc_str;
}

function packActResWork() {
	var selectRes = $("#gnt_task_resources_list").val().split(",");
	
	var resource_id = [];
	var resource_rate = [];
	$('[name^="rate_"]').each(function() {
					resource_id.push($(this).attr("id").replace(/[^0-9]/g, ''));
					resource_rate.push($(this).val());
	});	
	var resource_work = [];
	$('[name^="work_"]').each(function() {
					resource_work.push($(this).val());
	});	
	var resource_mode = [];
	$('[name^="mode_"]').each(function() {
					resource_mode.push($(this).val());
	});	

	var resWork_str = '';
	if ($('[name^="rate_"]').length > 0) {
		for(i=0; i<selectRes.length; i++){
			resWork_str += resource_id[i]+'*!*'+resource_mode[i]+'*!*'+resource_rate[i]+'*!*'+resource_work[i];
			if (i < selectRes.length - 1) resWork_str += '*$*';
		}
	}
	//alert('ResPack'+resWork_str+'dss');
	return resWork_str;
}

function RecalcResrcWork() {
	
	if ($('[name^="work_"]').length > 0) {
		$('[name^="work_"]').each(function() {
			var selectRes = $(this).attr("id").split("_");
			var thisResID = parseInt(selectRes[1]);
			//alert(thisResID);
			if ($('#mode_'+thisResID).val() == 'P') {
				$("#work_"+thisResID).val((parseFloat(parseFloat($("#gnt-available-hrs").val()) * parseFloat($("#rate_"+thisResID).val().replace(/[^0-9\-\.]/g, '')) / 100).toFixed(2)));
			}
		});	
	}
	UpdateTaskAvailableWork(); 
	
	return true;
}

function UpdateTaskAvailableWork() {
	
	var resource_tot_work = 0;
	if ($('[name^="work_"]').length > 0) {
		$('[name^="work_"]').each(function() {
			var thisResID = parseInt($(this).attr("name"));
			if ($('#mode_'+thisResID).val() == 'P') {
				$("#work_"+thisResID).val((parseFloat(parseFloat($("#gnt-available-hrs").val()) * parseFloat($("#rate_"+thisResID).val().replace(/[^0-9\-\.]/g, ''))).toFixed(2)));
			}
		});	
	
		$('[name^="work_"]').each(function() {
				resource_tot_work += parseFloat($(this).val().replace(/[^0-9\-\.]/g, ''));
		});	
	}
	$("#tsk-available-hrs").val((parseFloat(parseFloat($("#gnt-available-hrs").val()) - resource_tot_work).toFixed(2))); 
	return true;
}

function GetResourceTotalWork() {
	
	var resource_tot_work = 0;
	if ($('[name^="work_"]').length > 0) {
		$('[name^="work_"]').each(function() {
				resource_tot_work += parseFloat($(this).val().replace(/[^0-9\-\.]/g, ''));
		});	
	}
	
	return resource_tot_work;
}

/*------------- END of Project Gantt Nodes Edit --------------     */


