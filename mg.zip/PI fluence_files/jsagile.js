var JSAgile;
if (!JSAgile) JSAgile = {};
var vTimeout = 0;
var vBenchTime = new Date().getTime();
JSAgile.TaskItem = function (pID, pName, pStart, pEnd, pColor, pLink, pMile, pBudgetWork, pRes, pComp, pGroup, pParent, pOpen, pDepend, pCaption, pCost, pRole, pWork, pCalDay, pRtask, pEstimWork, pAdjEstWrk, pConstDate, pNotes, pNumDocs, pFixedCost, pActualWork, pCtrlAccnt, pRisks, ptIssues, poIssues, ptCRs, poCRs, ptBDs, poBDs, pActStart, pActEnd, pActCost, pActFixedCost, pActDuration, pTotCost, pTotWork, pAdjCost, pAdjWork, pWorkTolnce, pWorkTolnceNotes, pAgile, pRelsdWork, pFlagValue, psColor) {
    var vID = pID;
    var vName = pName;
    var vStart = new Date();
    var vEnd = new Date();
    var vColor = pColor;
	var vAgile = pAgile;
    var vLink = pLink;
    var vCost = pCost;
    var vRole = pRole;
    var vWork = pWork;
    var vCalDay = pCalDay;
    var vRtask = pRtask;
    var vNotes = pNotes;
    var vNumDocs = pNumDocs;
    var vEstimWork = pEstimWork;
    var vAdjEstWrk = pAdjEstWrk;
    var vConstDate = pConstDate;
    var vFixedCost = pFixedCost;
	var vActualWork = pActualWork;
	var vCtrlAccnt = pCtrlAccnt;
	var vRisks = pRisks;
	var vtIssues = ptIssues;
	var voIssues = poIssues;
	var vtCRs = ptCRs;
	var voCRs = poCRs;
	var vtBDs = ptBDs;
	var voBDs = poBDs;

	var vActStart = new Date();
	var vActEnd = new Date();
	var vActCost = pActCost; 
	var vActFixedCost = pActFixedCost;
	var vActDuration = pActDuration;
	
	var vTotCost = pTotCost; 
	var vTotWork = pTotWork;
	var vAdjCost = pAdjCost;
	var vAdjWork = pAdjWork;
	var vWorkTolnce = pWorkTolnce;
	var vWorkTolnceNotes = pWorkTolnceNotes;
    var vMile = pMile;
	var vBudgetWork = pBudgetWork;
    var vRes = pRes;
    var vComp = parseInt(pComp);
    var vsComp = parseFloat(pComp).toFixed(2);
    var vGroup = pGroup;
    var vParent = pParent;
    var vOpen = pOpen;
    var vDepend = pDepend;
    var vCaption = pCaption;
    var vDuration = '';
	
	var vRelsdWork= pRelsdWork;
	var vsColor = psColor;
	var vFlagValue = pFlagValue;
	
	
    var vLevel = 0;
    var vNumKid = 0;
    var vVisible = 1;
    var x1, y1, x2, y2;

    this.getFlagValue = function () {
		var zFlagValue = vFlagValue;
		if (zFlagValue < 0) zFlagValue = -1 * zFlagValue;
        return zFlagValue
    };
	
    this.getFlagSign = function () {
		var zFlagSign = '';
		if (vFlagValue < 0) zFlagSign = 'sprOvLd';
        return zFlagSign
    };
	
    this.getStryStsStr = function () {
        if (vFlagValue == 1) return 'Removed';
			else if (vFlagValue == 2) return 'Completed';
			else if (vFlagValue == 3) return 'Progress';
			else if (vFlagValue == 4) return 'Scheduled';
			else if (vFlagValue == 5) return 'Delayed';
			else if (vFlagValue == 6) return 'Backlog';
			else if (vFlagValue == 7) return 'Backlog';
			
			else if ((vFlagValue == 20) || (vFlagValue == -20)) return ' ';
			else if ((vFlagValue == 21) || (vFlagValue == -21)) return ' ';
			else if ((vFlagValue == 22) || (vFlagValue == -22)) return ' ';
			else if ((vFlagValue == 23) || (vFlagValue == -23)) return ' ';
			else if ((vFlagValue == 24) || (vFlagValue == -24)) return ' ';
			
			
			else return ' ';
    };
	
    if (vGroup != 1) {
        vStart = JSAgile.parseDateStr(pStart, g.getDateInputFormat());
        vEnd = JSAgile.parseDateStr(pEnd, g.getDateInputFormat());
    }
    this.getID = function () {
        return vID
    };
    this.getName = function () {
        return vName
    };
    this.getStart = function () {
        return vStart
    };
    this.getEnd = function () {
        return vEnd
    };

	if (pActStart != '-') vActStart = JSAgile.parseDateStr(pActStart, g.getDateInputFormat());
		else vActStart = pActStart;
    this.getActStart = function () {
        return vActStart
    };
	
	if (pActEnd != '-') vActEnd = JSAgile.parseDateStr(pActEnd, g.getDateInputFormat());
		else vActEnd = pActEnd;
    this.getActEnd = function () {
        return vActEnd
    };
	
    this.getActualCost = function () {
        return vActCost
    };
	
    this.getActFixedCost = function () {
        return vActFixedCost
    };
	
    this.getActDuration = function () {
        return vActDuration
    };
	
    this.getTotalCost = function () {
        return vTotCost
    };
	
    this.getAdjustedCost = function () {
        return vAdjCost
    };

    this.getWorkToleranceStr = function () {
        if (vWorkTolnce == 0) return "-";
			else return vWorkTolnce.toFixed(2)+"%";
    };
    this.getTolnceNotes = function () {
        return vWorkTolnceNotes;
    };
	
    this.getColor = function () {
        return vColor
    };
    this.getStsColor = function () {
        return vsColor
    };
	
	
    this.getAgile = function () {
        return vAgile
    };

    this.getLink = function () {
        return vLink
    };
    this.getCost = function () {
        return vCost
    };
	
    this.getWork = function () {
        var zWork = parseFloat(vWork).toFixed(2);
		if (zWork > 0) {
			if (WorkShow == 'H') return zWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zWork = parseFloat(zWork / prjSp2Hrs).toFixed(2);
					return zWork + ' Sps';
			    } else return zWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getActualWork = function () {
        var zActualWork = parseFloat(vActualWork).toFixed(2);
		if (zActualWork > 0) {
			if (WorkShow == 'H') return zActualWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zActualWork = parseFloat(zActualWork / prjSp2Hrs).toFixed(2);
					return zActualWork + ' Sps';
			    } else return zActualWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getTotalWork = function () {
        var zTotalWork = parseFloat(vTotWork).toFixed(2);
		if (zTotalWork > 0) {
			if (WorkShow == 'H') return zTotalWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zTotalWork = parseFloat(zTotalWork / prjSp2Hrs).toFixed(2);
					return zTotalWork + ' Sps';
			    } else return zTotalWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getAdjustedWork = function () {
        var zAdjustWork = parseFloat(vAdjWork).toFixed(2);
		if (zAdjustWork > 0) {
			if (WorkShow == 'H') return zAdjustWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zAdjustWork = parseFloat(zAdjustWork / prjSp2Hrs).toFixed(2);
					return zAdjustWork + ' Sps';
			    } else return zAdjustWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
	this.getBudgetWork = function () {
        var zBdjWork = parseFloat(vBudgetWork).toFixed(2);
		if (zBdjWork > 0) {
			if (WorkShow == 'H') return zBdjWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zBdjWork = parseFloat(zBdjWork / prjSp2Hrs).toFixed(2);
					return zBdjWork + ' Sps';
			    } else return zBdjWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getEstimWork = function () {
       // return vEstimWork;
        var zEstWork = parseFloat(vEstimWork).toFixed(2);
		if (zEstWork > 0) {
			if (WorkShow == 'H') return zEstWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zEstWork = parseFloat(zEstWork / prjSp2Hrs).toFixed(2);
					return zEstWork + ' Sps';
			    } else return zEstWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getAdjtEstimate = function () { 
        var zAdjEstWrk = parseFloat(vAdjEstWrk).toFixed(2);
		if (zAdjEstWrk > 0) {
			if (WorkShow == 'H') return zAdjEstWrk + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zAdjEstWrk = parseFloat(zAdjEstWrk / prjSp2Hrs).toFixed(2);
					return zAdjEstWrk + ' Sps';
			    } else return zAdjEstWrk + ' Hrs';
			}
		} else return '-';
    } // Compute Hour or Day here  MSD 
	
    this.getReleasedWork = function () { 
        var zRelsdWrk = parseFloat(vRelsdWork).toFixed(2);
		if (zRelsdWrk > 0) {
			if (WorkShow == 'H') return zRelsdWrk + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zRelsdWrk = parseFloat(zRelsdWrk / prjSp2Hrs).toFixed(2);
					return zRelsdWrk + ' Sps';
			    } else return zRelsdWrk + ' Hrs';
			}
		} else return '-';
    } // Compute Hour or Day here  MSD 
	
	
	
	//=====================
	this.getTRisks = function () {
		return vRisks;
    };

	this.getTIssues = function () {
		return vtIssues;
    };
	
	this.getOIssues = function () {
		return voIssues;
    };
	this.getTCRs = function () {
		return vtCRs;
    };
	
	this.getOCRs = function () {
		return voCRs;
    };
	this.getTBDs = function () {
		return vtBDs;
    };
	
	this.getOBDs = function () {
		return voBDs;
    };
	
	
	
	
	
	
	
	//==============
	
    this.getCalDay = function () {
        return parseInt(vCalDay)
    };
    this.getRtask = function () {
        return vRtask;
    };
    this.getNotes = function () {
        return vNotes;
    };
    this.getConstDate = function () {
        return vConstDate
    };
    this.getNumDocs = function () {
        return vNumDocs
    };

    this.getFixedCost = function () {
        return vFixedCost
    };
	this.getCtrlAccnt = function () {
        return vCtrlAccnt
    };
	
	this.getMile = function () {
        return vMile
    };
	
    this.getDepend = function () {
        if (vDepend) return vDepend;
        else return ''
    };
    this.getCaption = function () {
        if (vCaption) return vCaption;
        else return '';
    };
    this.getResource = function () {
        if (RoleName == 1) {
            if (vRes) return vRes;
            else return '&nbsp';
        } else {
            if (vRole) return vRole;
            else return '&nbsp';
        }
    };
    this.getCompVal = function () {
        if (vComp) return vComp;
        else return 0;
    }; // Remove getCompVal getCompStr
    this.getProgressVal = function () {
        if (vsComp) return vsComp;
        else return 0;
    };
    this.getCompStr = function () {
		if (ProgressActual == 0) {
			return this.getProgressStr();
		} else {
			var wWork = this.getWork();
				wWork = parseInt(wWork.replace(/[^0-9\-\.]/g, ''));
			var wActualWork = this.getActualWork();
				wActualWork = parseInt(wActualWork.replace(/[^0-9\-\.]/g, ''));
			var vWComp = 0;
			if (wWork > 0) vWComp = parseFloat(wActualWork / wWork * 100).toFixed(2);
			
			if (vWComp > 0) return vWComp + '%';
			else return '';
			
			//return '';       //.replace(/[^0-9\-\.]/g, '') getWork getActualWork 
		}
    };
	
    this.getStsCompStr = function () {
		var vWComp = parseInt((ColWidths[0]['StoryStatus'] + 21) * vsComp / 100);
		if (vWComp > 0) return vWComp + 'px';
			else return '0px';
    };
	
	// getStsReleseStr
    this.getStsReleseStr = function () {
		var baseVal = parseFloat(vBudgetWork);
		if (baseVal < parseFloat(vEstimWork)) baseVal = parseFloat(vEstimWork);
		var vWComp = parseInt((ColWidths[0]['StoryStatus'] + 21) * parseFloat(vRelsdWork) / baseVal);
		if (vWComp > 0) return vWComp + 'px';
			else return '0px';
    };
	
    this.getActWorkRatioStr = function () {
		var wWork = this.getWork();
			wWork = parseInt(wWork.replace(/[^0-9\-\.]/g, ''));
		var wActualWork = this.getActualWork();
			wActualWork = parseInt(wActualWork.replace(/[^0-9\-\.]/g, ''));
		var vWComp = 0;
		if (wWork > 0) vWComp = parseFloat(wActualWork / wWork * 100).toFixed(2);
		
		if (vWComp > 0) return vWComp + '%';
		else return '';
    };
	
    this.getProgressStr = function () {
        if (vsComp > 0) return vsComp + '%';
        else return '';
    };
    this.getDuration = function (vFormat) {
        var actualDate = this.getStart();
        var newDate = new Date(actualDate.getFullYear(), actualDate.getMonth(), actualDate.getDate() + 4);
        if (vMile) vDuration = '-';
        else if (vFormat == 'hour') {
            tmpPer = Math.ceil((this.getEnd() - this.getStart()) / (60 * 60 * 1000));
            if (tmpPer == 1) vDuration = '1 Hour';
            else vDuration = tmpPer + ' Hours';
        } else if (vFormat == 'minute') {
            tmpPer = Math.ceil((this.getEnd() - this.getStart()) / (60 * 1000));
            if (tmpPer == 1) vDuration = '1 Minute';
            else vDuration = tmpPer + ' Minutes';
        } else { //if(vFormat == 'day') {
            tmpPer = Math.ceil((this.getEnd() - this.getStart()) / (24 * 60 * 60 * 1000) + 1);
            if (this.getCalDay() == 0) {
                var bDays = 0;
                for (ij = 0; ij < tmpPer; ij++) { //check for <=
                    refDate = new Date(this.getStart().getFullYear(), this.getStart().getMonth(), this.getStart().getDate() + ij);
                    if (checkWeekEnd(refDate) == false) {
                        if (checkHoliDay(refDate) == false) bDays++;
                    }
                }
                tmpPer = bDays;
            }
            if (tmpPer == 1) {
                if (this.getCalDay() == 0) vDuration = '1 Day';
                else vDuration = '1 Cal-day';
            } else {
                if (this.getCalDay() == 0) vDuration = tmpPer + ' Days';
                else vDuration = tmpPer + ' Cal-days';
            };
        }
        return (vDuration)
    };
    this.getParent = function () {
        return vParent
    };
    this.getGroup = function () {
        return vGroup
    };
    this.getOpen = function () {
        return vOpen
    };
    this.getLevel = function () {
        return vLevel
    };
    this.getNumKids = function () {
        return vNumKid
    };
    this.getStartX = function () {
        return x1
    };
    this.getStartY = function () {
        return y1
    };
    this.getEndX = function () {
        return x2
    };
    this.getEndY = function () {
        return y2
    };
    this.getVisible = function () {
        return vVisible
    };
    this.setDepend = function (pDepend) {
        vDepend = pDepend;
    };
    this.setStart = function (pStart) {
        vStart = pStart;
    };

    this.setEnd = function (pEnd) {
        vEnd = pEnd;
    };
    this.setLevel = function (pLevel) {
        vLevel = pLevel;
    };
    this.setNumKid = function (pNumKid) {
        vNumKid = pNumKid;
    };
    this.setCompVal = function (pCompVal) {
        vComp = pCompVal;
    };
    this.setStartX = function (pX) {
        x1 = pX;
    };
    this.setStartY = function (pY) {
        y1 = pY;
    };
    this.setEndX = function (pX) {
        x2 = pX;
    };
    this.setEndY = function (pY) {
        y2 = pY;
    };
    this.setOpen = function (pOpen) {
        vOpen = pOpen;
    };
    this.setVisible = function (pVisible) {
        vVisible = pVisible;
    };

};

JSAgile.GanttChart = function (pGanttVar, pDiv, pFormat) {
    var vGanttVar = pGanttVar;
    var vDiv = pDiv;
    var vFormat = pFormat;
    var vShowRes = 1;
    var vShowDur = 1;
    var vShowComp = 1;
    var vShowStartDate = 1;
    var vShowEndDate = 1;
    var vDateInputFormat = "mm/dd/yyyy";
    var vDateDisplayFormat = "mm/dd/yy";
    var vNumUnits = 0;
    var vCaptionType;
    var vDepId = 1;
    var vTaskList = new Array();
    var vFormatArr = new Array("day", "week", "month", "quarter");
    var vQuarterArr = new Array(1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4);
    var vMonthDaysArr = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    var vMonthArr = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    this.setFormatArr = function () {
        vFormatArr = new Array();
        for (var i = 0; i < arguments.length; i++) {
            vFormatArr[i] = arguments[i];
        }
        if (vFormatArr.length > 4) {
            vFormatArr.length = 4;
        }
    };
    this.setShowRes = function (pShow) {
        vShowRes = pShow;
    };
    this.setShowDur = function (pShow) {
        vShowDur = pShow;
    };
    this.setShowComp = function (pShow) {
        vShowComp = pShow;
    };
    this.setShowStartDate = function (pShow) {
        vShowStartDate = pShow;
    };
    this.setShowEndDate = function (pShow) {
        vShowEndDate = pShow;
    };
    this.setDateInputFormat = function (pShow) {
        vDateInputFormat = pShow;
    };
    this.setDateDisplayFormat = function (pShow) {
        vDateDisplayFormat = pShow;
    };
    this.setCaptionType = function (pType) {
        vCaptionType = pType
    };
    this.setFormat = function (pFormat) {
        vFormat = pFormat;
        this.Draw();
    };
    this.getShowRes = function () {
        return vShowRes
    };
    this.getShowDur = function () {
        return vShowDur
    };
    this.getShowComp = function () {
        return vShowComp
    };
    this.getShowStartDate = function () {
        return vShowStartDate
    };
    this.getShowEndDate = function () {
        return vShowEndDate
    };
    this.getDateInputFormat = function () {
        return vDateInputFormat
    };
    this.getDateDisplayFormat = function () {
        return vDateDisplayFormat
    };
    this.getCaptionType = function () {
        return vCaptionType
    };

    this.AddTaskItem = function (value) {
        vTaskList.push(value);
    };
    this.getList = function () {
        return vTaskList
    };
 /*   this.sLine = function (x1, y1, x2, y2) {

        vLeft = Math.min(x1, x2);
        vTop = Math.min(y1, y2);
        vWid = Math.abs(x2 - x1) + 1;
        vHgt = Math.abs(y2 - y1) + 1;

        vDoc = document.getElementById('rightside');

        // retrieve DIV
        var oDiv = document.createElement('div');

        oDiv.id = "line" + vDepId++;
        oDiv.style.position = "absolute";
        oDiv.style.margin = "0px";
        oDiv.style.padding = "0px";
        oDiv.style.overflow = "hidden";
        oDiv.style.border = "0px";

        // set attributes
        oDiv.style.zIndex = 0;
        oDiv.style.backgroundColor = "#0F1131"; //#F44269 change the color to suitable one dependency lines--MSD
        oDiv.style.left = vLeft + "px";
        oDiv.style.top = vTop + "px";
        oDiv.style.width = vWid + "px";
        oDiv.style.height = vHgt + "px";

        oDiv.style.visibility = "visible";

        vDoc.appendChild(oDiv);

    };

    this.dLine = function (x1, y1, x2, y2) {

        var dx = x2 - x1;
        var dy = y2 - y1;
        var x = x1;
        var y = y1;

        var n = Math.max(Math.abs(dx), Math.abs(dy));
        dx = dx / n;
        dy = dy / n;
        for (i = 0; i <= n; i++) {
            vx = Math.round(x);
            vy = Math.round(y);
            this.sLine(vx, vy, vx, vy);
            x += dx;
            y += dy;
        };

    }; */

    this.DrawDependencies = function () {
		return false;
    };

    this.getArrayLocationByID = function (pId) {

        var vList = this.getList();
        for (var i = 0; i < vList.length; i++) {
            if (vList[i].getID() == pId) return i;
        }
    };

    this.Draw = function () {
        var vMaxDate = new Date();
        var vMinDate = new Date();
        var vTmpDate = new Date();
        var vNxtDate = new Date();
        var vCurrDate = new Date();
        var vTaskLeft = 0;
        var vTaskRight = 0;
        var vNumCols = 0;
        var vID = 0;
        var vMainTable = "";
        var vLeftTable = "";
        var vRightTable = "";
        var vDateRowStr = "";
        var vItemRowStr = "";
        var vColWidth = 0;
        var vColUnit = 0;
        var vChartWidth = 0;
        var vNumDays = 0;
        var vDayWidth = 0;
        var vStr = "";

        var vNameWidth = ColWidths[0]['Tasks'];
        var vIDWidth = ColWidths[0]['ID'];
        var vNotesWidth = ColWidths[0]['Notes'];
		
		var vRegistryWidth = ColWidths[0]['Registry'];
		
        var vBudgetWorkWidth = ColWidths[0]['BudgetWork']; // This is utilized for Budget Work
        var vResourceWidth = ColWidths[0]['Resource'];
        var vDurationWidth = ColWidths[0]['Duration'];
        var vCostWidth = ColWidths[0]['Cost'];
        var vProgressWidth = ColWidths[0]['Progress'] + 40;
        var vStartDateWidth = ColWidths[0]['StartDate'];
        var vEndDateWidth = ColWidths[0]['EndDate'];
        var vWorkWidth = ColWidths[0]['Work'] + 40;
        var vAdjtEstimateWidth = ColWidths[0]['AdjtEstimate'];
        var vEstimateWorkWidth = ColWidths[0]['EstimateWork'];
        var vFixedCostWidth = ColWidths[0]['FixedCost'];
		var vActualWorkWidth = ColWidths[0]['ActualWork'] + 40;
		var vActWorkRatioWidth = ColWidths[0]['ActWorkRatio'];
		var vCtrlAccntWidth = ColWidths[0]['CtrlAccnt'];
		
		var vActStartDateWidth = ColWidths[0]['ActStartDate'];
		var vActEndDateWidth = ColWidths[0]['ActEndDate'];
		var vActCostWidth = ColWidths[0]['ActualCost'];
		var vActFixedCostWidth = ColWidths[0]['ActFixedCost'];
		var vActDurationWidth = ColWidths[0]['ActDuration'];
		var vTotCostWidth = ColWidths[0]['TotalCost'];
		var vTotWorkWidth = ColWidths[0]['TotalWork'];
		var vAdjCostWidth = ColWidths[0]['AdjustedCost'];
		var vAdjWorkWidth = ColWidths[0]['AdjustedWork'];
		var vWorkToleranceWidth = ColWidths[0]['WorkTolerance'];
		var vReleasedWorkWidth = ColWidths[0]['ReleasedWork'];
		var vStoryStatusWidth = ColWidths[0]['StoryStatus'];
		
		
        var vScreenWidth = ColWidths[0]['Screen'];
        var vLeftWidth = 0;

        if (vTaskList.length > 0) {

            JSAgile.processRows(vTaskList, 0, -1, 1, 1);
            vMinDate = JSAgile.getMinDate(vTaskList, vFormat);
            vMaxDate = JSAgile.getMaxDate(vTaskList, vFormat);
            if (vFormat == 'day') {
                vColWidth = 18;
                vColUnit = 1;
            } else if (vFormat == 'week') {
                vColWidth = 37;
                vColUnit = 7;
            } else if (vFormat == 'month') {
                vColWidth = 37;
                vColUnit = 30;
            } else if (vFormat == 'quarter') {
                vColWidth = 60;
                vColUnit = 90;
            } else if (vFormat == 'hour') {
                vColWidth = 18;
                vColUnit = 1;
            } else if (vFormat == 'minute') {
                vColWidth = 18;
                vColUnit = 1;
            }

            vNumDays = (Date.parse(vMaxDate) - Date.parse(vMinDate)) / (24 * 60 * 60 * 1000);
            vNumUnits = vNumDays / vColUnit;

            vChartWidth = vNumUnits * vColWidth + 1;
            vDayWidth = (vColWidth / vColUnit) + (1 / vColUnit);

            //  from here --------------------------------------------------------------- getPriority

            vMainTable = '<TABLE id=theTable cellSpacing=0 cellPadding=0 border=0 style="margin: 0px auto;"><TBODY><TR>' + '<TD vAlign=top bgColor=#ffffff>';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
                case 'Notes':
                    vLeftWidth += vNotesWidth + 35;
                    break;
                case 'Registry':
                    vLeftWidth += vRegistryWidth + 35;
                    break;
                case 'Tasks': 
                    vLeftWidth += vNameWidth + 21;
                    break;
                case 'Resource':
                    vLeftWidth += vResourceWidth + 21;
                    break;
                case 'Duration':
                    vLeftWidth += vDurationWidth + 21;
                    break;
                case 'Cost':
                    vLeftWidth += vCostWidth + 21;
                    break;
                case 'Progress':
                    vLeftWidth += vProgressWidth + 22;
                    break;
                case 'StartDate':
                    vLeftWidth += vStartDateWidth + 21;
                    break;
                case 'EndDate':
                    vLeftWidth += vEndDateWidth + 21;
                    break;
					
                case 'ActStartDate':
                    vLeftWidth += vActStartDateWidth + 21;
                    break;
                case 'ActEndDate':
                    vLeftWidth += vActEndDateWidth + 21;
                    break;
					
                case 'BudgetWork':
                    vLeftWidth += vBudgetWorkWidth + 23;
                    break;
                case 'ID':
                    vLeftWidth += vIDWidth + 21;
                    break;
                case 'Work':
                    vLeftWidth += vWorkWidth + 24;
                    break;
                case 'AdjtEstimate':
                    vLeftWidth += vAdjtEstimateWidth + 21;
                    break;
                case 'EstimateWork':
                    vLeftWidth += vEstimateWorkWidth + 21;
                    break;
                case 'FixedCost':
                    vLeftWidth += vFixedCostWidth + 21;
                    break;
                case 'ActualWork':
                    vLeftWidth += vActualWorkWidth + 24;
                    break;
                case 'ActWorkRatio':
                    vLeftWidth += vActWorkRatioWidth + 22;
                    break;
                case 'CtrlAccnt':
                    vLeftWidth += vCtrlAccntWidth + 21;
                    break;
                case 'ActualCost':
                    vLeftWidth += vActCostWidth + 21;
                    break;
				case 'ActFixedCost':
                    vLeftWidth += vActFixedCostWidth + 21;
                    break;	
                case 'ActDuration':
                    vLeftWidth += vActDurationWidth + 21;
                    break;
				case 'TotalCost':
                    vLeftWidth += vTotCostWidth + 21;
                    break;
				case 'TotalWork':
                    vLeftWidth += vTotWorkWidth + 21;
                    break;
				case 'AdjustedCost':
                    vLeftWidth += vAdjCostWidth + 21;
                    break;
				case 'AdjustedWork':
                    vLeftWidth += vAdjWorkWidth + 21;
                    break; 
				case 'WorkTolerance':
                    vLeftWidth += vWorkToleranceWidth + 21;
                    break;
				case 'ReleasedWork':
					vLeftWidth += vReleasedWorkWidth + 21;
					break;               
				case 'StoryStatus':
					vLeftWidth += vStoryStatusWidth + 21;
					break;
					
				
                }
            }
			
            if(vLeftWidth > vScreenWidth) vLeftWidth = vScreenWidth;  
			//if(vLeftWidth < 1000) vLeftWidth = 1000; 

            var lsDisplay = "block";
            var rsDisplay = "block";
            switch (sgMode) {
            case 0:
                {
                    lsDisplay = "block";
                    rsDisplay = "block";
                    break;
                }
            case 1:
                {
                    lsDisplay = "block";
                    rsDisplay = "none";
                    break;
                }

            case 2:
                {
                    lsDisplay = "none";
                    rsDisplay = "block";
                    break;
                }

            }

            // DRAW the Left-side of the chart MSD -- add display none to hide DIV id leftside to hide spreadsheet
            vLeftTable = '<DIV class=scroll id=leftside style="width:' + vLeftWidth + 'px; display:' + lsDisplay + ';">' +
            //'<DIV id=lefttopfill style="width:' + vLeftWidth + 'px; HEIGHT: 17px"></DIV>' +
            '<TABLE id="tLeft" cellSpacing=0 cellPadding=0 border=0><THEAD>';

            vLeftTable += '<TR style="HEIGHT: 25px">';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
                case 'Notes':
                    vLeftTable += '<TH id="Notes_h" class="lTabCol" style="WIDTH: ' + vNotesWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap><div style="font-size: 18px;"><b><i>i</i></b></div></TH>'; // <img src="css/jsgantt/info.jpg" width="23" height="17">
                    break;
					
                case 'Registry':
                    vLeftTable += '<TH id="Registry_h" class="lTabCol" style="WIDTH: ' + vRegistryWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Registers</TH>'; // <img src="css/jsgantt/info.jpg" width="23" height="17">
                    break;
					
                case 'Tasks':
                    vLeftTable += '<TH id="Tasks_h" class="lTabCol" style="WIDTH: ' + vNameWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Description</TH>';
                    break;
                case 'Resource':
                    vLeftTable += '<TH id="Resource_h" class="lTabCol" style="WIDTH: ' + vResourceWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Resources</TH>';
                    break;
                case 'Duration':
                    vLeftTable += '<TH id="Duration_h" class="lTabCol" style="WIDTH: ' + vDurationWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Duration</TH>';
                    break;
                case 'Cost':
                    vLeftTable += '  <TH id="Cost_h" class="lTabCol" style="WIDTH: ' + vCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Cost</TH>';
                    break;
                case 'Progress':
                    vLeftTable += '  <TH id="Progress_h" class="lTabCol" style="WIDTH: ' + vProgressWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Progress</TH>';
                    break;
                case 'StartDate':
                    vLeftTable += '  <TH id="StartDate_h" class="lTabCol" style="WIDTH: ' + vStartDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Start Date</TH>';
                    break;
                case 'EndDate':
                    vLeftTable += '  <TH id="EndDate_h" class="lTabCol" style="WIDTH: ' + vEndDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>End Date</TH>';
                    break;
					
                case 'ActStartDate':
                    vLeftTable += '  <TH id="ActStartDate_h" class="lTabCol" style="WIDTH: ' + vActStartDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Start</TH>';
                    break;
                case 'ActEndDate':
                    vLeftTable += '  <TH id="ActEndDate_h" class="lTabCol" style="WIDTH: ' + vActEndDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual End</TH>';
                    break;
					
					
					
                case 'BudgetWork':
                    vLeftTable += '  <TH id="BudgetWork_h" class="lTabCol" style="WIDTH: ' + vBudgetWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Budget Work</TH>';
                    break;
                case 'ID':
                    vLeftTable += '  <TH id="ID_h" class="lTabCol" style="WIDTH: ' + vIDWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>ID</TH>';
                    break;
                case 'Work':
                    vLeftTable += '  <TH id="Work_h" class="lTabCol" style="WIDTH: ' + vWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Picked Work</TH>';
                    break;
                case 'AdjtEstimate':
                    vLeftTable += '  <TH id="AdjtEstimate_h" class="lTabCol" style="WIDTH: ' + vAdjtEstimateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Adjusted:Alloted</TH>';
                    break;
                case 'EstimateWork':
                    vLeftTable += '  <TH id="EstimateWork_h" class="lTabCol" style="WIDTH: ' + vEstimateWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Alloted Work</TH>';
                    break;
                case 'FixedCost':
                    vLeftTable += '  <TH id="FixedCost_h" class="lTabCol" style="WIDTH: ' + vFixedCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Fixed Cost</TH>';
                    break;
                case 'ActualWork':
                    vLeftTable += '  <TH id="ActualWork_h" class="lTabCol" style="WIDTH: ' + vActualWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Work</TH>';
                    break;
                case 'ActWorkRatio':
                    vLeftTable += '  <TH id="ActWorkRatio_h" class="lTabCol" style="WIDTH: ' + vActWorkRatioWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Work Ratio</TH>';
                    break;
                case 'CtrlAccnt':
                    vLeftTable += '  <TH id="CtrlAccnt_h" class="lTabCol" style="WIDTH: ' + vCtrlAccntWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Control Account</TH>';
                    break;
                case 'ActualCost':
                    vLeftTable += '  <TH id="ActualCost_h" class="lTabCol" style="WIDTH: ' + vActCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Cost</TH>';
                    break;
                case 'ActFixedCost':
                    vLeftTable += '  <TH id="ActFixedCost_h" class="lTabCol" style="WIDTH: ' + vActFixedCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Fixed Cost</TH>';
                    break;
                case 'ActDuration':
                    vLeftTable += '<TH id="ActDuration_h" class="lTabCol" style="WIDTH: ' + vActDurationWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Actual Duration</TH>';
                    break;
                case 'TotalCost':
                    vLeftTable += '  <TH id="TotalCost_h" class="lTabCol" style="WIDTH: ' + vTotCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Total Cost</TH>';
                    break;
                case 'TotalWork':
                    vLeftTable += '  <TH id="TotalWork_h" class="lTabCol" style="WIDTH: ' + vTotWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Total Work</TH>';
                    break;
                case 'AdjustedCost':
                    vLeftTable += '  <TH id="AdjustedCost_h" class="lTabCol" style="WIDTH: ' + vAdjCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Adjusted Cost</TH>';
                    break;
                case 'AdjustedWork':
                    vLeftTable += '  <TH id="AdjustedWork_h" class="lTabCol" style="WIDTH: ' + vAdjWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Adjusted:Picked</TH>';
                    break;
                case 'WorkTolerance':
                    vLeftTable += '  <TH id="WorkTolerance_h" class="lTabCol" style="WIDTH: ' + vWorkToleranceWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap>Work Tolerance</TH>';
                    break;
                case 'ReleasedWork':
                    vLeftTable += '  <TH id="ReleasedWork_h" class="lTabCol" style="WIDTH: ' + vReleasedWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Released Work</TH>';
                    break;
                case 'StoryStatus': 
                    vLeftTable += '  <TH id="StoryStatus_h" class="lTabCol" style="WIDTH: ' + vStoryStatusWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Status</TH>';
                    break;
				
                }
            }
            vLeftTable += '</TR><TR style="HEIGHT: 15px">';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
                case 'Notes':
                    vLeftTable += '<TD id="Notes" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vNotesWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
					
                case 'Registry':
                    vLeftTable += '<TD id="Registry" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vRegistryWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
					
                case 'Tasks':
                    vLeftTable += '<TD id="Tasks" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vNameWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Resource':
                    vLeftTable += '<TD id="Resource" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vResourceWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Duration':
                    vLeftTable += '<TD id="Duration" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vDurationWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Cost':
                    vLeftTable += '  <TD id="Cost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Progress':
                    vLeftTable += '  <TD id="Progress" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vProgressWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'StartDate':
                    vLeftTable += '  <TD id="StartDate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vStartDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'EndDate':
                    vLeftTable += '  <TD id="EndDate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vEndDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
					
                case 'ActStartDate':
                    vLeftTable += '  <TD id="ActStartDate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActStartDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ActEndDate':
                    vLeftTable += '  <TD id="ActEndDate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActEndDateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;

			
					
                case 'BudgetWork':
                    vLeftTable += '  <TD id="BudgetWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vBudgetWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ID':
                    vLeftTable += '  <TD id="ID" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vIDWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Work':
                    vLeftTable += '  <TD id="Work" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'AdjtEstimate':
                    vLeftTable += '  <TD id="AdjtEstimate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vAdjtEstimateWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'EstimateWork':
                    vLeftTable += '  <TD id="EstimateWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vEstimateWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'FixedCost':
                    vLeftTable += '  <TD id="FixedCost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vFixedCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'ActualWork':
                    vLeftTable += '  <TD id="ActualWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActualWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ActWorkRatio':
                    vLeftTable += '  <TD id="ActWorkRatio" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActWorkRatioWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'CtrlAccnt':
                    vLeftTable += '  <TD id="CtrlAccnt" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vCtrlAccntWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ActualCost':
                    vLeftTable += '  <TD id="ActualCost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ActFixedCost':
                    vLeftTable += '  <TD id="ActFixedCost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActFixedCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'ActDuration':
                    vLeftTable += '<TD id="ActDuration" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vActDurationWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'TotalCost':
                    vLeftTable += '  <TD id="TotalCost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vTotCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'TotalWork':
                    vLeftTable += '  <TD id="TotalWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vTotWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'AdjustedCost':
                    vLeftTable += '  <TD id="AdjustedCost" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vAdjCostWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'AdjustedWork':
                    vLeftTable += '  <TD id="AdjustedWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vAdjWorkWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'WorkTolerance':
                    vLeftTable += '  <TD id="WorkTolerance" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vWorkToleranceWidth + 'px" onclick="JSAgile.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ReleasedWork':
                    vLeftTable += '  <TD id="ReleasedWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vReleasedWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'StoryStatus':
                    vLeftTable += '  <TD id="StoryStatus" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vStoryStatusWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
				
				
                }
            }

            vLeftTable += '</TR></THEAD><TBODY>';

            for (i = 0; i < vTaskList.length; i++) {
                if (vTaskList[i].getGroup()) {
                    if (vTaskList[i].getLink() % 2 == 1) {
                        vBGColor = "ffffff";
                    } else {
                        vBGColor = "eee";
                    }
                    vRowType = "group"; // Row colors  MSD 98F8ED
                } else {
                    if (vTaskList[i].getLink() % 2 == 1) {
                        vBGColor = "ffffff";
                    } else {
                        vBGColor = "eee";
                    }
                    vRowType = "row";
                }

                vID = vTaskList[i].getID();

                if (vTaskList[i].getVisible() == 0) vLeftTable += '<TR id=child_' + vID + ' bgcolor=#' + vBGColor + ' style="display:none"  onMouseover=g.mouseOver(this,' + vID + ',"left","' + vRowType + '") onMouseout=g.mouseOut(this,' + vID + ',"left","' + vRowType + '")>';
					else vLeftTable += '<TR id=child_' + vID + ' bgcolor=#' + vBGColor + ' onMouseover=g.mouseOver(this,' + vID + ',"left","' + vRowType + '") onMouseout=g.mouseOut(this,' + vID + ',"left","' + vRowType + '")>';
				
				var pblcVwCol = (publicView == 0) ? " lTabCol" : " nlTabCol";
				var pblcVwCur = (publicView == 0) ? "pointer" : "default";
				for (colC = 0; colC < ColOrder.length; colC++) {

                    blankattach = 'blank_indicator';
                    blanknotes = 'blank_indicator';
                    blankconstr = 'blank_indicator';
					
                    blankrisk = 'blank_indicator';
                    blankissue = 'blank_indicator';
                    blankcrs = 'blank_indicator';
					blankbds = 'blank_indicator';
                    switch (ColOrder[colC]) {
                    case 'Notes':
                        vLeftTable += '<TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Notes"); style="WIDTH: ' + vNotesWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" >' + '<div id="tattach_' + vTaskList[i].getID() + '" class="' + blankattach + '">&nbsp;&nbsp;&nbsp;&nbsp;</div>' + '<div id="tnotes_' + vTaskList[i].getID() + '" class="' + blanknotes + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tconstr_' + vTaskList[i].getID() + '" class="' + blankconstr + '">&nbsp&nbsp&nbsp&nbsp</div>' + '</TD>';
                        break;
						
						
                    case 'Registry':
                        vLeftTable += '<TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Registry"); style="WIDTH: ' + vRegistryWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" >' + '<div id="trisk_' + vTaskList[i].getID() + '" class="' + blankrisk + '">&nbsp;&nbsp;&nbsp;&nbsp;</div>' + '<div id="tissue_' + vTaskList[i].getID() + '" class="' + blankissue + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tcrs_' + vTaskList[i].getID() + '" class="' + blankcrs + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tbds_' + vTaskList[i].getID() + '" class="' + blankbds + '">&nbsp&nbsp&nbsp&nbsp</div>' + '</TD>';
                        break;
						
						
                    case 'Tasks':
                        {
                            vLeftTable += '<TD class="gname '+ pblcVwCol +'" style="WIDTH: ' + vNameWidth + 'px" nowrap><NOBR><span style="color: #aaaaaa">';

                            for (j = 1; j < vTaskList[i].getLevel(); j++) {
                                vLeftTable += '&nbsp&nbsp';
                            }
                            vLeftTable += '</span>';
							
							if (vTaskList[i].getAgile() == 4) {
                                taskClr = MileClr;
                            } else if (vTaskList[i].getAgile() == 3) {
                                taskClr = StryClr;
                            } else {
                                if (vTaskList[i].getGroup()) {
                                    if (vTaskList[i].getRtask() == 1) taskClr = RGrpClr;
                                    else taskClr = GroupClr;
                                } else {
                                    if (vTaskList[i].getRtask() == 2) taskClr = RTskClr;
                                    else taskClr = NormClr;
                                }
                            }
							
							
							

							cpmClass = 'NonCritTask';
							
                            if (vTaskList[i].getGroup()) {
                                if (vTaskList[i].getOpen() == 1) vLeftTable += '<DIV id="group_' + vID + '" class="openGroup" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" onclick="JSAgile.folder(' + vID + ',' + vGanttVar + ');' + vGanttVar + '.DrawDependencies();"></DIV><span style="color:#000000">&nbsp</SPAN>';
									else vLeftTable += '<DIV id="group_' + vID + '" class="closeGroup" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" onclick="JSAgile.folder(' + vID + ',' + vGanttVar + ');' + vGanttVar + '.DrawDependencies();"></DIV><span style="color:#000000">&nbsp</SPAN>';
                            } else {
                                vLeftTable += '<span style="color: #000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px">&nbsp&nbsp&nbsp</span>';
                            }
							if (vTaskList[i].getID() == 1) {
								if (prjLockSts == 1) vLeftTable += '<DIV id="lock_' + vID + '" class="lockPrjkt" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Tasks");></DIV><span style="color:#000000">&nbsp</SPAN>';
								if (prjNdaSts == 1) vLeftTable += '<DIV id="nda_' + vID + '" class="ndaPrjkt" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Tasks");></DIV><span style="color:#000000">&nbsp</SPAN>';
							}

                            vLeftTable += '<span ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Tasks"); class="'+ cpmClass +'" style="WIDTH: ' + vNameWidth + 'px; OVERFLOW: hidden; TEXT-ALIGN: left; DISPLAY:inline-block; color: #' + taskClr + '" > ' + vTaskList[i].getName() + '</span></NOBR></TD>';
                            break;
                        }
                    case 'Resource':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Resource"); style="WIDTH: ' + vResourceWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vResourceWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getResource() + '</span></NOBR></TD>';
                        break;
                    case 'Duration':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Duration"); style="WIDTH: ' + vDurationWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getDuration(vFormat) + '</NOBR></TD>';
                        break;
                    case 'Cost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Cost"); style="WIDTH: ' + vCostWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getCost() + '</NOBR></TD>';
                        break;
                    case 'Progress':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Progress"); style="WIDTH: ' + vProgressWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getProgressStr() + '</NOBR></TD>';
                        break;
                    case 'StartDate':
                        // MSD Adjusted start Date as per earliest child end date
                        if (prjkt[i]["pStart"] != JSAgile.formatDateStr(vTaskList[i].getStart(), vDateInputFormat)) prjkt[i]["pStart"] = JSAgile.formatDateStr(vTaskList[i].getStart(), vDateInputFormat);
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","StartDate"); style="WIDTH: ' + vStartDateWidth + 'px; TEXT-ALIGN: center;" align=center><NOBR>' + JSAgile.formatDateStr(vTaskList[i].getStart(), vDateDisplayFormat) + '</NOBR></TD>';
                        break;
                    case 'EndDate':
                        // MSD Adjusted End Date as per latest child end date
                        if (prjkt[i]["pEnd"] != JSAgile.formatDateStr(vTaskList[i].getEnd(), vDateInputFormat)) prjkt[i]["pEnd"] = JSAgile.formatDateStr(vTaskList[i].getEnd(), vDateInputFormat);
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","EndDate"); style="WIDTH: ' + vEndDateWidth + 'px; TEXT-ALIGN: center;" align=center><NOBR>' + JSAgile.formatDateStr(vTaskList[i].getEnd(), vDateDisplayFormat) + '</NOBR></TD>';
                        break;
						
                    case 'ActStartDate':
                        // MSD Adjusted start Date as per earliest child end date
						if (vTaskList[i].getActStart() != '-') var actStDte = JSAgile.formatDateStr(vTaskList[i].getActStart(), vDateDisplayFormat);
							else var actStDte = vTaskList[i].getActStart();
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActStartDate"); style="WIDTH: ' + vActStartDateWidth + 'px; TEXT-ALIGN: center;" align=center><NOBR>' + actStDte + '</NOBR></TD>';
                        break;
                    case 'ActEndDate':
                        // MSD Adjusted start Date as per earliest child end date
						if (vTaskList[i].getActEnd() != '-') var actEnDte = JSAgile.formatDateStr(vTaskList[i].getActEnd(), vDateDisplayFormat);
							else var actEnDte = vTaskList[i].getActEnd();
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActStartDate"); style="WIDTH: ' + vActEndDateWidth + 'px; TEXT-ALIGN: center;" align=center><NOBR>' + actEnDte + '</NOBR></TD>';
                        break;


					
						
                    case 'BudgetWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","BudgetWork"); style="WIDTH: ' + vBudgetWorkWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR>' + vTaskList[i].getBudgetWork() + '</NOBR></TD>';
                        break;
                    case 'ID':
                        // MSD Include right click option
						
						if (vTaskList[i].getAgile() == 5) {
							taskTyp = 'gntRoot_';
						} else if (vTaskList[i].getAgile() == 4) {
							taskTyp = 'gntSprt_';
						} else if (vTaskList[i].getAgile() == 3) {
							taskTyp = 'gntStry_';
						} else {
							if (vTaskList[i].getGroup()) {
								if (vTaskList[i].getRtask() == 1) taskTyp = 'gntRGnode_';
								else taskTyp = 'gntnode_';
							} else {
								if (vTaskList[i].getRtask() == 2) taskTyp = 'gntRTnode_';
								else taskTyp = 'gntnode_';
							}
						}
						
                        if (vTaskList[i].getMile()) vLeftTable += '  <TD id="gntMlnode_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ID"); style="WIDTH: ' + vIDWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getLink() + '</NOBR></TD>';
                        else vLeftTable += '  <TD id="' + taskTyp + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ID"); style="WIDTH: ' + vIDWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getLink() + '</NOBR></TD>';
                        break;
                    case 'Work':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Work"); style="WIDTH: ' + vWorkWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getWork() + '</NOBR></TD>';
                        break;
                    case 'AdjtEstimate':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","AdjtEstimate"); style="WIDTH: ' + vAdjtEstimateWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vAdjtEstimateWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getAdjtEstimate() + '</span></NOBR></TD>';
                        break;
                    case 'EstimateWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","EstimateWork"); style="WIDTH: ' + vEstimateWorkWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vEstimateWorkWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getEstimWork() + '</span></NOBR></TD>';
                        break;
                    case 'FixedCost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","FixedCost"); style="WIDTH: ' + vFixedCostWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vFixedCostWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getFixedCost() + '</span></NOBR></TD>';
                        break;
                    case 'ActualWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActualWork"); style="WIDTH: ' + vActualWorkWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getActualWork() + '</NOBR></TD>';
                        break;
                    case 'ActWorkRatio':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActWorkRatio"); style="WIDTH: ' + vActWorkRatioWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getActWorkRatioStr() + '</NOBR></TD>';
                        break;
                    case 'CtrlAccnt':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","CtrlAccnt"); style="WIDTH: ' + vCtrlAccntWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" align=center><NOBR>' + vTaskList[i].getCtrlAccnt() + '</NOBR></TD>';
                        break;
                    case 'ActualCost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActualCost"); style="WIDTH: ' + vActCostWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getActualCost() + '</NOBR></TD>';
                        break;
                    case 'ActFixedCost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActFixedCost"); style="WIDTH: ' + vActFixedCostWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vActFixedCostWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getActFixedCost() + '</span></NOBR></TD>';
                        break;
                    case 'ActDuration':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ActDuration"); style="WIDTH: ' + vActDurationWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getActDuration() + '</NOBR></TD>';
                        break;
                    case 'TotalCost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","TotalCost"); style="WIDTH: ' + vTotCostWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getTotalCost() + '</NOBR></TD>';
                        break;
                    case 'TotalWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","TotalWork"); style="WIDTH: ' + vTotWorkWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getTotalWork() + '</NOBR></TD>';
                        break;
                    case 'AdjustedCost':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","AdjustedCost"); style="WIDTH: ' + vAdjCostWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getAdjustedCost() + '</NOBR></TD>';
                        break;
                    case 'AdjustedWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","AdjustedWork"); style="WIDTH: ' + vAdjWorkWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getAdjustedWork() + '</NOBR></TD>';
                        break;
                    case 'WorkTolerance':
                        vLeftTable += '  <TD  id="twtnotes_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","WorkTolerance"); style="WIDTH: ' + vWorkToleranceWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getWorkToleranceStr() + '</NOBR></TD>';
                        break;
                    case 'ReleasedWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","ReleasedWork"); style="WIDTH: ' + vReleasedWorkWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vReleasedWorkWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getReleasedWork() + '</span></NOBR></TD>';
                        break;
                    case 'StoryStatus':
                        if (vTaskList[i].getStsColor() != 'ffffff') vLeftTable += '  <TD id="tstysts_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" style="background-color:#' + vTaskList[i].getStsColor() + '; opacity:0.9; position: relative; " ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","StoryStatus"); style="WIDTH: ' + vStoryStatusWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px">' + '<div style="Z-INDEX: 10; float:left; background-color:#'+ gRlsClr +'; height:12px; filter: alpha(opacity=70); opacity:0.7; width:' + vTaskList[i].getStsReleseStr() + '; overflow:hidden">' + '</div>' + '<div style="position: absolute; Z-INDEX: -4; float:left; background-color:#'+ gBakClr +'; height:5px; margin-top:2px; filter: alpha(opacity=50); opacity:0.5; width:' + vTaskList[i].getStsCompStr() + '; overflow:hidden">' + '</div>'+'<DIV style="position: absolute; float: center; Z-INDEX: 2; width: 100%; height: 100%; left: 0;"><NOBR>' + vTaskList[i].getStryStsStr() + '</NOBR></DIV>'+'</TD>';
							else vLeftTable += '  <TD id="tstysts_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" style="opacity:0.9; position: relative; " ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","StoryStatus"); style="WIDTH: ' + vStoryStatusWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px">' + '<div style="Z-INDEX: 10; float:left; background-color:#'+ gRlsClr +'; height:12px; filter: alpha(opacity=70); opacity:0.7; width:' + vTaskList[i].getStsReleseStr() + '; overflow:hidden">' + '</div>' + '<div style="position: absolute; Z-INDEX: -4; float:left; background-color:#'+ gBakClr +'; height:5px; margin-top:2px; filter: alpha(opacity=50); opacity:0.5; width:' + vTaskList[i].getStsCompStr() + '; overflow:hidden">' + '</div>'+'<DIV style="position: absolute; float: center; Z-INDEX: 2; width: 100%; height: 100%; left: 0;"><NOBR>' + vTaskList[i].getStryStsStr() + '</NOBR></DIV>'+'</TD>';
						break;
						
						
						
						
                    }
                }

                vLeftTable += '</TR>';
            }
            vLeftTable += '</TD></TR>';
            vLeftTable += '</TBODY></TABLE></DIV>';
            vLeftTable += '<DIV id=leftbotfill style="width:' + vLeftWidth + 'px; HEIGHT: 20px; display:none">'; //MSD
            vLeftTable += '<p border=1 align=left style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 11px; BORDER-LEFT: #efefef 1px solid; height=18px; ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Display Format:';

            if (vFormatArr.join().indexOf("minute") != -1) {
                if (vFormat == 'minute') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="minute" checked>Minute';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("minute",' + vGanttVar + '); VALUE="minute">Minute';
            }

            if (vFormatArr.join().indexOf("hour") != -1) {
                if (vFormat == 'hour') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="hour" checked>Hour';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("hour",' + vGanttVar + '); VALUE="hour">Hour';
            }

            if (vFormatArr.join().indexOf("day") != -1) {
                if (vFormat == 'day') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="day" checked>Day';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("day",' + vGanttVar + '); VALUE="day">Day';
            }

            if (vFormatArr.join().indexOf("week") != -1) {
                if (vFormat == 'week') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="week" checked>Week';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("week",' + vGanttVar + ') VALUE="week">Week';
            }

            if (vFormatArr.join().indexOf("month") != -1) {
                if (vFormat == 'month') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="month" checked>Month';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("month",' + vGanttVar + ') VALUE="month">Month';
            }

            if (vFormatArr.join().indexOf("quarter") != -1) {
                if (vFormat == 'quarter') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="quarter" checked>Quarter';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSAgile.changeFormat("quarter",' + vGanttVar + ') VALUE="quarter">Quarter';
            }

            vLeftTable += '</p></DIV></TD>';
            vMainTable += vLeftTable;

            // Draw the Chart Rows    Right table starts here ---- MSD add display none to below TD remove gantt
            var rsWidth = 0;
			var scroller = 'noClass';
            if (vChartWidth > 480) {
				rsWidth = 480;
				scroller = 'scroll2';
			} else rsWidth = vChartWidth;
				
            vRightTable = '<TD style="width: ' + rsWidth + 'px;display:' + rsDisplay + ';" vAlign=top>' + '<DIV class='+scroller+' id=rightside style="display:' + rsDisplay + ';">' + '<TABLE style="width: ' + vChartWidth + 'px;" cellSpacing=0 cellPadding=0 border=0>' + '<TBODY><TR style="HEIGHT: 20px">';

            vTmpDate.setFullYear(vMinDate.getFullYear(), vMinDate.getMonth(), vMinDate.getDate());
            vTmpDate.setHours(0);
            vTmpDate.setMinutes(0);

            while (Date.parse(vTmpDate) <= Date.parse(vMaxDate)) {
                vStr = vTmpDate.getFullYear() + '';
                vStr = vStr.substring(2, 4);

                if (vFormat == 'minute') {
                    vRightTable += '<td class=gdatehead style="FONT-SIZE: 12px; HEIGHT: 22px;" align=center colspan=60>';
                    vRightTable += JSAgile.formatDateStr(vTmpDate, vDateDisplayFormat) + ' ' + vTmpDate.getHours() + ':00 -' + vTmpDate.getHours() + ':59 </td>';
                    vTmpDate.setHours(vTmpDate.getHours() + 1);
                }

                if (vFormat == 'hour') {
                    vRightTable += '<td class=gdatehead style="FONT-SIZE: 12px; HEIGHT: 22px;" align=center colspan=24>';
                    vRightTable += JSAgile.formatDateStr(vTmpDate, vDateDisplayFormat) + '</td>';
                    vTmpDate.setDate(vTmpDate.getDate() + 1);
                }

                if (vFormat == 'day') { // MSD  width: ' + rsWidth + 'px;
                    vRightTable += '<td class="gdatehead sdatehead" style="FONT-SIZE: 12px; HEIGHT: 22px;" align=center colspan=7>';
                    if (vTmpDate < vMaxDate) vRightTable += JSAgile.formatDateStr(vTmpDate, vDateDisplayFormat.substring(0, 5));
                    vTmpDate.setDate(vTmpDate.getDate() + 6); // Check here  MSD
                    if (vTmpDate < vMaxDate) vRightTable += ' - ' + JSAgile.formatDateStr(vTmpDate, vDateDisplayFormat) + '</td>';
                    else vRightTable += '</td>';
                    vTmpDate.setDate(vTmpDate.getDate() + 1);
                } else if (vFormat == 'week') {
                    vRightTable += '<td class="gdatehead sdatehead" align=center style="FONT-SIZE: 12px; HEIGHT: 22px;" width=' + vColWidth + 'px>`' + vStr + '</td>';
                    vTmpDate.setDate(vTmpDate.getDate() + 7);
                } else if (vFormat == 'month') {
                    vRightTable += '<td class="gdatehead sdatehead" align=center style="FONT-SIZE: 12px; HEIGHT: 22px;" width=' + vColWidth + 'px>`' + vStr + '</td>';
                    vTmpDate.setDate(vTmpDate.getDate() + 1);
                    while (vTmpDate.getDate() > 1) {
                        vTmpDate.setDate(vTmpDate.getDate() + 1);
                    }
                } else if (vFormat == 'quarter') {
                    vRightTable += '<td class="gdatehead sdatehead" align=center style="FONT-SIZE: 12px; HEIGHT: 22px;" width=' + vColWidth + 'px>`' + vStr + '</td>';
                    vTmpDate.setDate(vTmpDate.getDate() + 81);
                    while (vTmpDate.getDate() > 1) {
                        vTmpDate.setDate(vTmpDate.getDate() + 1);
                    }
                }

            }

            vRightTable += '</TR><TR>';

            // Minor Date header and Cell Rows
            vTmpDate.setFullYear(vMinDate.getFullYear(), vMinDate.getMonth(), vMinDate.getDate());
            vNxtDate.setFullYear(vMinDate.getFullYear(), vMinDate.getMonth(), vMinDate.getDate());
            vNumCols = 0;

            while (Date.parse(vTmpDate) <= Date.parse(vMaxDate)) {
                if (vFormat == 'minute') {

                    if (vTmpDate.getMinutes() == 0) vWeekdayColor = "ccccff";
                    else vWeekdayColor = "ffffff";


                    vDateRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getMinutes() + '</div></td>';
                    vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    vTmpDate.setMinutes(vTmpDate.getMinutes() + 1);
                } else if (vFormat == 'hour') {

                    if (vTmpDate.getHours() == 0) vWeekdayColor = "ccccff";
                    else vWeekdayColor = "ffffff";


                    vDateRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getHours() + '</div></td>';
                    vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    vTmpDate.setHours(vTmpDate.getHours() + 1);
                } else if (vFormat == 'day') {
                    if (JSAgile.formatDateStr(vCurrDate, 'mm/dd/yyyy') == JSAgile.formatDateStr(vTmpDate, 'mm/dd/yyyy')) {
                        vWeekdayColor = "ccccff";
                        vWeekendColor = "9999ff";
                        vWeekdayGColor = "bbbbff";
                        vWeekendGColor = "8888ff";
                    } else {
                        vWeekdayColor = "ffffff";
                        vWeekendColor = "cfcfcf";
                        vWeekdayGColor = "eee";
                        vWeekendGColor = "c3c3c3";
                    }


                    if (chgdateFormat(vTmpDate) == prjStartDt) {
                        vDateRowStr += '<td class="gheadwkend sheadprjst" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getDate() + '</div></td>';
                        vItemRowStr += '<td class="gheadwkend sheadprjst" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp</div></td>';

                    } else if (chgdateFormat(vTmpDate) == prjEndDt) {
                        vDateRowStr += '<td class="gheadwkend sheadprjet" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getDate() + '</div></td>';
                        vItemRowStr += '<td class="gheadwkend sheadprjet" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp</div></td>';

                    } else if (checkWeekEnd(vTmpDate) || checkHoliDay(vTmpDate)) {
                        vDateRowStr += '<td class="gheadwkend sheadwkend" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getDate() + '</div></td>';
                        vItemRowStr += '<td class="gheadwkend sheadwkend" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekendColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp</div></td>';
                    } else {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">' + vTmpDate.getDate() + '</div></td>';
                        if (JSAgile.formatDateStr(vCurrDate, 'mm/dd/yyyy') == JSAgile.formatDateStr(vTmpDate, 'mm/dd/yyyy')) vItemRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; cursor: default;"  align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    }

                    vTmpDate.setDate(vTmpDate.getDate() + 1);

                } else if (vFormat == 'week') {

                    vNxtDate.setDate(vNxtDate.getDate() + 7);

                    if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vWeekdayColor = "ccccff";
                    else vWeekdayColor = "ffffff";

                    if (vNxtDate <= vMaxDate) {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">' + (vTmpDate.getMonth() + 1) + '/' + vTmpDate.getDate() + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';

                    } else {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid; bgcolor=#' + vWeekdayColor + ' BORDER-RIGHT: #efefef 1px solid;" align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">' + (vTmpDate.getMonth() + 1) + '/' + vTmpDate.getDate() + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';

                    }

                    vTmpDate.setDate(vTmpDate.getDate() + 7);

                } else if (vFormat == 'month') {

                    vNxtDate.setFullYear(vTmpDate.getFullYear(), vTmpDate.getMonth(), vMonthDaysArr[vTmpDate.getMonth()]);
                    if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vWeekdayColor = "ccccff";
                    else vWeekdayColor = "ffffff";

                    if (vNxtDate <= vMaxDate) {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">' + vMonthArr[vTmpDate.getMonth()].substr(0, 3) + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    } else {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">' + vMonthArr[vTmpDate.getMonth()].substr(0, 3) + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    }

                    vTmpDate.setDate(vTmpDate.getDate() + 1);

                    while (vTmpDate.getDate() > 1) {
                        vTmpDate.setDate(vTmpDate.getDate() + 1);
                    }

                } else if (vFormat == 'quarter') {

                    vNxtDate.setDate(vNxtDate.getDate() + 122);
                    if (vTmpDate.getMonth() == 0 || vTmpDate.getMonth() == 1 || vTmpDate.getMonth() == 2) vNxtDate.setFullYear(vTmpDate.getFullYear(), 2, 31);
                    else if (vTmpDate.getMonth() == 3 || vTmpDate.getMonth() == 4 || vTmpDate.getMonth() == 5) vNxtDate.setFullYear(vTmpDate.getFullYear(), 5, 30);
                    else if (vTmpDate.getMonth() == 6 || vTmpDate.getMonth() == 7 || vTmpDate.getMonth() == 8) vNxtDate.setFullYear(vTmpDate.getFullYear(), 8, 30);
                    else if (vTmpDate.getMonth() == 9 || vTmpDate.getMonth() == 10 || vTmpDate.getMonth() == 11) vNxtDate.setFullYear(vTmpDate.getFullYear(), 11, 31);

                    if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vWeekdayColor = "ccccff";
                    else vWeekdayColor = "ffffff";

                    if (vNxtDate <= vMaxDate) {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">Qtr. ' + vQuarterArr[vTmpDate.getMonth()] + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    } else {
                        vDateRowStr += '<td class="ghead shead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; HEIGHT: 22px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center width:' + vColWidth + 'px><div style="width: ' + vColWidth + 'px">Qtr. ' + vQuarterArr[vTmpDate.getMonth()] + '</div></td>';
                        if (vCurrDate >= vTmpDate && vCurrDate < vNxtDate) vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" bgcolor=#' + vWeekdayColor + ' align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                        else vItemRowStr += '<td class="ghead" style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 12px; BORDER-LEFT: #efefef 1px solid; BORDER-RIGHT: #efefef 1px solid;" align=center><div style="width: ' + vColWidth + 'px">&nbsp&nbsp</div></td>';
                    }

                    vTmpDate.setDate(vTmpDate.getDate() + 81);

                    while (vTmpDate.getDate() > 1) {
                        vTmpDate.setDate(vTmpDate.getDate() + 1);
                    }

                }
            }

            vRightTable += vDateRowStr + '</TR>';
            vRightTable += '</TBODY></TABLE>';

            // Draw each row
           /* if ($.browser.chrome) rwHeight = 20;
            else if ($.browser.safari) rwHeight = 20;
            else if ($.browser.msie) rwHeight = 24;
            else rwHeight = 24; */

			rwHeight = brow_height;
			var barColor = (ProgressActual == 0) ? gCmpClr : gActClr;
			var barGrpClr = (ProgressActual == 0) ? '6BA7A4' : 'B77EBF';
            for (i = 0; i < vTaskList.length; i++) {

               /* if (vTaskList[i].getLink() % 5 > 0) {
                    if ($.browser.chrome) rwHeight = 25;
                    else if ($.browser.safari) rwHeight = 21;
                    else if ($.browser.msie) rwHeight = 21;
                    else rwHeight = 25;
                } else {
                    if ($.browser.chrome) rwHeight = 23;
                    else if ($.browser.safari) rwHeight = 20;
                    else if ($.browser.msie) rwHeight = 20;
                    else rwHeight = 24;
                } */

				if (vTaskList[i].getLink() % 5 > 0) rwHeight = brow_height;
					else rwHeight = brow_height + brow_tuner;
				
				
                vTmpDate.setFullYear(vMinDate.getFullYear(), vMinDate.getMonth(), vMinDate.getDate());
                vTaskStart = vTaskList[i].getStart();
                vTaskEnd = vTaskList[i].getEnd();

                vNumCols = 0;
                vID = vTaskList[i].getID();

                // vNumUnits = Math.ceil((vTaskList[i].getEnd() - vTaskList[i].getStart()) / (24 * 60 * 60 * 1000)) + 1;
                vNumUnits = (vTaskList[i].getEnd() - vTaskList[i].getStart()) / (24 * 60 * 60 * 1000) + 1;
                if (vFormat == 'hour') {
                    vNumUnits = (vTaskList[i].getEnd() - vTaskList[i].getStart()) / (60 * 1000) + 1;
                } else if (vFormat == 'minute') {
                    vNumUnits = (vTaskList[i].getEnd() - vTaskList[i].getStart()) / (60 * 1000) + 1;
                }

                if (vTaskList[i].getVisible() == 0) vRightTable += '<DIV id=childgrid_' + vID + ' style="position:relative; display:none;">';
                else vRightTable += '<DIV id=childgrid_' + vID + ' style="position:relative">';

                if (vTaskList[i].getMile()) {

                    vRightTable += '<DIV><TABLE style="position:relative; top:0px; width: ' + vChartWidth + 'px;" cellSpacing=0 cellPadding=0 border=0>' + '<TR id=childrow_' + vID + ' class=yesdisplay style="HEIGHT:' + rwHeight + 'px" onMouseover=g.mouseOver(this,' + vID + ',"right","mile") onMouseout=g.mouseOut(this,' + vID + ',"right","mile")>' + vItemRowStr + '</TR></TABLE></DIV>';

                    // Build date string for Title  
                    vDateRowStr = JSAgile.formatDateStr(vTaskStart, vDateDisplayFormat);

                    vTaskLeft = (Date.parse(vTaskList[i].getStart()) - Date.parse(vMinDate)) / (24 * 60 * 60 * 1000);
                    vTaskRight = 1;

                    vRightTable += '<div id=bardiv_' + vID + ' style="position:absolute; top:0px; left:' + Math.ceil((vTaskLeft * vDayWidth + vDayWidth - 5)) + 'px; height: 18px; width:160px; overflow:hidden;">' +




                    '  <div id=taskbar_' + vID + ' title="' + vTaskList[i].getName() + ': ' + vDateRowStr + '" style="height: 16px; width:12px; overflow:hidden; color: #' + MileClr + '; cursor: '+ pblcVwCur +';" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Chart");>'; // added color: blue for the milestones --MSD
                    if (vTaskList[i].getProgressVal() < 100) {
                        vRightTable += '&loz;</div>';
                    } else {
                        vRightTable += '&diams;</div>';
                    }

                    if (g.getCaptionType()) {
                        vCaptionStr = '';
                        switch (g.getCaptionType()) {
                        case 'Caption':
                            vCaptionStr = vTaskList[i].getCaption();
                            break;
                        case 'Resource':
                            vCaptionStr = vTaskList[i].getResource();
                            break;
                        case 'Duration':
                            vCaptionStr = vTaskList[i].getDuration(vFormat);
                            break;
                        case 'Complete':
                            vCaptionStr = vTaskList[i].getCompStr();
                            break;
                        }
                        //vRightTable += '<div style="FONT-SIZE:12px; position:absolute; left: 6px; top:1px;">' + vCaptionStr + '</div>';
                        vRightTable += '<div style="FONT-SIZE:12px; position:absolute; top:2px; width:120px; left:12px">' + vCaptionStr + '</div>';
                    };

                    vRightTable += '</div>';


                } else {

                    // Build date string for Title
                    vDateRowStr = JSAgile.formatDateStr(vTaskStart, vDateDisplayFormat) + ' - ' + JSAgile.formatDateStr(vTaskEnd, vDateDisplayFormat);

                    if (vFormat == 'minute') {
                        vTaskRight = (Date.parse(vTaskList[i].getEnd()) - Date.parse(vTaskList[i].getStart())) / (60 * 1000) + 1 / vColUnit;
                        vTaskLeft = Math.ceil((Date.parse(vTaskList[i].getStart()) - Date.parse(vMinDate)) / (60 * 1000));
                    } else if (vFormat == 'hour') {
                        vTaskRight = (Date.parse(vTaskList[i].getEnd()) - Date.parse(vTaskList[i].getStart())) / (60 * 60 * 1000) + 1 / vColUnit;
                        vTaskLeft = (Date.parse(vTaskList[i].getStart()) - Date.parse(vMinDate)) / (60 * 60 * 1000);
                    } else {
                        vTaskRight = (Date.parse(vTaskList[i].getEnd()) - Date.parse(vTaskList[i].getStart())) / (24 * 60 * 60 * 1000) + 1 / vColUnit;
                        vTaskLeft = Math.ceil((Date.parse(vTaskList[i].getStart()) - Date.parse(vMinDate)) / (24 * 60 * 60 * 1000));
                        if (vFormat = 'day') {
                            var tTime = new Date();
                            tTime.setTime(Date.parse(vTaskList[i].getStart()));
                            if (tTime.getMinutes() > 29) vTaskLeft += .5;
                        }
                    }

                    // Draw Group Bar  which has outer div with inner group div and several small divs to left and right to create angled-end indicators
                    if (vTaskList[i].getGroup()) { //MSD --------------
                        if (vTaskList[i].getLink() % 2 == 1) {
                            vBGColor = "ffffff";
                        } else {
                            vBGColor = "eee";
                        }
                        vRightTable += '<DIV><TABLE style="position:relative; top:0px; width: ' + vChartWidth + 'px;" cellSpacing=0 cellPadding=0 border=0>' + '<TR id=childrow_' + vID + ' class=yesdisplay style="HEIGHT:' + rwHeight + 'px" bgColor=#' + vBGColor + ' onMouseover=g.mouseOver(this,' + vID + ',"right","group") onMouseout=g.mouseOut(this,' + vID + ',"right","group")>' + vItemRowStr + '</TR></TABLE></DIV>';
                        vRightTable += '<div id=bardiv_' + vID + ' style="position:absolute; top:5px; left:' + Math.ceil(vTaskLeft * (vDayWidth) + 1) + 'px; height: 7px; width:' + Math.ceil((vTaskRight) * (vDayWidth) - 1) + 'px">' + '<div id=taskbar_' + vID + ' title="' + vTaskList[i].getName() + ': ' + vDateRowStr + '" class=gtask style="background-color:#434343; height: 7px; width:' + Math.ceil((vTaskRight) * (vDayWidth) - 1) + 'px;  cursor: '+ pblcVwCur +'; opacity:0.9;">' + '<div style="Z-INDEX: -4; float:left; background-color:#'+ barGrpClr +'; height:3px; overflow: hidden; margin-top:1px; ' + 'margin-left:1px; margin-right:1px; filter: alpha(opacity=80); opacity:0.8; width:' + vTaskList[i].getCompStr() + '; ' + 'cursor: '+ pblcVwCur +';" ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Chart");>' + '</div>' + '</div>' + '<div style="Z-INDEX: -4; float:left; background-color:#434343; height:4px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:right; background-color:#434343; height:4px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:left; background-color:#434343; height:3px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:right; background-color:#434343; height:3px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:left; background-color:#434343; height:2px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:right; background-color:#434343; height:2px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:left; background-color:#434343; height:1px; overflow: hidden; width:1px;"></div>' + '<div style="Z-INDEX: -4; float:right; background-color:#434343; height:1px; overflow: hidden; width:1px;"></div>';
                        if (g.getCaptionType()) {
                            vCaptionStr = '';
                            switch (g.getCaptionType()) {
                            case 'Caption':
                                vCaptionStr = vTaskList[i].getCaption();
                                break;
                            case 'Resource':
                                vCaptionStr = vTaskList[i].getResource();
                                break;
                            case 'Duration':
                                vCaptionStr = vTaskList[i].getDuration(vFormat);
                                break;
                            case 'Complete':
                                vCaptionStr = vTaskList[i].getCompStr();
                                break;
                            }
                            //vRightTable += '<div style="FONT-SIZE:12px; position:absolute; left: 6px; top:1px;">' + vCaptionStr + '</div>';
                            vRightTable += '<div style="FONT-SIZE:12px; position:absolute; top:-3px; width:120px; left:' + (Math.ceil((vTaskRight) * (vDayWidth) - 1) + 6) + 'px">' + vCaptionStr + '</div>';
                        };

                        vRightTable += '</div>';

                    } else {



                        if (vTaskList[i].getLink() % 2 == 1) {
                            vBGColor = "ffffff";
                        } else {
                            vBGColor = "eee";
                        }


                        vDivStr = '<DIV><TABLE style="position:relative; top:0px; width: ' + vChartWidth + 'px;" cellSpacing=0 cellPadding=0 border=0>' + '<TR id=childrow_' + vID + ' class=yesdisplay style="HEIGHT:' + rwHeight + 'px" bgColor=#' + vBGColor + ' onMouseover=g.mouseOver(this,' + vID + ',"right","row") onMouseout=g.mouseOut(this,' + vID + ',"right","row")>' + vItemRowStr + '</TR></TABLE></DIV>';
                        vRightTable += vDivStr;

                        // Draw Task Bar  which has outer DIV with enclosed colored bar div, and opaque completion div  
						vRightTable += '<div id=bardiv_' + vID + ' style="position:absolute; top:4px; left:' + Math.ceil(vTaskLeft * (vDayWidth) + 1) + 'px; height:18px; width:' + Math.ceil((vTaskRight) * (vDayWidth) - 1) + 'px">' + '<div id=taskbar_' + vID + ' title="' + vTaskList[i].getName() + ': ' + vDateRowStr + '" class=gtask style="background-color:#' + vTaskList[i].getColor() + '; height: 13px; width:' + Math.ceil((vTaskRight) * (vDayWidth) - 1) + 'px; cursor: '+ pblcVwCur +'; opacity:0.9;" ' + 'ondblclick=JSAgile.taskLink("' + vTaskList[i].getID() + '","Chart"); >' + '<div class=gcomplete style="Z-INDEX: -4; float:left; background-color:#'+ barColor +'; height:5px; overflow: auto; margin-top:4px; filter: alpha(opacity=50); opacity:0.5; width:' + vTaskList[i].getCompStr() + '; overflow:hidden">' + '</div>' + '</div>';
						
                        if (g.getCaptionType()) {
                            vCaptionStr = '';
                            switch (g.getCaptionType()) {
                            case 'Caption':
                                vCaptionStr = vTaskList[i].getCaption();
                                break;
                            case 'Resource':
                                vCaptionStr = vTaskList[i].getResource();
                                break;
                            case 'Duration':
                                vCaptionStr = vTaskList[i].getDuration(vFormat);
                                break;
                            case 'Complete':
                                vCaptionStr = vTaskList[i].getCompStr();
                                break;
                            }
                            //vRightTable += '<div style="FONT-SIZE:12px; position:absolute; left: 6px; top:-3px;">' + vCaptionStr + '</div>';
                            vRightTable += '<div style="FONT-SIZE:12px; position:absolute; top:-3px; width:120px; left:' + (Math.ceil((vTaskRight) * (vDayWidth) - 1) + 6) + 'px">' + vCaptionStr + '</div>';
                        }
                        vRightTable += '</div>';



                    }
                }

                vRightTable += '</DIV>';

            }

            vMainTable += vRightTable + '</DIV></TD></TR></TBODY></TABLE>';




            if (vDiv != null) $("#" + vDiv.id).html(vMainTable).css("margin", "0px auto");

            for (i = 0; i < vTaskList.length; i++) {
                if (vTaskList[i].getNotes() != '') {
                    $("#tnotes_" + vTaskList[i].getID()).addClass("extNotes").attr("title", vTaskList[i].getNotes());
                }




                switch (vTaskList[i].getFlagValue()) {
                    case 0:
                        {
                            flagClass = 'blank_indicator';
							titleMsg = '';
                            break;
                        }
                    case 1: // Deleted
                        {
                            flagClass = 'extDeltd';
							titleMsg = 'Story deleted from Product Backlog';
                            break;
                        }
                    case 2: // Completed
                        {
                            flagClass = 'extCompltd';
							titleMsg = 'Story development completed';
                            break;
                        }
                    case 3: // Some Progress
                        {
                            flagClass = 'extSprnt50';
							titleMsg = 'Story development in progress';
                            break;
                        }
                    case 4: // In Sprint - no progress
                        {
                            flagClass = 'extSprnt0';
							titleMsg = 'Story development in progress';
                            break;
                        }
                    case 5: // Delayed
                        {
                            flagClass = 'extAside';
							titleMsg = 'Story development delayed';
                            break;
                        }
                    case 6: // Pushed, some Progress
                        {
                            flagClass = 'extChngd';
							titleMsg = 'Story pushed to Product Backlog';
                            break;
                        }
                    case 7: // Pushed No Progress
                        {
                            flagClass = 'extOnce';
							titleMsg = 'Story pushed to Product Backlog';
                            break;
                        }
                    case 20:
                        {
                            flagClass = 'spr0';
							titleMsg = 'Sprint in Planning';
                            break;
                        }
                    case 21: // Deleted
                        {
                            flagClass = 'spr1';
							titleMsg = 'Current Sprint';
                            break;
                        }
                    case 22: // Completed
                        {
                            flagClass = 'spr2';
							titleMsg = 'Sprint Completed';
                            break;
                        }
                    case 23: // Some Progress
                        {
                            flagClass = 'spr3';
							titleMsg = 'Sprint on Hold';
                            break;
                        }
                    case 24: // In Sprint - no progress
                        {
                            flagClass = 'spr4';
							titleMsg = 'Sprint Terminated';
                            break;
                        }
                }
				
                $("#tconstr_" + vTaskList[i].getID()).addClass(flagClass);  
				if (vTaskList[i].getFlagSign() != '') $("#tconstr_" + vTaskList[i].getID()).addClass(vTaskList[i].getFlagSign());	
				if (titleMsg != '') $("#tconstr_" + vTaskList[i].getID()).attr("title", titleMsg);

			
				
				
				if (vTaskList[i].getTolnceNotes() != '') {
                    $("#twtnotes_" + vTaskList[i].getID()).attr("title", vTaskList[i].getTolnceNotes());
                }				

                if (vTaskList[i].getNumDocs() > 0) {
                    $("#tattach_" + vTaskList[i].getID()).addClass("extAttach");
                }
				
				
				// HERE risks, issues, crs, bds
				
					//=================
				if (vTaskList[i].getTRisks() > 0) {	
					$("#trisk_" + vTaskList[i].getID()).addClass("ocRisks").attr("title", "Total Risks: "+vTaskList[i].getTRisks());
				}
				
				if (vTaskList[i].getTIssues() > 0) {	
					if (vTaskList[i].getOIssues() > 0) $("#tissue_" + vTaskList[i].getID()).addClass("opIssues").attr("title", "Total Issues: "+vTaskList[i].getTIssues()+" and Active Issues: "+vTaskList[i].getOIssues());
						else  $("#tissue_" + vTaskList[i].getID()).addClass("tlIssues").attr("title", "Total Issues: "+vTaskList[i].getTIssues());
				}
				
				if (vTaskList[i].getTCRs() > 0) {	
					if (vTaskList[i].getOCRs() > 0) $("#tcrs_" + vTaskList[i].getID()).addClass("opCRs").attr("title", "Total CRs: "+vTaskList[i].getTCRs()+" and Active CRs: "+vTaskList[i].getOCRs());
						else  $("#tcrs_" + vTaskList[i].getID()).addClass("tlCRs").attr("title", "Total CRs: "+vTaskList[i].getTCRs());
				}
				
				if (vTaskList[i].getTBDs() > 0) {	
					if (vTaskList[i].getOBDs() > 0) $("#tbds_" + vTaskList[i].getID()).addClass("opBDs").attr("title", "Total Defects: "+vTaskList[i].getTBDs()+" and Active Defects: "+vTaskList[i].getOBDs());
						else  $("#tbds_" + vTaskList[i].getID()).addClass("tlBDs").attr("title", "Total Defects: "+vTaskList[i].getTBDs());
				}

            }


            if ($("#Notes").length > 0) callRClick('Notes');
			if ($("#Registry").length > 0) callRClick('Registry');
            if ($("#ID").length > 0) callRClick('ID');
            if ($("#Tasks").length > 0) callRClick('Tasks');
            if ($("#Resource").length > 0) callRClick('Resource');
            if ($("#Cost").length > 0) callRClick('Cost');
            if ($("#Duration").length > 0) callRClick('Duration');
            if ($("#Progress").length > 0) callRClick('Progress');
            if ($("#StartDate").length > 0) callRClick('StartDate');
            if ($("#EndDate").length > 0) callRClick('EndDate');
			
			if ($("#ActStartDate").length > 0) callRClick('ActStartDate');
			if ($("#ActEndDate").length > 0) callRClick('ActEndDate');
			
            if ($("#BudgetWork").length > 0) callRClick('BudgetWork');
            if ($("#Work").length > 0) callRClick('Work');
            if ($("#AdjtEstimate").length > 0) callRClick('AdjtEstimate');
            if ($("#EstimateWork").length > 0) callRClick('EstimateWork');
			
            if ($("#FixedCost").length > 0) callRClick('FixedCost');
			if ($("#ActualWork").length > 0) callRClick('ActualWork');
			if ($("#ActWorkRatio").length > 0) callRClick('ActWorkRatio');
			if ($("#CtrlAccnt").length > 0) callRClick('CtrlAccnt');
			if ($("#ActualCost").length > 0) callRClick('ActualCost');
			if ($("#ActFixedCost").length > 0) callRClick('ActFixedCost');
			if ($("#ActDuration").length > 0) callRClick('ActDuration');
			if ($("#TotalCost").length > 0) callRClick('TotalCost');
			if ($("#TotalWork").length > 0) callRClick('TotalWork');
			if ($("#AdjustedCost").length > 0) callRClick('AdjustedCost');
			if ($("#AdjustedWork").length > 0) callRClick('AdjustedWork');
			if ($("#WorkTolerance").length > 0) callRClick('WorkTolerance');
			if ($("#ReleasedWork").length > 0) callRClick('ReleasedWork');
			if ($("#StoryStatus").length > 0) callRClick('StoryStatus');
			
            //MSD Change this to rightclick menu - cut-rename etc 
            if (procesMode == 0) {

				$("[id^='gntnode_']").contextMenu({
					menu: 'myMenuAgile',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "nTask", "planner"); // func in Gantt_Masters.js
				});

				$("[id^='gntStry_']").contextMenu({
					menu: 'myMenuStoryAgile',
					elementID: 'context_main' // func in Gantt_Masters.js
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "story", "planner"); // Change to Story --- func in Gantt_Masters.js
				});
				
				$("[id^='gntSprt_']").contextMenu({
					menu: 'myMenuSprntAgile',
					elementID: 'context_main' // func in Gantt_Masters.js
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "sprint", "planner"); // Change to Sprint --- func in Gantt_Masters.js
				});
				
				$("#gntRoot_1").contextMenu({
					menu: 'myMenuRootAgile',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "root", "planner"); // func in Gantt_Masters.js
				});

				$("[id^='gntMlnode_']").contextMenu({
					menu: 'myMenuMile',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "rMlTask", "planner"); // func in Gantt_Masters.js
				});

				$("[id^='gntRGnode_']").contextMenu({
					menu: 'myMenuRGrpAgile',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "rgTask", "planner"); // func in Gantt_Masters.js
				});
				$("[id^='gntRTnode_']").contextMenu({
					menu: 'myMenuRTskAgile',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "rtTask", "planner"); // func in Gantt_Masters.js
				});
            }

            // to here ------------------------------------------------------------------------------------------------
        };
		return;
    }; //this.draw 

    function callRClick(aColID) {
        $("#" + aColID + "_h").rAglClickMenu({
            menu: 'AglColHideShow',
            elID: aColID
        }, function (action, status, elID) {
            if (action == 'update') {
                UpdateColsArray();
                setColumnPos(elID);
            } else {
                reDrawAgile();
            }
        });
        $("#" + aColID).rAglClickMenu({
            menu: 'AglColHideShow',
            elID: aColID
        }, function (action, status, elID) {
            if (action == 'update') {
                UpdateColsArray();
                setColumnPos(elID);
            } else {
                reDrawAgile();
            }
        });
    }

    this.mouseOver = function (pObj, pID, pPos, pType) {
        if (pPos == 'right') vID = 'child_' + pID;
        else vID = 'childrow_' + pID;

        pObj.bgColor = "#d5effc";
        vRowObj = JSAgile.findObj(vID);
        if (vRowObj) vRowObj.bgColor = "#d5effc";
    };

    this.mouseOut = function (pObj, pID, pPos, pType) {
        if (pPos == 'right') vID = 'child_' + pID;
        else vID = 'childrow_' + pID;

        pObj.bgColor = "#ffffff"; // Row colors ---MSD
        vRowObj = JSAgile.findObj(vID);
        if (vRowObj) {
            if (pType == "group") {
                if (getOrigLink(pID) % 2 == 1) {
                    pObj.bgColor = "#ffffff";
                    vRowObj.bgColor = "#ffffff";
                } else {
                    pObj.bgColor = "#eee";
                    vRowObj.bgColor = "#eee";
                }
            } else {

                if (getOrigLink(pID) % 2 == 1) {
                    pObj.bgColor = "#ffffff";
                    vRowObj.bgColor = "#ffffff";
                } else {
                    pObj.bgColor = "#eee";
                    vRowObj.bgColor = "#eee";
                }
            }
        }

    };

}; //GanttChart
JSAgile.isIE = function () {

    if (typeof document.all != 'undefined') {
        return true;
    } else {
        return false;
    }
};

JSAgile.processRows = function (pList, pID, pRow, pLevel, pOpen) {

    var vMinDate = new Date();
    var vMaxDate = new Date();
    var vMinSet = 0;
    var vMaxSet = 0;
    var vList = pList;
    var vLevel = pLevel;
    var i = 0;
    var vNumKid = 0;
    var vCompSum = 0;
    var vVisible = pOpen;

    for (i = 0; i < pList.length; i++) {
        if (pList[i].getParent() == pID) {
            vVisible = pOpen;
            pList[i].setVisible(vVisible);
            if (vVisible == 1 && pList[i].getOpen() == 0) {
                vVisible = 0;
            }

            pList[i].setLevel(vLevel);
            vNumKid++;

            if (pList[i].getGroup() == 1) {
                JSAgile.processRows(vList, pList[i].getID(), i, vLevel + 1, vVisible);
            };

            if (vMinSet == 0 || pList[i].getStart() < vMinDate) {
                vMinDate = pList[i].getStart();
                vMinSet = 1;
            };

            if (vMaxSet == 0 || pList[i].getEnd() > vMaxDate) {
                vMaxDate = pList[i].getEnd();
                vMaxSet = 1;
            };

            vCompSum += pList[i].getCompVal();

        }
    }

    if (pRow >= 0) {
        pList[pRow].setStart(vMinDate);
        pList[pRow].setEnd(vMaxDate);
        pList[pRow].setNumKid(vNumKid);
        pList[pRow].setCompVal(Math.ceil(vCompSum / vNumKid));
    }

};

JSAgile.getMinDate = function getMinDate(pList, pFormat) {

    var vDate = new Date();

    vDate.setFullYear(pList[0].getStart().getFullYear(), pList[0].getStart().getMonth(), pList[0].getStart().getDate());

    // Parse all Task End dates to find min
    for (i = 0; i < pList.length; i++) {
        if (Date.parse(pList[i].getStart()) < Date.parse(vDate)) vDate.setFullYear(pList[i].getStart().getFullYear(), pList[i].getStart().getMonth(), pList[i].getStart().getDate());
    }

    if (pFormat == 'minute') {
        vDate.setHours(0);
        vDate.setMinutes(0);
    } else if (pFormat == 'hour') {
        vDate.setHours(0);
        vDate.setMinutes(0);
    }
    // Adjust min date to specific format boundaries (first of week or first of month)
    else if (pFormat == 'day') {
        vDate.setDate(vDate.getDate() - 1);
        while (vDate.getDay() % 7 > 0) {
            vDate.setDate(vDate.getDate() - 1);
        }

    } else if (pFormat == 'week') {
        vDate.setDate(vDate.getDate() - 7);
        while (vDate.getDay() % 7 > 0) {
            vDate.setDate(vDate.getDate() - 1);
        }

    } else if (pFormat == 'month') {
        while (vDate.getDate() > 1) {
            vDate.setDate(vDate.getDate() - 1);
        }
    } else if (pFormat == 'quarter') {
        if (vDate.getMonth() == 0 || vDate.getMonth() == 1 || vDate.getMonth() == 2) {
            vDate.setFullYear(vDate.getFullYear(), 0, 1);
        } else if (vDate.getMonth() == 3 || vDate.getMonth() == 4 || vDate.getMonth() == 5) {
            vDate.setFullYear(vDate.getFullYear(), 3, 1);
        } else if (vDate.getMonth() == 6 || vDate.getMonth() == 7 || vDate.getMonth() == 8) {
            vDate.setFullYear(vDate.getFullYear(), 6, 1);
        } else if (vDate.getMonth() == 9 || vDate.getMonth() == 10 || vDate.getMonth() == 11) {
            vDate.setFullYear(vDate.getFullYear(), 9, 1);
        }

    };

    return (vDate);

};

JSAgile.getMaxDate = function (pList, pFormat) {
    var vDate = new Date();
    vDate.setFullYear(pList[0].getEnd().getFullYear(), pList[0].getEnd().getMonth(), pList[0].getEnd().getDate());
    for (i = 0; i < pList.length; i++) {
        if (Date.parse(pList[i].getEnd()) > Date.parse(vDate)) {
            vDate.setTime(Date.parse(pList[i].getEnd()));
        }
    }

	/* Adjust vDate to have a minimum of 30 days from project start */
	if (((Date.parse(vDate) - Date.parse(pList[0].getStart())) / (24 * 60 * 60 * 1000)) < 30) vDate.setTime(Date.parse(pList[0].getStart())+(30 * 24 * 60 * 60 * 1000));
	
	
    if (pFormat == 'minute') {
        vDate.setHours(vDate.getHours() + 1);
        vDate.setMinutes(59);
    }

    if (pFormat == 'hour') {
        vDate.setHours(vDate.getHours() + 2);
    }

    // Adjust max date to specific format boundaries (end of week or end of month)
    if (pFormat == 'day') {
        vDate.setDate(vDate.getDate() + 1);
        while (vDate.getDay() % 6 > 0) {
            vDate.setDate(vDate.getDate() + 1);
        }
    }

    if (pFormat == 'week') {
        vDate.setDate(vDate.getDate() + 11);
        while (vDate.getDay() % 6 > 0) {
            vDate.setDate(vDate.getDate() + 1);
        }

    }

    if (pFormat == 'month') {
        while (vDate.getDay() > 1) {
            vDate.setDate(vDate.getDate() + 1);
        }
        vDate.setDate(vDate.getDate() - 1);
    }

    if (pFormat == 'quarter') {
        if (vDate.getMonth() == 0 || vDate.getMonth() == 1 || vDate.getMonth() == 2) vDate.setFullYear(vDate.getFullYear(), 2, 31);
        else if (vDate.getMonth() == 3 || vDate.getMonth() == 4 || vDate.getMonth() == 5) vDate.setFullYear(vDate.getFullYear(), 5, 30);
        else if (vDate.getMonth() == 6 || vDate.getMonth() == 7 || vDate.getMonth() == 8) vDate.setFullYear(vDate.getFullYear(), 8, 30);
        else if (vDate.getMonth() == 9 || vDate.getMonth() == 10 || vDate.getMonth() == 11) vDate.setFullYear(vDate.getFullYear(), 11, 31);

    }
    return (vDate);
};

JSAgile.findObj = function (theObj, theDoc)
{
    var p, i, foundObj;
    if (!theDoc) {
        theDoc = document;
    }
    if ((p = theObj.indexOf("?")) > 0 && parent.frames.length) {
        theDoc = parent.frames[theObj.substring(p + 1)].document;
        theObj = theObj.substring(0, p);
    }
    if (!(foundObj = theDoc[theObj]) && theDoc.all)
    {
        foundObj = theDoc.all[theObj];
    }

    for (i = 0; !foundObj && i < theDoc.forms.length; i++) {
        foundObj = theDoc.forms[i][theObj];
    }

    for (i = 0; !foundObj && theDoc.layers && i < theDoc.layers.length; i++) {
        foundObj = JSAgile.findObj(theObj, theDoc.layers[i].document);
    }
    if (!foundObj && document.getElementById){
        foundObj = document.getElementById(theObj);
    }
    return foundObj;
};

JSAgile.changeFormat = function (pFormat, ganttObj) {
    UpdateColsArray(); // Newly added -MSD
    if (ganttObj) {
        ganttObj.setFormat(pFormat);
        ganttObj.DrawDependencies();
    } else {
        alert('Chart undefined');
    };
};

JSAgile.folder = function (pID, ganttObj) {
    var vList = ganttObj.getList();
    for (i = 0; i < vList.length; i++) {
        if (vList[i].getID() == pID) {
            if (vList[i].getOpen() == 1) {
                vList[i].setOpen(0);
                JSAgile.hide(pID, ganttObj);
                $('#group_' + pID).removeClass('openGroup').addClass('closeGroup');
            } else {
                vList[i].setOpen(1);
                JSAgile.show(pID, 1, ganttObj);
                $('#group_' + pID).removeClass('closeGroup').addClass('openGroup');
            }
        }
    }
};

JSAgile.hide = function (pID, ganttObj) {
    var vList = ganttObj.getList();
    var vID = 0;

    for (var i = 0; i < vList.length; i++) {
        if (vList[i].getParent() == pID) {
            vID = vList[i].getID();
            JSAgile.findObj('child_' + vID).style.display = "none";
            JSAgile.findObj('childgrid_' + vID).style.display = "none";
            vList[i].setVisible(0);
            if (vList[i].getGroup() == 1) {
                JSAgile.hide(vID, ganttObj);
            }
        }
    }
};

JSAgile.show = function (pID, pTop, ganttObj) {
    var vList = ganttObj.getList();
    var vID = 0;

    for (var i = 0; i < vList.length; i++) {
        if (vList[i].getParent() == pID) {
            vID = vList[i].getID();
            if (pTop == 1) {
                if (JSAgile.isIE()) { // IE;
                    if ($('#group_' + pID).hasClass('closeGroup')) {
                        JSAgile.findObj('child_' + vID).style.display = "";
                        JSAgile.findObj('childgrid_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                } else {
                    if ($('#group_' + pID).hasClass('closeGroup')) {
                        JSAgile.findObj('child_' + vID).style.display = "";
                        JSAgile.findObj('childgrid_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                }
            } else {
                if (JSAgile.isIE()) { // IE;
                    if ($('#group_' + pID).hasClass('openGroup')) {
                        JSAgile.findObj('child_' + vID).style.display = "";
                        JSAgile.findObj('childgrid_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                } else {
                    if ($('#group_' + pID).hasClass('openGroup')) {
                        JSAgile.findObj('child_' + vID).style.display = "";
                        JSAgile.findObj('childgrid_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                }
            }

            if (vList[i].getGroup() == 1) {
                JSAgile.show(vID, 0, ganttObj);
            }
        }
    }
};
JSAgile.taskLink = function (pRef, pClickCol) {
	var jsProcessMode = 3;
	if (publicView == 0) jsProcessMode = procesMode;
	
    switch (jsProcessMode) {
    case 0:
        {
			var prjStatusStr = "";
			if ((prjStatus == 2) || (prjStatus == 4) || (prjStatus == 5)) {
				switch (prjStatus) {
					case 2:
						prjStatusStr = 'Completed';
						break;
					case 4:
						prjStatusStr = 'Cancelled';
						break;
					case 5:
						prjStatusStr = 'Locked';
						break;				
				}
				jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Edit the Task...','E');
			
			} else {
				var nodeinfo = getNodeInfo(pRef);
				selNodeData = pClickCol;
				if (parseInt(nodeinfo["agile-type"]) == 4) {
					selNodeType = 'sprint';
					jgfForms('AglEditSprint', pRef,'Edit Sprint...');
				} else if (parseInt(nodeinfo["agile-type"]) == 3) {
					selNodeType = 'story';
					jgfForms('AglEditStory', pRef,'Edit Story...');
				} else if (parseInt(nodeinfo["agile-type"]) == 5) {
					selNodeType = 'root';
					jgfForms('AglEditStory', pRef,'Edit Project Data...');
				} else {
					if (parseInt(pRef) == 1) {
						selNodeType = 'root';
					} else if (parseInt(nodeinfo["rTask"]) == 1) {
						selNodeType = 'rgTask';
						jgfForms('GntEditMeeting', pRef, 'Edit Meeting...');
					} else if (parseInt(nodeinfo["rTask"]) == 2) {
						selNodeType = 'rtTask';
						jgfForms('GntEditMeeting', pRef, 'Edit Meeting...');
					} else if (parseInt(nodeinfo["rTask"]) == 0) {
						selNodeType = 'nTask';
						jgfForms('GntTaskEdit', pRef, 'Edit Task...');
					}
				}				
				
				
			}
            break;
        }
    case 1:
        {
            //alert(pRef + " -- " + pClickCol + " -- " + "Update");
			var prjStatusStr = "";
			if (prjStatus == 1) {
				var nodeinfo = getNodeInfo(pRef);
				/*
				
				
				
				*/
				
				if (parseInt(pRef) == 1) selNodeType = 'root';
				else if (parseInt(nodeinfo["rTask"]) == 1) selNodeType = 'rgTask';
				else if (parseInt(nodeinfo["rTask"]) == 2) selNodeType = 'rtTask';
				else if ((parseInt(nodeinfo["rTask"]) == 0) && (parseInt(nodeinfo["milestone"]) == 1)) selNodeType = 'rMlTask';
				else if ((parseInt(nodeinfo["rTask"]) == 0) && (parseInt(nodeinfo["milestone"]) == 0)) selNodeType = 'nTask';
				selNodeData = pClickCol;
				jgfForms('GntTaskUpdate', pRef, 'Update Task...');
			} else {
				switch (prjStatus) {
					case 0:
						prjStatusStr = 'Pending Approval';
						break;
					case 2:
						prjStatusStr = 'Completed';
						break;
					case 3:
						prjStatusStr = 'On Hold';
						break;
					case 4:
						prjStatusStr = 'Cancelled';
						break;
					case 5:
						prjStatusStr = 'Locked';
						break;				
				}
			
				jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Update the Task...','E');
			
			}
            break;
        }

    case 2:
        {
            //alert(pRef + " -- " + pClickCol + " -- " + "View");
			var nodeinfo = getNodeInfo(pRef);
			/*
			
			
			*/
			
			if (parseInt(pRef) == 1) selNodeType = 'root';
			else if (parseInt(nodeinfo["rTask"]) == 1) selNodeType = 'rgTask';
			else if (parseInt(nodeinfo["rTask"]) == 2) selNodeType = 'rtTask';
			else if ((parseInt(nodeinfo["rTask"]) == 0) && (parseInt(nodeinfo["milestone"]) == 1)) selNodeType = 'rMlTask';
			else if ((parseInt(nodeinfo["rTask"]) == 0) && (parseInt(nodeinfo["milestone"]) == 0)) selNodeType = 'nTask';
			selNodeData = pClickCol;
			jgfForms('GntTaskView', pRef, 'View Task...');
            break;
        }

    };
	return true;
};

JSAgile.getDispDepend = function (origDepend) {
    var dispDepend = '';

    if (origDepend != '') {

        var vDependStr = origDepend + '';
        var vDepList = vDependStr.split(',');
        var n = vDepList.length;

        for (var k = 0; k < n; k++) {

            var cTask = '';
            var zTask = '';
            var zDelay = '';
            if (vDepList[k].indexOf('-') != -1) {
                cTask = vDepList[k];
                cTask = cTask.split("-");
                zTask = cTask[0];
                zDelay = ' - ' + cTask[1];
            } else if (vDepList[k].indexOf('+') != -1) {
                cTask = vDepList[k];
                cTask = cTask.split("+");
                zTask = cTask[0];
                zDelay = ' + ' + cTask[1];
            } else zTask = vDepList[k];

            for (ik = 0; ik < prjkt.length; ik++) {
                if (prjkt[ik]['pID'] == parseInt(zTask)) vTask = prjkt[ik]['pLink'];
            }

            var vRelate = zTask.replace(/\d+/g, '');
            vDepList[k] = vTask + vRelate + zDelay;
        }
        dispDepend = vDepList.toString();
    }
    return dispDepend;
}




JSAgile.resizePopup = function (elID) {
    var elemID = elID.split("_");
    var elID = elemID[0];
    if (elID == 'Notes') return;
	 else if (elID == 'Registry') return;
    var offset = $('#' + elID).offset();
    var elText = '';
    if (elID == 'StartDate') elText = 'Start Date';
    else if (elID == 'EndDate') elText = 'End Date';
	else if (elID == 'ActStartDate') elText = 'Actual Start';
	else if (elID == 'ActEndDate') elText = 'Actual End';
    else if (elID == 'FixedCost') elText = 'Fixed Cost';
	else if (elID == 'ActualWork') elText = 'Actual Work';
	else if (elID == 'ActWorkRatio') elText = 'Actual Work Ratio';
	else if (elID == 'CtrlAccnt') elText = 'Control Account';
	else if (elID == 'ActualCost') elText = 'Actual Cost';
	else if (elID == 'ActFixedCost') elText = 'Actual Fixed Cost';
	else if (elID == 'ActDuration') elText = 'Actual Duration';
	else if (elID == 'TotalCost') elText = 'Total Cost';
	else if (elID == 'TotalWork') elText = 'Total Work';
	else if (elID == 'AdjustedCost') elText = 'Adjusted Cost';
	else if (elID == 'AdjustedWork') elText = 'Adjusted:Picked';
	else if (elID == 'WorkTolerance') elText = 'Work Tolerance';
	else if (elID == 'BudgetWork') elText = 'Budget Work';
	else if (elID == 'EstimateWork') elText = 'Alloted Work';
	else if (elID == 'AdjtEstimate') elText = 'Adjusted:Alloted';
	else if (elID == 'Work') elText = 'Picked Work';
	else if (elID == 'Tasks') elText = 'Description';
	else if (elID == 'ReleasedWork') elText = 'Released Work';
	else if (elID == 'StoryStatus') elText = 'Status';
    else elText = elID; 

    $('.colmWidth').text(elText); 
	
	
	

    $('#colWSet').bPopup({
        onOpen: function () {
            if ($('#colmWidth').length != 0) $('#colmWidth').spinner({
                min: 10,
                max: 640,
                stepping: 5
            }).val(ColWidths[0][elID]); /* alert('onOpen fired'); */
        },
        onClose: function () {
            if ($('#colmWidth').length != 0) {
                if (parseInt($('#colmWidth').val()) > 10) ColWidths[0][elID] = parseInt($('#colmWidth').val());
            }
            reDrawAgile(); /* alert('onClose fired'); */
        },
        modal: true,
        modalColor: '#D3D3D3',
        position: [offset.left, offset.top],
        opacity: 0.3,
        positionStyle: 'fixed',
        fadeSpeed: 'fast',
        followSpeed: 1500,
        speed: 450 //transition: 'slideDown'
    }, function () { /* alert('Callback fired'); */
    });
	return false;
}

JSAgile.parseDateStr = function (pDateStr, pFormatStr) {
    var vDate = new Date();
    vDate.setTime(Date.parse(pDateStr));

    switch (pFormatStr) {
    case 'mm/dd/yyyy':
        var vDateParts = pDateStr.split('/');
        vDate.setFullYear(parseInt(vDateParts[2], 10), parseInt(vDateParts[0], 10) - 1, parseInt(vDateParts[1], 10));
        break;
    case 'dd/mm/yyyy':
        var vDateParts = pDateStr.split('/');
        vDate.setFullYear(parseInt(vDateParts[2], 10), parseInt(vDateParts[1], 10) - 1, parseInt(vDateParts[0], 10));
        break;
    case 'yyyy-mm-dd':
        var vDateParts = pDateStr.split('-');
        vDate.setFullYear(parseInt(vDateParts[0], 10), parseInt(vDateParts[1], 10) - 1, parseInt(vDateParts[1], 10));
        break;
    }

    return (vDate);

};

JSAgile.formatDateStr = function (pDate, pFormatStr) {
    vYear4Str = pDate.getFullYear() + '';
    vYear2Str = vYear4Str.substring(2, 4);
    vMonthStr = (pDate.getMonth() + 1) + '';
    vDayStr = pDate.getDate() + '';

    var vDateStr = "";

    switch (pFormatStr) {
    case 'mm/dd/yyyy':
        return (vMonthStr + '/' + vDayStr + '/' + vYear4Str);
    case 'dd/mm/yyyy':
        return (vDayStr + '/' + vMonthStr + '/' + vYear4Str);
    case 'yyyy-mm-dd':
        return (vYear4Str + '-' + vMonthStr + '-' + vDayStr);
    case 'mm/dd/yy':
        return (vMonthStr + '/' + vDayStr + '/' + vYear2Str);
    case 'dd/mm/yy':
        return (vDayStr + '/' + vMonthStr + '/' + vYear2Str);
    case 'yy-mm-dd':
        return (vYear2Str + '-' + vMonthStr + '-' + vDayStr);
    case 'mm/dd':
        return (vMonthStr + '/' + vDayStr);
    case 'dd/mm':
        return (vDayStr + '/' + vMonthStr);
    }

};

JSAgile.AddJSONTask = function (pGanttVar) {

    var n = prjkt.length; // the number of tasks. IE gets this right, but mozilla add extra ones (Whitespace)
	for (var i = 0; i < n; i++) {
        if (prjkt[i]["pID"] != 0) {
            var pID = prjkt[i]["pID"];
            var pName = prjkt[i]["pName"];
            var pStart = prjkt[i]["pStart"];
            var pEnd = prjkt[i]["pEnd"];
            var pColor = prjkt[i]["pColor"];
			var pAgile = prjkt[i]["pAgile"];
            var pLink = prjkt[i]["pLink"];
            var pMile = 0;
			var pBudgetWork = prjkt[i]["pBudgetWork"];
			var pEstimWork = prjkt[i]["pEstimWork"];
            var pRes = prjkt[i]["pRes"];
            var pComp = prjkt[i]["pComp"];
            var pGroup = prjkt[i]["p-Group"];
            var pParent = prjkt[i]["pParent"];
            var pOpen = prjkt[i]["pOpen"];
            var pDepend = prjkt[i]["pDepend"];
            var pCaption = prjkt[i]["pCaption"];
            var pCost = prjkt[i]["pCost"];
            var pRole = prjkt[i]["pRole"];
            var pWork = prjkt[i]["pWork"];
            var pCalDay = prjkt[i]["pCalDay"];
            var pRtask = prjkt[i]["pRtask"];
            var pPriorty = 500;
            var pAdjEstWrk = prjkt[i]["pAdjEstWrk"];
			var pFixEstWrk = prjkt[i]["pFixEstWrk"];
            var pConstDate = prjkt[i]["constDate"];
            var pNotes = prjkt[i]["notes-desc"];
            var pNumDocs = prjkt[i]["numDocs"];
            var pFixedCost = prjkt[i]["pFixedCost"];
			var pActualWork = prjkt[i]["pActualWork"];
			var pCtrlAccnt = prjkt[i]["pCtrlAccnt"];
			var pRisks = prjkt[i]["pRisks"];
			var ptIssues = prjkt[i]["ptIssues"];
			var poIssues = prjkt[i]["poIssues"];
			var ptCRs = prjkt[i]["ptCRs"];
			var poCRs = prjkt[i]["poCRs"];
			var ptBDs = prjkt[i]["ptBDs"];
			var poBDs = prjkt[i]["poBDs"];
			
			var pActStart = prjkt[i]["pActStart"];
			var pActEnd = prjkt[i]["pActEnd"];
			var pActCost = prjkt[i]["pActCost"];
			var pActFixedCost = prjkt[i]["pActFixedCost"];
			var pActDuration = prjkt[i]["ActDuration"];
			var pTotCost = prjkt[i]["pTotCost"];
			var pTotWork = prjkt[i]["pTotWork"];
			var pAdjCost = prjkt[i]["pAdjCost"];
			var pAdjWork = prjkt[i]["pAdjWork"];
			var pWorkTolnce = prjkt[i]["wr_tolerance"];
			var pWorkTolnceNotes = prjkt[i]["tolerance-desc"];
			var pRelsdWork = prjkt[i]["pRelWrk"];
			var pFlagValue = prjkt[i]["flag-status"];
			var psColor = prjkt[i]["psColor"];
			
            pGanttVar.AddTaskItem(new JSAgile.TaskItem(pID, pName, pStart, pEnd, pColor, pLink, pMile, pBudgetWork, pRes, pComp, pGroup, pParent, pOpen, pDepend, pCaption, pCost, pRole, pWork, pCalDay, pRtask, pEstimWork, pAdjEstWrk, pConstDate, pNotes, pNumDocs, pFixedCost, pActualWork, pCtrlAccnt, pRisks, ptIssues, poIssues, ptCRs, poCRs, ptBDs, poBDs, pActStart, pActEnd, pActCost, pActFixedCost, pActDuration, pTotCost, pTotWork, pAdjCost, pAdjWork, pWorkTolnce, pWorkTolnceNotes, pAgile, pRelsdWork, pFlagValue, psColor));

        };
    }
};


JSAgile.benchMark = function (pItem) {
    var vEndTime = new Date().getTime();
    alert(pItem + ': Elapsed time: ' + ((vEndTime - vBenchTime) / 1000) + ' seconds.');
    vBenchTime = new Date().getTime();
};