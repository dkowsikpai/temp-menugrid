jQuery.ajaxSetup({
  cache: true
});

function menu_loader() {
	$("#error-messages").empty().css({"display":"none"});
	$("#btnLogin, #aTagfPwd").attr("disabled", "disabled");
	var MesgUname = '';
	MesgUname += validate({ 
			elem_id: 'user-name-login',
			mn_length: 6,
			mx_length: 60,
			strg_type: 'uname',
			msg_type: 'mesg-box'
		});
	var MesgPword = '';
	MesgPword += validate({ 
			elem_id: 'pass-word-login',
			mn_length: 6,
			mx_length: 60,
			strg_type: 'upassword',
			msg_type: 'mesg-box'
		});

	if ((MesgUname != '') || (MesgPword != '')) {
		$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
		$("#error-messages").empty().append('<p>Invalid Username or Password</p>').css({"display":"block"}).focus();
		return false;
	} else {
		// AJAX to validate and check and load menu
		
		$("body").addClass("progressor");
		$.ajax({
			url: "phpUserLogin.php",
			type: 'POST',
			data: {
				"page": 'user-login',
				"user-uname": $('#user-name-login').val(),
				"user-password": $('#pass-word-login').val(),
				"restart-request": 0  
			},
			timeout: xhr_timeout,
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			},
			success: function(response) {
				//alert(response);
				response = $.parseJSON(response);
				if (response[0].status == "error") {
					$("body").removeClass("progressor");
					$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
					$('#pass-word-login').val('');
					$('#user-name-login').focus();
					$("#error-messages").empty().append(response[0].data).css({"display":"block"});
					return false;
				} else {
					$("body").removeClass("body-login").removeClass("body-color").addClass("body-default").empty().load("Mainmenu.html", function(responseText, statusText, xhr) {
						//include_script('js/jquery.menudriver.js', "js");
						//include_script('js/jquery.dcmegamenu.js', "js");
						//include_script('js/jquery.hoverIntent.min.js', "js");
						hide_upload_started();
						$("body").removeClass("progressor");
						// ADD MENU CONTROLS
						if (response[0].org_logo != '') $("#org-logo").attr("src", response[0].org_logo);
						if (response[0].org_name != '') $("#org-name").text(response[0].org_name);
						 
						if (response[0].data != '') jAlert(response[0].data,'A');
						estmat = response[0].estmat;
						adjust = response[0].adjust;
						noproj = response[0].noproj;
						totest = response[0].totest;
						totadj = response[0].totadj;
						prfrsa = response[0].prfrsa;
						prfsha = response[0].prfsha;
						prfota = response[0].prfota;
						prfrsc = response[0].prfrsc;
						prfshc = response[0].prfshc;
						billwc = response[0].billwc;
						estfcc = response[0].estfcc;
						actfcc = response[0].actfcc;
						pjtval = response[0].pjtval;
						baslne = response[0].baslne;
						unasgn = response[0].unasgn;
						opnsts = response[0].opnsts;
						rvwsts = response[0].rvwsts;
						acpsts = response[0].acpsts;
						mtgsts = response[0].mtgsts;
						rjtsts = response[0].rjtsts;
						clssts = response[0].clssts;
						delsts = response[0].delsts;
						lowclr = response[0].lowclr;
						medclr = response[0].medclr;
						hghclr = response[0].hghclr;
						pvclr = response[0].pvclr;
						evclr = response[0].evclr;
						acclr = response[0].acclr;
						svspic = response[0].svspic;
						cvcpic = response[0].cvcpic;							
						users_name =  response[0].user_name;
						userFname = response[0].user_fname;
						userFullName = response[0].userFname;
						user_id = response[0].user_id;
						user_sys_id = response[0].user_sys_id;
						user_profile = response[0].user_profile;
						
						org_date_format = response[0].date_format;
						org_first_week_day = response[0].first_week_day;
						org_week_ends = response[0].week_ends;
						xhr_timeout = response[0].xhr_timeout;
						img_extns = response[0].img_extns;
						doc_extns = response[0].doc_extns;
						img_max_size = response[0].img_max_size;
						sp_to_hrs = response[0].sp_to_hrs;
						popup_stack = [];
						popup_help = [];
						if (response[0].user_guide != '') $(response[0].user_guide).css({"display":"block"});
						if (response[0].menu_items != '') $(response[0].menu_items).css({"display":"block"});
						
						//alert("      <>         "+response[0].test_data);
						
						$("#MyNameList").text(userFname);
						tt_exp = response[0].session_expiry;
						tt_delay = parseFloat(response[0].session_alert) * 1000;
						tt_exp     = (parseFloat(tt_exp) * 60000) - tt_delay; //set the time in microsecond 
						/*tt_exp = 10000;      // testing purpose
						tt_delay = 8000; */
						
						autoLogin = false; 
						timer_binder();
						
						$(".work_space").css({
							"padding-top": $('.fix_header_class').height() - 3 + 'px'
						});					
						$('#mega-menu-1').css("visibility","visible").dcMegaMenu({
							rowItems: '4',
							speed: 'fast',
							fullWidth: true
						});
						
						if(statusText == "error") {
							alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
							exclude_script('js/jquery.menudriver.js', "js");
							exclude_menujs();
						}
						
					});
				}
			}
		});	
	}
}

function user_restart() {
	clearTimeout(set_timeout);
	jQuery(document).unbind("active.idleTimer").unbind("idle.idleTimer");
	$.idleTimer('destroy');
	jsoutResume('', 'Session Expired');

}

function timer_binder() {

	if (parseFloat(tt_exp) > 0) {
		$.idleTimer('destroy');
		clearTimeout(set_timeout);
		jQuery(document).unbind("active.idleTimer").unbind("idle.idleTimer").bind("idle.idleTimer", function(){
			userActed = false;
			if (autoLogin == false) {
				var today = new Date();
				var curr_time = today.getHours()+":"+today.getMinutes()+":"+today.getSeconds();
				jsOutConfirm('Session expires in '+ parseInt(tt_delay / 60000) +' minutes from (<b>'+ curr_time +'</b>h) <p>Do you want to continue<b>?</b></p>', 'Session Timeout',function(user_act) {
					if (!user_act) {
						clearTimeout(set_timeout);
						jQuery(document).unbind("active.idleTimer").unbind("idle.idleTimer");
						userActed = true;
						$.idleTimer('destroy');
						show_upload_started();
						$("body").removeClass("progressor").removeClass("body-color").removeClass("body-default").addClass("body-login").empty().load("LoginData.html", function(responseText, statusText, xhr) {
							userFname = '';
							userFullName = '';
							org_date_format = 'dd/mm/yyyy';
							org_first_week_day = 0; 
							org_week_ends = '0,6';
							xhr_timeout = 60000;   
							user_id = 0;  
							users_name = '';
							user_profile = ''; 
							user_sys_id = 0; 
							clipAction = '';
							clipNode = -1;
							img_extns = 'png'; 
							doc_extns = 'zip|txt';
							publicView = 0; 
							profileItem = '';
							img_max_size = 40;
							sp_to_hrs = 0;
							tt_exp = 0;
							tt_delay = 0;
							set_timeout = 0;
							popup_stack = [];
							popup_help = [];
							SA_show = false;
							estmat = '#656565';
							adjust = '#656565';
							noproj = '#656565';
							totest = '#656565';
							totadj = '#656565';
							prfrsa = '#656565';
							prfsha = '#656565';
							prfota = '#656565';
							prfrsc = '#656565';
							prfshc = '#656565';
							billwc = '#656565';
							estfcc = '#656565';
							actfcc = '#656565';
							pjtval = '#656565';
							baslne = '#656565';
							unasgn = '#656565';
							opnsts = '#656565';
							rvwsts = '#656565';
							acpsts = '#656565';
							mtgsts = '#656565';
							rjtsts = '#656565';
							clssts = '#656565';
							delsts = '#656565';
							lowclr = '#656565';
							medclr = '#656565';
							hghclr = '#656565';
							pvclr = '#656565';
							evclr = '#656565';
							acclr = '#656565';
							svspic = '#656565';
							cvcpic = '#656565';
							$('#user-name-login').focus();
							hide_upload_started();
							if(statusText == "error") {
								alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
							}
						});
					} else {
						jQuery(document).bind("active.idleTimer", function(){/* do nothing but clear the alert */});
						jQuery(document).trigger('mousemove');
						userActed = true;
					};
				});
			}
			set_timeout = setTimeout(function(){
				if (userActed == false) {
					jQuery(document).unbind("active.idleTimer");
					if (autoLogin == false) {
						user_restart();
						autoLogin = true;
					}	
				}	
			},tt_delay); 
			
		});
		jQuery.idleTimer(tt_exp);
		jQuery(document).bind("active.idleTimer", function(){/* do nothing but clear the alert */});
		jQuery(document).trigger('mousemove');
		
	}

}

function event_binder() {
	if ($('.login_container').length > 0) {
		var inputs = $(':input, :button, :checkbox').keypress(function (e) {
			if ($(this).is( "textarea" ) == false) {
				 if (e.which == 13) {
					 e.preventDefault();
					 if ( $(this).is( ":button" ) ) {
						$(this).trigger('click');
					 } else {
						 var nextButton = $(':button').not(':hidden').filter(':visible:first');
						 nextButton.focus().trigger('click');
					 }
				 }
			 }
		 });
	} else {
		var inputs = $(':button').keypress(function (e) {
				 if (e.which == 13) {
					e.preventDefault();
					$(this).trigger('click');
				 }
		 });
	}
}

function clearPopUps(formID) {
	//alert($("#gDIform_container").length);
	var popup_id = popup_stack[popup_stack.length - 1];
	var cnTxtHlp = popup_help[popup_help.length - 1];
	switch (formID) {
		case "Mn":
			// close all popups and goto page home
			if ($("#dform_container").length > 0) $.popfrm._hide();
			if ($("#gSform_container").length > 0) $.popgSLfrm._hide();
			if ($("#gFform_container").length > 0) $.popgFLfrm._hide();
			if ($("#gFIform_container").length > 0) $.popgFIfrm._hide();
			if ($("#gDIform_container").length > 0) $.popgDIfrm._hide();
			if ($("#gGntform_container").length > 0) $.popGntDform._hide();
			
			// adjust in context track for help
			popup_stack = [];
			var mainmenu_item = popup_help[0]; // Keep the first element - which is the mainmenu item
			popup_help = []; 
			popup_help.push(mainmenu_item);
			help_tab_id = 0;
			break;
		case "GD": //ganttDisplay
			if (popup_id == "GD") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 500) && (Math.abs(cnTxtHlp) <= 599)) popup_help.pop();
			break;
		case "DI": //DI forms
			if (popup_id == "DI") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 600) && (Math.abs(cnTxtHlp) <= 699)) popup_help.pop();
			break;
		case "FI": //FI forms
			if (popup_id == "FI") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 300) && (Math.abs(cnTxtHlp) <= 399)) popup_help.pop();
			break;
		case "FL": //FL forms
			help_tab_id = 0;
			if (popup_id == "FL") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 200) && (Math.abs(cnTxtHlp) <= 299)) popup_help.pop();
			break;
		case "SL": //SL forms
			if (popup_id == "SL") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 400) && (Math.abs(cnTxtHlp) <= 499)) popup_help.pop();
			break;
		case "D": //D forms
			if (popup_id == "D") popup_stack.pop();
			if ((Math.abs(cnTxtHlp) >= 100) && (Math.abs(cnTxtHlp) <= 199)) popup_help.pop();
			break;
		default:
			break;
	}
	cnTxtHlp = popup_help[popup_help.length - 1];
	if (cnTxtHlp <= 0) $("#brd_help").css("display","none");
		else  $("#brd_help").css("display","inline");
	if ($("[id$='form_container']").length == 0) {
		$('#prj_select_mnu').css("display", "inline");
		$("#brd_back, #brd_home").css("display", "none");
		if ($("#menu-message-box").text() == "" ) $("#brd_errors_ico").css("display","none");
			else $("#brd_errors_ico").css("display","inline");
	}
	return;
}


function fnNavigator(which_button) {
	var form_id = popup_stack[popup_stack.length - 1];
	switch (which_button) {
		case 0: // Help
			var help_cntxt_sub_id = popup_help_item;
			if (form_id == "FL") {
				$.popgFLfrm._help();
				if ($.popgFLfrm.cnTxtHelpSid == false) help_cntxt_sub_id = 0;
					else if (help_tab_id > 0) help_cntxt_sub_id = help_tab_id;
			} else if (form_id == "FI") {
				$.popgFIfrm._help();
				help_cntxt_sub_id = 0;
			} else if (form_id == "SL") {
				$.popgSLfrm._help();
				if ($.popgSLfrm.cnTxtHelpSid == false) help_cntxt_sub_id = 0;
			} else if (form_id == "GD") {
				$.popGntDform._help();
				help_cntxt_sub_id = 0;
			} else if (form_id == "DI") {
				$.popgDIfrm._help();
				help_cntxt_sub_id = 0;
			} else if (form_id == "D") {
				$.popfrm._help();
				help_cntxt_sub_id = 0;
			}
			// Call Help Function 
			var help_cntxt_id = popup_help[popup_help.length - 1];
			$.ajax({
				url: 'phpContextHelp.php',
				type: 'POST',
				data: {
					"page": 'context-help',  
					"help-id": help_cntxt_id, 
					"help-item": help_cntxt_sub_id 
				},
				timeout: xhr_timeout,
				error: function () {
					hide_all_errors();
					hide_upload_started();
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					response = $.parseJSON(response);
					if (response[0][0].status == "error") {
						jAlert('Could not find help data...','E');
					} else if(response[0][0].status == "NoData"){
						jAlert(response[0][0].data,'E'); // Remove after completion
					} else if(response[0][0].status == "success"){
						var strWindowFeatures = "directories=0,titlebar=1, menubar=no,location=no,resizable=no,toolbar=no,scrollbars=yes,resizable=yes,status=no,top=20, left="+ ( $(window).width() / 2 )+", width="+ ( $(window).width() / 2 )+", height="+$(window).outerHeight();
						if((typeof(myHelpWindow) == 'undefined') || (myHelpWindow.closed)) {
							myHelpWindow = window.open("", "Help_PIfluence",strWindowFeatures);
						} else {
							myHelpWindow.close();
							myHelpWindow = window.open("", "Help_PIfluence",strWindowFeatures);
						}
						$(myHelpWindow.document.head).html(response[0][0].css);
						$(myHelpWindow.document.body).html(response[0][0].data);
						myHelpWindow.focus();
					}
				}
			});
			break;
		case 1: // Back
			if (form_id == "FL") $.popgFLfrm._hide();
				else if (form_id == "FI") $.popgFIfrm._hide();
				else if (form_id == "SL") $.popgSLfrm._hide();
				else if (form_id == "GD") $.popGntDform._hide();
				else if (form_id == "DI") $.popgDIfrm._hide();
				else if (form_id == "D") $.popfrm._hide();
			break;
		case 2: // Home
			if (form_id == "FL") $.popgFLfrm._home();
				else if (form_id == "FI") $.popgFIfrm._home();
				else if (form_id == "SL") $.popgSLfrm._home();
				else if (form_id == "GD") $.popGntDform._home();
				else if (form_id == "DI") $.popgDIfrm._home();
				else if (form_id == "D") $.popfrm._home();
			break;
		case 3: // Errors	
			var msgid = $("#brd_errors [id$='-message-box']").attr('id');
			if ((msgid != undefined) && (msgid !="")) {
				if ($("#"+msgid).text() != '') {
					if ($("#brd_errors").css("display") == "none") $("#brd_errors").css("display", "block");
						else $("#brd_errors").css("display", "none");
				}
			}
			break;
		case 4: // Initiator Edit Errors	
			var msgid = $("#init_edit_errors [id$='-message-box']").attr('id');
			if ((msgid != undefined) && (msgid !="")) {
				if ($("#"+msgid).text() != '') {
					if ($("#init_edit_errors").css("display") == "none") $("#init_edit_errors").css("display", "block");
						else $("#init_edit_errors").css("display", "none");
				}
			}
			break;
			
			
			
		default:
			break;
	}
	return;
}

function forgot_password() {
	$("#error-messages").empty().css({"display":"none"});
	$("#btnLogin, #aTagfPwd").attr("disabled", "disabled");
	var MesgUname = '';
	MesgUname += validate({ 
			elem_id: 'user-name-login',
			mn_length: 6,
			mx_length: 60,
			strg_type: 'uname',
			msg_type: 'mesg-box'
		});
	
	if (MesgUname != '') {
		$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
		$("#error-messages").empty().append('<p>Invalid Username</p>').css({"display":"block"}).focus();
		return false;
	} else {

		var crtNewPwd = confirm('Do you want generate a new password?');
		if (crtNewPwd) {
			//alert('function to create new password');
			//---------------------------
			$("body").addClass("progressor");
			$.ajax({
				url: "phpUserLogin.php",
				type: 'POST',
				data: {
					"page": 'user-forgot-password',
					"user-uname": $('#user-name-login').val() 
				},
				timeout: xhr_timeout,
				error: function () {
					hide_all_errors();
					hide_upload_started();
					alert('Could not connect to server...');
				},
				success: function(response) {
					//alert(response);
					response = $.parseJSON(response);
					if (response[0].status == "error") {
						$("body").removeClass("progressor");
						$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
						$("#error-messages").empty().append(response[0].data).css({"display":"block"}).focus();
						return false;
					} else {
						$("body").removeClass("progressor");
						$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
						if (response[0].data != '') alert(response[0].data);
						return false;
					}
				}
			});	
			//-------------------
		} else {
			$("#btnLogin, #aTagfPwd").removeAttr("disabled").blur();
			return false;
		}
	}
}

function fnProjectSelectorMenu(vSource) {
	
		switch(popup_help[0]){ 
			case 1: // Initiator
				var display_count = ($('#content_auditor').css('display') == "block")?1:0;
					display_count += ($('#content_locker').css('display') == "block")?1:0;
					display_count += ($('#content_edit').css('display') == "block")?1:0;
					display_count += ($('#content_add').css('display') == "block")?1:0;
					
				if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
					if ((act_loaded != 0) && (display_count > 0) && (vSource == true)){
						$("BODY").css("overflow", "auto");
						$("#initiator_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					} else if (vSource == false) {
						$("BODY").css("overflow", "auto");
						$("#initiator_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					}
				} else {
					if ($('#content_add').css('display') == "block") $("#tab_general").trigger("click"); 
						else if ($('#content_edit').css('display') == "block") $('#e_Ptitle').trigger('click'); 
					if ((vSource == true) && ($("[id$='form_container']").length == 0)){
						$("BODY").css("overflow", "hidden");
						$("#initiator_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					} else if (vSource == false) {
						$("BODY").css("overflow", "hidden");
						$("#initiator_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
						$('#Proj-select-edit').val(0);
					}
				}
				break;
			case 2: // Planner
				if (($("#displayparam").length > 0) || ($("#colWSet").length > 0)) popupvanish();
				if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
					if (($('#GanttChartDIV').contents().length > 0) && (parseInt($('#gantt-select-devp').val()) > 0) && (vSource == true)){
						$("BODY").css("overflow", "auto");
						$("#devp_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					} else if (vSource == false) {
						$("BODY").css("overflow", "auto");
						$("#devp_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					}
				} else {
					if ((vSource == true) && ($("[id$='form_container']").length == 0)){
						$("BODY").css("overflow", "hidden");
						$("#devp_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					}	
				}
				break;
			case 3: // Analyzer
				if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
					if ((act_loaded != 0) && (parseInt($('#gantt-select-anlyz').val()) > 0) && (vSource == true)){
						$("BODY").css("overflow", "auto");
						$("#anlyz_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					} else if (vSource == false) {
						$("BODY").css("overflow", "auto");
						$("#anlyz_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					}
				} else {
					if ((vSource == true) && ($("[id$='form_container']").length == 0)){
						$("BODY").css("overflow", "hidden");
						$("#anlyz_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					} else if (vSource == false) {
						$("BODY").css("overflow", "hidden");
						$("#anlyz_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					}
				}
				break;
			case 4: // Archive
				if (($("#displayparam").length > 0) || ($("#colWSet").length > 0)) popupvanish();	
				if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
					if ((act_loaded != 0) && (vSource == true)){
						$("BODY").css("overflow", "auto");
						$("#archive_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					} else if (vSource == false) {
						$("BODY").css("overflow", "auto");
						$("#archive_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					}
				} else {
					if ((vSource == true) && ($("[id$='form_container']").length == 0)){
						$("BODY").css("overflow", "hidden");
						$("#archive_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					} else if (vSource == false) {
						$("BODY").css("overflow", "hidden");
						$("#archive_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					}
				}
				break;
			case 8: // Resource Portfolio 
				if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
					if ((act_loaded != 0) && (parseInt($('#prtflio-select-anlyz').val()) > 0) && (vSource == true)){
						$("BODY").css("overflow", "auto");
						$("#anlyz_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					} else if (vSource == false) {
						$("BODY").css("overflow", "auto");
						$("#anlyz_ctrl").css("display","none");
						$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
					}
				} else {
					if ((vSource == true) && ($("[id$='form_container']").length == 0)){
						$("BODY").css("overflow", "hidden");
						$("#anlyz_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					} else if (vSource == false) {
						$("BODY").css("overflow", "hidden");
						$("#anlyz_ctrl").css("display","block");
						$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
					}
				}
				break;

			/*  Next Case Here  */	
	
			default:
				
				var sMenu_Array = [ 5, 6, 13, 14, 15, 16, 17, 18, 19, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 35, 39, 40, 41 ];
				if ($.inArray(popup_help[0], sMenu_Array) != -1) {
					
					if ($('#prj_select_mnu').hasClass('prj_select_mnu_en')) {
						
						if ((act_loaded != 0) && (vSource == true)){
							$("BODY").css("overflow", "auto");
							$("#master_ctrl").css("display","none");
							if ((popup_help[0] == 24) || (popup_help[0] == 41)) {
								if (act_loaded == 1) {
									$("#content_add").css("display", "block");
									$("#content_edit, #content_list").css("display", "none");
								} else if (act_loaded == 2) {
									$("#content_edit").css("display", "block");
									$("#content_add, #content_list").css("display", "none");
								} else if (act_loaded == 3) {
									$("#content_list").css("display", "block");
									$("#content_add, #content_edit").css("display", "none");
								}	
							}
							$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
						} else if (vSource == false) {
							$("BODY").css("overflow", "auto");
							$("#master_ctrl").css("display","none");
							if ((popup_help[0] == 24) || (popup_help[0] == 41)) {
								if (act_loaded == 1) {
									$("#content_add").css("display", "block");
									$("#content_edit, #content_list").css("display", "none");
								} else if (act_loaded == 2) {
									$("#content_edit").css("display", "block");
									$("#content_add, #content_list").css("display", "none");
								} else if (act_loaded == 3) {
									$("#content_list").css("display", "block");
									$("#content_add, #content_edit").css("display", "none");
								}	
							}
							$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds');
						}
					} else {
						if ((vSource == true) && ($("[id$='form_container']").length == 0)){
							$("BODY").css("overflow", "hidden");
							if ((popup_help[0] == 24) || (popup_help[0] == 41)) {
								$("#content_add, #content_edit, #content_list").css("display", "none");
							}
							$("#master_ctrl").css("display","block");
							$('#prj_select_mnu').removeClass('prj_select_mnu_ds').addClass('prj_select_mnu_en');
						}	
					}				
				}
				break;
		}
	
	if ($("[id$='form_container']").length > 0) {
		$("BODY").css("overflow", "hidden");
		$("#archive_ctrl").css("display","none");
		$('#prj_select_mnu').removeClass('prj_select_mnu_en').addClass('prj_select_mnu_ds').css("display", "none");
	} else $('#prj_select_mnu').css("display", "inline");
}

function errMessageToggle (msgid) {
	var parid = $("#"+msgid).parent().attr('id');
	if ($("#"+msgid).text() != '') {
		if ($("#"+parid).css("display") == "none") $("#"+parid).css("display", "block");
			else $("#"+parid).css("display", "none");
	} 
}



/* --------------------  include and exclude css and js scripts ----------------------------------- */

function check_script_load(filename, filetype){
	var loadedscript=0
	var targetelement=(filetype=="js")? "script" : (filetype=="css")? "link" : "none" //determine element type to create nodelist using
	var targetattr=(filetype=="js")? "src" : (filetype=="css")? "href" : "none" //determine corresponding attribute to test for
	var allsuspects=document.getElementsByTagName(targetelement)
	for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1){
			loadedscript+=1
		}
	}
	return loadedscript;
}


function include_script(filename, filetype){
	if (filetype=="js"){ //if filename is a external JavaScript file
		var fileref=document.createElement('script')
		fileref.setAttribute("type","text/javascript");
		fileref.setAttribute("src", filename);
	} else if (filetype=="css"){ //if filename is an external CSS file
		var fileref=document.createElement("link")
		fileref.setAttribute("rel", "stylesheet");
		fileref.setAttribute("type", "text/css");
		fileref.setAttribute("href", filename);
	}
	if (typeof fileref!="undefined")
		document.getElementsByTagName("head")[0].appendChild(fileref)
}

function exclude_script(filename, filetype){
	var removedelements=0
	var targetelement=(filetype=="js")? "script" : (filetype=="css")? "link" : "none" //determine element type to create nodelist using
	var targetattr=(filetype=="js")? "src" : (filetype=="css")? "href" : "none" //determine corresponding attribute to test for
	var allsuspects=document.getElementsByTagName(targetelement)
	for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1){
			allsuspects[i].parentNode.removeChild(allsuspects[i]) //remove element by calling parentNode.removeChild()
			removedelements+=1
		}
	}
}

function load_script(filename, filetype){
	var targetelement=(filetype=="js")? "script" : (filetype=="css")? "link" : "none" //determine element type to create nodelist using
	var targetattr=(filetype=="js")? "src" : (filetype=="css")? "href" : "none" //determine corresponding attribute to test for
	var allsuspects=document.getElementsByTagName(targetelement)
	var breaker = false;
	for (var i=allsuspects.length; i>=0; i--){ //search backwards within nodelist for matching elements to remove
		if (allsuspects[i] && allsuspects[i].getAttribute(targetattr)!=null && allsuspects[i].getAttribute(targetattr).indexOf(filename)!=-1){
			breaker = true;
			break;
		} 
	}
	if (!breaker) {
		if (filetype=="js"){ //if filename is a external JavaScript file
			var fileref=document.createElement('script')
			fileref.setAttribute("type","text/javascript");
			fileref.setAttribute("src", filename);
		} else if (filetype=="css"){ //if filename is an external CSS file
			var fileref=document.createElement("link")
			fileref.setAttribute("rel", "stylesheet");
			fileref.setAttribute("type", "text/css");
			fileref.setAttribute("href", filename);
		}
		if (typeof fileref!="undefined")
			document.getElementsByTagName("head")[0].appendChild(fileref);
	}
	return true;	
}


/* --------------------  File uploads and return messages control ----------------------------------- */
function show_upload_started(){
	/*if ($('#upload_status').length == 0) {
		$('body').append('<div id="upload_status" style="z-index: 90000;"><img id="upload_pic" src="images/processing/ajax-processing.gif"></div>');
		$('#upload_pic').height($('#upload_status').height());
		$('#upload_pic').width($('#upload_status').width());
	} 
	$("body").addClass("progressor");
	$('#upload_status').css({display: "block"}); */
	
	if(jQuery('body').find('#resultLoading').attr('id') != 'resultLoading'){
		jQuery('body').append('<div id="resultLoading" style="display:none"><div><img src="images/processing/ajax-processing.gif"><div>'+'Processing...'+'</div></div><div class="bg"></div></div>');
		}
		
		jQuery('#resultLoading').css({
			'width':'100%',
			'height':'100%',
			'position':'fixed',
			'z-index':'100000',
			'top':'0',
			'left':'0',
			'right':'0',
			'bottom':'0',
			'margin':'auto'
		});	
		
		/*jQuery('#resultLoading .bg').css({
			'background':'#f1f1f1',
			'opacity':'0.7',
			'width':'100%',
			'height':'100%',
			'position':'absolute',
			'top':'0'
		});*/
		
		jQuery('#resultLoading>div:first').css({
			'width': '250px',
			'height':'75px',
			'text-align': 'center',
			'position': 'fixed',
			'top':'0',
			'left':'0',
			'right':'0',
			'bottom':'0',
			'margin':'auto',
			'font-size':'16px',
			'z-index':'10',
			'color':'#B9742A'
			
		});

	    jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeIn(300);
	    jQuery('body').css('cursor', 'wait');	
	
	
	
	$("[id$='-message-box']").css({display: "none"});
}

function hide_upload_started(){
	event_binder();
	clearTimeout(set_timeout);
	jQuery(document).unbind("active.idleTimer").unbind("idle.idleTimer");
	timer_binder();
	/*setTimeout(function(){
		$("body").removeClass("progressor");
		$('#upload_status').css({display: "none"});
	},500);*/
	
	    jQuery('#resultLoading .bg').height('100%');
        jQuery('#resultLoading').fadeOut(300);
	    jQuery('body').css('cursor', 'default');
	
	
	
	
	
	
	
	/*$("body").removeClass("progressor");
	$('#upload_status').css({display: "none"});*/
}

function hide_message_box(boxID) {
	$("#"+boxID).css("display", "none");
	var pid = $("#"+boxID).parent().attr("id");
	if ((pid != undefined) && (pid != '') && (pid.match("_errors$"))) {
		$("#"+pid).css("display", "none");
		if ($("#"+boxID).text() == '') $("#"+ pid +"_ico").css("display", "none");
	}
	return;
}

function show_message_box(boxID) {
	$("#"+boxID).css("display", "block");
	var pid = $("#"+boxID).parent().attr("id");
	//alert(pid);
	if ((pid != undefined) && (pid != '') && (pid.match("_errors$"))) {
		$("#"+pid).css("display", "block");
		$("#"+ pid +"_ico").css("display", "block");
		// show icon
	}
	//alert(boxID+' > '+pid);
	return;
}

function empty_message_box(boxID) {
	$("#"+boxID).empty();
	var pid = $("#"+boxID).parent().attr("id");
	if ((pid != undefined) && (pid != '') && (pid.match("_errors$"))) {
		$("#"+ pid +"_ico").css("display", "none");
		// hide icon
	}
	return;
}



function TimeToDecimal(aTime) {
	var floatTime = parseFloat(aTime).toFixed(2);
	return ((Math.floor(floatTime) + ((floatTime - Math.floor(floatTime)) / 60 * 100)).toFixed(2));
}

function DecimalToTime(decTime) {
	var decTime = parseFloat(decTime).toFixed(2);
	return ((Math.floor(decTime) + ((decTime - Math.floor(decTime)) / 100 * 60)).toFixed(2));
}


function get_upload_message(frm_name, div_id, style){
	//var upload_status = $("#"+div_id, frames[frm_name].document).text(); //.split("!?!"); ;
	//alert(upload_status);
	
	var iframe0 = document.getElementById(frm_name);
    var iframe0document=iframe0.contentDocument||iframe0.contentWindow.document;
    var inputIframe = iframe0document.getElementById(div_id);
    //alert(inputIframe.text);
	
	if (style == 0) {
		var upload_errors = upload_status[0];
		var uploaded_files = upload_status[1];
		var mssg = ""
		if (upload_errors == '') {
			mssg += '<p><b>Errors occoured are:</b></p><br/>';
				mssg += '<p>'+upload_errors+'</p><br/>'
		}  
		if (uploaded_files == '') {
			mssg += '<p><b>Files uploaded are:</b></p><br/>';
				mssg += '<p>'+uploaded_files+'</p><br/>'
		}	
	} else {
		var upload_errors = $.parseJSON(upload_status[0]);
		var uploaded_files = $.parseJSON(upload_status[1]);
		var mssg = ""
		if (upload_errors.length > 0) {
			mssg += '<b>Errors occoured are:</b><br/>';
			for (i = 0; i < upload_errors.length; i++) {
				mssg += upload_errors[i]+'<br/>'
			}
		}  
		if (uploaded_files.length > 0) {
			mssg += '<b>Files uploaded are:</b><br/>';
			for (i = 0; i < uploaded_files.length; i++) {
				mssg += uploaded_files[i]+'<br/>'
			}
		} 
	}
	return mssg;
 }
 
function clearFile(list_id) {
	var div_Id = '#'+list_id;
		// remove all file for upload within the div
	  $('a.MultiFile-remove',div_Id).trigger('click');
	  
}

function zipDownloader(page_info, field_info, entity_info, ticket_info) {

	$("body").append('<div id="dnload_tmpForm" style="z-index: 99989;"></div>');
	$("#dnload_tmpForm").load("General_Services.html #downloaderForm", function(responseText, statusText, xhr) {
		switch(page_info){ 
			case "emp-doc-dwl":
				$("#downloaderFile").attr("action", "dwlEmpDoc.php");
				break;
			case "cust-doc-dwl":
				$("#downloaderFile").attr("action", "dwlCustDoc.php");
				break;
			case "proj-cntr-doc-dwl":
				$("#downloaderFile").attr("action", "dwlProjCntrDoc.php");
				break; 
			case "gnt-task-deliv-dwl": 
				$("#downloaderFile").attr("action", "dwlGntTaskDeliv.php");
				break;
			case "gnt-task-MoMs-dwl":
				$("#downloaderFile").attr("action", "dwlGntTaskMoMs.php");
				break;
			case "gnt-task-Reports-dwl":
				$("#downloaderFile").attr("action", "dwlGntTaskReports.php");
				break; 
			case "gnt-task-crdocs-dwl":
				$("#downloaderFile").attr("action", "dwlGntTaskCRdocs.php");
				break; 
			case "gnt-task-bddocs-dwl":
				$("#downloaderFile").attr("action", "dwlGntTaskBDdocs.php");
				break; 
			case "baklog-sty-attach-dwl":
				$("#downloaderFile").attr("action", "dwlBaklogStorydocs.php");
				break; 
			case "backlog-story-gtdocs-dwl":
				$("#downloaderFile").attr("action", "dwlBacklogStoryGTdocs.php"); 
				break; 
				
				
		}
		$('#page').val(page_info);
		$('#field, #ticket-id').val(field_info);
		$('#ticket-id').val(ticket_info);
		$('#entities').val(entity_info);
		$('#user-info').val(user_id);
		$('#btnDnloadSubmit').trigger('click');
		hide_upload_started();
		$("#dnload_tmpForm").remove();
		if(statusText == "error") {
			alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
		}
	});
}

function tranformDate(dateString){
	var resultStr = '';
	if (dateString != '') {
		var indDates = dateString.split(",");
		for (i = 0; i<indDates.length; i++) {
		   var splitDates = indDates[i].split("/");
		   var conDateStr = splitDates[1]+"/"+splitDates[0]+"/"+splitDates[2];
		   resultStr += conDateStr;
		   if (i<indDates.length-1) resultStr += ",";
		}
	}	
	return resultStr;
}

function delete_custom_report(fileName) {
	$.ajax({
		url: "phpFlexService.php",
		type: 'POST',
		data: {
			"page": 'delete-custom-report',
			"file-handle": fileName,
			"user-id": user_id 
		},
		timeout: xhr_timeout * 10,   // Timeout is set 10 times NOTE
		error: function () {
			return false;
		}, 
		success: function(response) {
			return false;
		}
	});	
}


function showResAvail(resource_id, project_id, form_id) {
	if (form_id != undefined) user_form_id = form_id;
		else user_form_id = '';
	jgSforms('showResAvail', resource_id+','+project_id,'Resource Availability Chart...','|WA-3|WA-2');
}

function showResActuals(resource_id, project_id, form_id) {
	if (form_id != undefined) user_form_id = form_id;
		else user_form_id = '';
	jgSforms('showResActuals', resource_id+','+project_id,'Resource Performance Chart...','|WA-3|WA-2');
}

function TodayInBrit() {
	var d = new Date();
	var day = d.getDate();
	var month = d.getMonth() + 1;
	var year = d.getFullYear();
	if (day < 10) {
		day = "0" + day;
	}
	if (month < 10) {
		month = "0" + month;
	}
	var date = day + "/" + month + "/" + year;
	return date;
}; 

function TodayInUs() {
	var d = new Date();
	var day = d.getDate();
	var month = d.getMonth() + 1;
	var year = d.getFullYear();
	if (day < 10) {
		day = "0" + day;
	}
	if (month < 10) {
		month = "0" + month;
	}
	var date =  month + "/" + day + "/" + year;
	return date;
}; 



first_time_load = true;
prjAgility = 0;
userFname = '';
userFullName = '';
org_date_format = 'dd/mm/yyyy';
org_first_week_day = 0; 
org_week_ends = '0,6';
xhr_timeout = 60000;   
user_id = 0;  
users_name = '';
user_profile = ''; 
user_sys_id = 0; 
clipAction = '';
clipNode = -1;
img_extns = 'png'; 
doc_extns = 'zip|txt';
publicView = 0; 
profileItem = '';
img_max_size = 40;
tt_exp = 0;
tt_delay = 0;
set_timeout = 0;
popup_stack = [];
sp_to_hrs = 0;
SA_show = false;
scroller = 0; // REMOVE after checking in session expiry popups
estmat = '#656565';
adjust = '#656565';
noproj = '#656565';
totest = '#656565';
totadj = '#656565';
prfrsa = '#656565';
prfsha = '#656565';
prfota = '#656565';
prfrsc = '#656565';
prfshc = '#656565';
billwc = '#656565';
estfcc = '#656565';
actfcc = '#656565';
pjtval = '#656565';
baslne = '#656565';
unasgn = '#656565';
opnsts = '#656565';
rvwsts = '#656565';
acpsts = '#656565';
mtgsts = '#656565';
rjtsts = '#656565';
clssts = '#656565';
delsts = '#656565';
lowclr = '#656565';
medclr = '#656565';
hghclr = '#656565';
pvclr = '#656565';
evclr = '#656565';
acclr = '#656565';
svspic = '#656565';
cvcpic = '#656565';
SA_show = false;




