﻿

/*------------- Backlog Story Update Actions --------------     */
function BacklogViewer(node_ID) {
	$("html, body").animate({ scrollTop: 0 }, "slow");
	hide_message_box("gntFl-message-box");
	$.popgFLfrm._show();
	selNodeID = node_ID;
	var NodeInfo = getNodeInfo(node_ID);
	$('#gntTaskName-show').val('(ID: ' +getOrigLink(node_ID)+') '+getNodeName(node_ID));
	help_tab_id = 21;
	
	$(".taskmenu > li").click(function(e){
		
		switch(e.target.id){ 
			case "tab_upd_progress": 
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 21;
				$("#tab_upd_progress").addClass("active");
				$("#tab_upd_work, #tab_upd_cost, #tab_upd_meetings, #tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskProgress").fadeIn();
				$("#content_tskReviews, #content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_work":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 22;
				$("#tab_upd_work").addClass("active");
				$("#tab_upd_progress, #tab_upd_cost, #tab_upd_meetings, #tab_upd_documents, #tab_upd_reviews").removeClass("active");
				$("#content_tskWork").fadeIn();
				$("#content_tskReviews, #content_tskProgress, #content_tskCost, #content_tskMeetings, #content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_cost":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 23;
				$("#tab_upd_cost").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_meetings,#tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskCost").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_meetings":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 24;
				$("#tab_upd_meetings").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskMeetings").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_documents":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 25;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reviews").removeClass("active");
				$("#tab_upd_documents").addClass("active");
				$("#content_tskDocuments").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings").css("display", "none");
			break; 
			case "tab_upd_reviews":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 27;
				$("#tab_upd_reviews").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_documents").removeClass("active");
				$("#content_tskReviews").fadeIn();
				$("#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 

		}
		return false;
	});
	$("#content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskReviews, #content_tskDocuments").css("display", "none");
	
	styProgress_bar = new JustGage({
		id: "styProgress-bar", 
        value: 0, 
        min: 0,
        max: 100,
		gaugeColor: "#EBECE7", 
        title: "Story Progress",
		titleFontColor: "#9AA08D",  
        levelColors: ["#C1D693"],
        showMinMax: false, 
		valueFontColor: "#717171",
		gaugeWidthScale: 1.2, 
        label: "%", 
		labelFontColor: "#717171"  
	});
	
	
	
	show_upload_started();
	$('#gnt-sty-prty').addClass('populate_loading');
	$.ajax({
		url: "phpPopulate.php",
		type: 'POST',
		data: {"page": "backlog-story-viewer", "project-id":$('#gantt-select-devp').val(), "node-id":selNodeID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);
			response = $.parseJSON(response);
			hide_upload_started();
			$('#gnt-sty-prty').removeClass('populate_loading');
			$('#gnt-sty-prty').val(response["priority"]);
			styProgress_bar.refresh(parseFloat(response["progress"]));	
		}
	});

	
	$.ajax({
		url: "phpAgileLoad.php",
		type: 'POST',
		data: {"page": "sty-desc-load", "project-id": $('#gantt-select-devp').val(), "node-id":node_ID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ds) {
			//$('bak-story-desc').removeClass('populate_loading');
			//alert(response_ds);
			response_ds = JSON.parse(response_ds);
			$('#bak-story-desc').html(response_ds);
		}
	});
	
	
		
		

// Grid for Story Sprint Status
	$("#flex-sty-sprint").flexigrid ({
		url: 'phpAgileFlexLoader.php', /*       Complete              */
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Sprint', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'Occurrences', name : 'agile_sprint_release_sp', width : 120, sortable : false, align: 'right'},
			{display: 'Released Work', name : 'agile_sprint_release_sp', width : 120, sortable : false, align: 'right'}
			],
		sortname: "node_id",
		sortorder: "asc",
		usepager: true,
		title: 'Associated Sprints',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 203,
		singleSelect: true,
		appPage: "backlog-storySprints",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 


	$("#flex-sty-history").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Updated on', name : 'cr_date', width : 175, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Action', name : 'story_action', width : 120, sortable : true, align: 'left'},
			{display: 'Story ID', name : 'story_number', width : 175, sortable : false, align: 'left'},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'Priority', name : 'node_priority', width : 120, sortable : false, align: 'left'},
			{display: 'Notes', name : 'task_notes ', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'View', bclass: 'view flx-bklgStyHist-vwe', onpress : styEditHistory}, 
			{separator: true}
			],
		searchitems : [
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "cr_date",
		sortorder: "desc",
		usepager: true,
		title: 'Story Edit History',
		useRp: true,
		onDoubleClick: '.flx-bklgStyHist-vwe',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyEdtHistory",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 

	$("#flex-sty-gts").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
			{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [ // function in Gantt_Controls.js
			{name: 'Comment', bclass: 'comment flx-bklgStyGTs-cmt', onpress : GTLists},
			{name: 'View', bclass: 'view', onpress : GTLists},
			{name: 'Add', bclass: 'add', onpress : GTLists},
			{name: 'Edit', bclass: 'edit', onpress : GTLists},
			{name: 'History', bclass: 'history', onpress : GTLists},
			{name: 'Delete', bclass: 'delete', onpress : GTLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'cr_title', isdefault: true},
			{display: 'Ticket ID', name : 'cr_id'},
			{display: 'Requested by', name : 'requested_by'}
			], 
		sortname: "requested_on",
		sortorder: "desc",
		usepager: true,
		title: 'Backlog Grooming Tips',
		useRp: true,
		onDoubleClick: '.flx-bklgStyGTs-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyGTs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 

	$("#flex-sty-issues").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
			{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
			{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [  // function in Gantt_Controls.js
			{name: 'Comment', bclass: 'comment', onpress : BacklogIssueLists},
			{name: 'Add', bclass: 'add', onpress : BacklogIssueLists}, 
			{name: 'Edit', bclass: 'edit flx-bklgStyChlg-edt', onpress : BacklogIssueLists}, 
			{name: 'History', bclass: 'history', onpress : BacklogIssueLists},
			{name: 'Delete', bclass: 'delete', onpress : BacklogIssueLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'issue_title', isdefault: true},
			{display: 'Ticket ID', name : 'issue_id'},
			{display: 'Reported by', name : 'raised_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Backlog Challenges',
		useRp: true,
		onDoubleClick: '.flx-bklgStyChlg-edt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-story-challenges",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 

	$("#flex-sty-documents").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Download', bclass: 'download', onpress : backlogDocsLists},
			{name: 'View', bclass: 'view flx-bklgStyAtch-vw', onpress : backlogDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: false,
		title: 'Story Attachments',
		useRp: false,
		onDoubleClick: '.flx-bklgStyAtch-vw',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		appPage: "baklog-storyattach",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+',1'
	}); 
	
	
	

}

/*------------- Backlog Story Update Actions --------------     */
function BacklogUpdator(node_ID) {
	$("html, body").animate({ scrollTop: 0 }, "slow");
	hide_message_box("gntFl-message-box");
	$.popgFLfrm._show();
	selNodeID = node_ID;
	var NodeInfo = getNodeInfo(node_ID);
	$('#gntTaskName-show').val('(ID: ' +getOrigLink(node_ID)+') '+getNodeName(node_ID));
	help_tab_id = 11;
	
	$(".taskmenu > li").click(function(e){
		
		switch(e.target.id){ 
			case "tab_upd_progress": 
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 11;
				$("#tab_upd_progress").addClass("active");
				$("#tab_upd_work, #tab_upd_cost, #tab_upd_meetings, #tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskProgress").fadeIn();
				$("#content_tskReviews, #content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_work":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 12;
				$("#tab_upd_work").addClass("active");
				$("#tab_upd_progress, #tab_upd_cost, #tab_upd_meetings, #tab_upd_documents, #tab_upd_reviews").removeClass("active");
				$("#content_tskWork").fadeIn();
				$("#content_tskReviews, #content_tskProgress, #content_tskCost, #content_tskMeetings, #content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_cost":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 13;
				$("#tab_upd_cost").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_meetings,#tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskCost").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_meetings":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 14;
				$("#tab_upd_meetings").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_documents,#tab_upd_reviews").removeClass("active");
				$("#content_tskMeetings").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_documents":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 15;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reviews").removeClass("active");
				$("#tab_upd_documents").addClass("active");
				$("#content_tskDocuments").fadeIn();
				$("#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings").css("display", "none");
			break; 
			case "tab_upd_reviews":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 16;
				$("#tab_upd_reviews").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_documents").removeClass("active");
				$("#content_tskReviews").fadeIn();
				$("#content_tskProgress,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 

		}
		return false;
	});
	$("#content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskReviews, #content_tskDocuments").css("display", "none");
	
	$("#styEstimate-sps").spinner({min: 0, max: 1000, decimals: 2, stepping: 0.25});
	$("#styEstimate-tolerance").spinner({min: -100, max: 200});	
	
	$("#styEstimate-sps").on( "spinchange", function( event, ui ) { 
		if (parseFloat($('#styEstimate-sps').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$("#styEstimate-tolerance").spinner( "enable" );
			if (parseInt($('#styEstimate-tolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
				$('#styEstimate-tolrnc-block').css("display", "block");
				$('#styEstimate-tolrnc-basis').attr('placeholder', '-- required --');
			} else {
				$('#styEstimate-tolrnc-block').css("display", "none");
				$('#styEstimate-tolrnc-basis').removeAttr('placeholder').val('');
			}
		} else {
			$("#styEstimate-tolerance").spinner( "disable" ).val(0);
			$('#styEstimate-tolrnc-block').css("display", "none");
			$('#styEstimate-tolrnc-basis').removeAttr('placeholder').val('');
		}	
	});
	
	$("#styEstimate-tolerance").on( "spinchange", function( event, ui ) { 
		if (parseFloat($('#styEstimate-tolerance').val().replace(/[^0-9\-\.]/g, '')) != 0) {
			$('#styEstimate-tolrnc-block').css("display", "block");
			$('#styEstimate-tolrnc-basis').attr('placeholder', '-- required --');
		} else {
			$('#styEstimate-tolrnc-block').css("display", "none");
			$('#styEstimate-tolrnc-basis').removeAttr('placeholder');
		}	
	});
	
	show_upload_started();
	//$("#gnt-meeting-dur").spinner({min: 0, stepping: 0.25});
	$('#styEstimate-sps-basis, #styEstimate-tolrnc-basis, #styEstimate-res').addClass('populate_loading');
	$.ajax({
		url: "phpPopulate.php",
		type: 'POST',
		data: {"page": "backlog-story-resources", "field":$('#gantt-select-devp').val(), "condition":selNodeID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);
			response = $.parseJSON(response);
			//$.popgFLfrm._show();
			hide_upload_started();
			$("#styEstimate-res").empty().attr("multiple","multiple").append($("<option></option>").attr("value","").text(""));
			if (response.length > 0) {
				
				$('#styEstimate-sps').val(response[0]["budget-available"].toFixed(2));
				$("#styEstimate-tolerance").val(response[0]["sp-tolerance"]);
				$('#styEstimate-sps-basis').val(response[0]["sp-notes"]);
				$("#styEstimate-tolrnc-basis").val(response[0]["tolerance-notes"]);
				if (parseFloat(response[0]["budget-available"]) > 0) {
					$("#styEstimate-tolerance").spinner( "enable" );
					$('#styEstimate-tolrnc-block').css("display", "block");
					$('#styEstimate-tolrnc-basis').attr('placeholder', '-- required --');
				} else {
					$("#styEstimate-tolerance").spinner( "disable" ).val(0);
					$('#styEstimate-tolrnc-block').css("display", "none");
					$('#styEstimate-tolrnc-basis').removeAttr('placeholder').val('');
				}
				$("#styEstimate-sps").spinner( "option", "min", response[0]["in-sprint"]);
								
				if (parseInt(response[0]["sp-tolerance"]) > 0) $('#styEstimate-tolrnc-block').css("display", "block");
					else $('#styEstimate-tolrnc-block').css("display", "none");
				for(ij = 0; ij< response.length; ij++) {
					if (!$('#optg_'+response[ij]["dept-no"]).length)  $('#styEstimate-res').append($("<optgroup></optgroup>").attr('id','optg_'+ response[ij]["dept-no"]).attr('label', response[ij]["dept-name"]));
					$('#optg_'+response[ij]["dept-no"]).append($('<option></option>').attr('value', response[ij]["value"]).text(response[ij]["descr"]));
				
					if (parseInt(response[ij]["is-estimator"]) == 1) $('#styEstimate-res option[value='+ response[ij]["value"] +']').attr("selected","selected");
				
				};
			};
			$('#styEstimate-sps-basis, #styEstimate-tolrnc-basis, #styEstimate-res').removeClass('populate_loading');
			$('#styEstimate-res').multiSelect({selectAll: false, 
											listHeight: 150, 
											noneSelected: "Select Estimators", 
											oneOrMoreSelected: '% Estimator(s) Selected',
											spanWidth: -70, 
											optWidth: 0, 
											resultFld: "styEstimate_res_list"}); // , oneOrMoreSelected: '*' 
		}
	});

	
	$.ajax({
		url: "phpAgileLoad.php",
		type: 'POST',
		data: {"page": "sty-desc-load", "project-id": $('#gantt-select-devp').val(), "node-id":node_ID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response_ds) {
			//$('bak-story-desc').removeClass('populate_loading');
			//alert(response_ds);
			response_ds = JSON.parse(response_ds);
			$('#bak-story-desc').html(response_ds);
		}
	});
	
	
		
		

// Grid for Story Update History
	$("#flex-styEstHistory").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Updated on', name : 'cr_date', width : 175, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Estimated Work', name : 'estimate_work_hours', width : 175, sortable : false, align: 'right'},
			{display: 'Basis of Estimation', name : 'story_estimation_basis', width : 360, sortable : false, align: 'left'},
			{display: 'Work Tolerance', name : 'work_ratio_tolerance', width : 180, sortable : false, align: 'right'},
			{display: 'Basis of Tolerance', name : 'tolerance_notes ', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'View', bclass: 'view flx-bklgStyHis-vw', onpress : styUpdHistory}, 
			{separator: true}
			],
		searchitems : [
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "cr_date",
		sortorder: "desc",
		usepager: true,
		title: 'Story Estimate - Update History',
		useRp: true,
		onDoubleClick: '.flx-bklgStyHis-vw',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyUpdHistory",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 



	$("#flex-sty-gts").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
			{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [ // function in Gantt_Controls.js
			{name: 'Add', bclass: 'add', onpress : GTLists},
			{name: 'Edit', bclass: 'edit', onpress : GTLists},
			{name: 'Update', bclass: 'update', onpress : GTLists},
			{name: 'View', bclass: 'view', onpress : GTLists},
			{name: 'Comment', bclass: 'comment flx-prjGTsSty-cmt', onpress : GTLists},
			{name: 'History', bclass: 'history', onpress : GTLists},
			{name: 'Purge', bclass: 'purge', onpress : GTLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'cr_title', isdefault: true},
			{display: 'Ticket ID', name : 'cr_id'},
			{display: 'Requested by', name : 'requested_by'}
			], 
		sortname: "requested_on",
		sortorder: "desc",
		usepager: true,
		title: 'Backlog Grooming Tips',
		useRp: true,
		onDoubleClick: '.flx-prjGTsSty-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-storyGTs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 

	$("#flex-sty-issues").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
			{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
			{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Story', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [  // function in Gantt_Controls.js
			{name: 'Add', bclass: 'add', onpress : BacklogIssueLists}, 
			{name: 'Edit', bclass: 'edit', onpress : BacklogIssueLists}, 
			{name: 'Update', bclass: 'update', onpress : BacklogIssueLists}, 
			{name: 'Comment', bclass: 'comment flx-prjChlgSty-cmt', onpress : BacklogIssueLists},
			{name: 'History', bclass: 'history', onpress : BacklogIssueLists},
			{name: 'Purge', bclass: 'purge', onpress : BacklogIssueLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'issue_title', isdefault: true},
			{display: 'Ticket ID', name : 'issue_id'},
			{display: 'Reported by', name : 'raised_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Backlog Challenges',
		useRp: true,
		onDoubleClick: '.flx-prjChlgSty-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "backlog-story-challenges",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 

	$("#flex-sty-documents").flexigrid ({
		url: 'phpAgileFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Story Title', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Upload', bclass: 'upload', onpress : backlogDocsLists},
			{name: 'Download', bclass: 'download', onpress : backlogDocsLists},
			{name: 'View', bclass: 'view flx-prjDocsSty-vwe', onpress : backlogDocsLists},
			{name: 'Delete', bclass: 'delete', onpress : backlogDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Story Attachments',
		useRp: false,
		onDoubleClick: '.flx-prjDocsSty-vwe',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 202,
		appPage: "baklog-storyattach",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+',1'
	}); 
	
	
	

}

function submitBakStoryUpdate(node_ID) {

	show_upload_started();
	empty_message_box("gntFl-message-box");
	var ValidStatus = true;
	var MesgStrg = '';
	var story_estimate = parseFloat($('#styEstimate-sps').val().replace(/[^0-9\-\.]/g, ''));
	
	
	if (($("#styEstimate_res_list").val() == '') && story_estimate > 0) {	
		MesgStrg += '<p><i>Estimated by</i></p>' + '<p>&#9830; Select atleast one Estimator</p>'; 
	}; 
	
	if (MesgStrg.length > 0) {
		ValidStatus = false;
		$("#gntFl-message-box").append(MesgStrg);
	};	
	MesgStrg = '';
	MesgStrg += validate({ 
			elem_id: 'styEstimate-sps-basis',
			mn_length: 2,
			mx_length: 600,
			strg_type: 'ctext',
			msg_type: 'mesg-box'
		});
	if (MesgStrg.length > 0) {
		ValidStatus = false;
		$("#gntFl-message-box").append('<br/><p><b>Basis of Estimate</b></p>').append(MesgStrg);
	}

	var estimate_tolerance = parseInt($('#styEstimate-tolerance').val().replace(/[^0-9\-\.]/g, ''));
	if (estimate_tolerance > 0) {
		MesgStrg = '';
		MesgStrg += validate({ 
				elem_id: 'styEstimate-tolrnc-basis',
				mn_length: 2,
				mx_length: 300,
				strg_type: 'ctext',
				msg_type: 'mesg-box'
			});
		if (MesgStrg.length > 0) {
			ValidStatus = false;
			$("#gntFl-message-box").append('<br/><p><b>Basis of Tolerance</b></p>').append(MesgStrg);
		}		
	} else $("#styEstimate-tolrnc-basis").val('');
	
	if (ValidStatus == false) { // change
		show_message_box("gntFl-message-box");
		hide_upload_started();
		jAlert('Correct the errors indicated...','E', function(){
			return;
		});
	} else {
		var estimators = '';
		if ($("#styEstimate_res_list").val() != '') {	
			var selectRes = $("#styEstimate_res_list").val().split(",");
			for(i=0; i<selectRes.length; i++) {
				var indResource = selectRes[i].split("~");
				if (indResource[0] != '') {
					if (estimators == '') estimators = indResource[0];
						else estimators = estimators + "," + indResource[0];
				}	
			} 			
		}; 
		$.ajax({
			url: "phpBacklogService.php",
			type: 'POST',
			data: {"page": "backlog-story-updt-estimate", 
					"project-id": $('#gantt-select-devp').val(), 
					"node-id": node_ID, 
					"estimate-sps": story_estimate,
					"estimate-basis": $("#styEstimate-sps-basis").val(),
					"estimate-resources": estimators,
					"estimate-tolerance": estimate_tolerance,
					"tolerance-basis": $("#styEstimate-tolrnc-basis").val(),
					"user-id": user_id,
					"user-profile": user_profile,
					"user-sys-id": user_sys_id 
				},
			timeout: xhr_timeout,
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			},
			success: function(response) {
				//alert(response);
				hide_all_errors();
				hide_upload_started();
				response = $.parseJSON(response);
				if (response[0][0].status == "error") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert(response[0][0].data['messg'],'E', function() {
							loadProjectGantt('');
					});
				} else if (response[0][0].status == "invalid") {
					hide_upload_started();
					hide_message_box("gntFl-message-box");
					jAlert('Correct the errors indicated...','E', function() {
							loadProjectGantt('');
							empty_message_box("gntFl-message-box");
							$("#gntFl-message-box").append(response[0][0].data['messg']);
							show_message_box("gntFl-message-box");
					});
				} else if (response[0][0].status == "success") {
					// --- check  and correct
					hide_upload_started();
					if (response[0][0].data[0]['node-id'] != '-1') {
						jAlert(response[0][0].data[0]['messg'],'S',function() {
							$.popgFLfrm._hide();
							loadProjectGantt('');
						});
					} else {
						jAlert(response[0][0].data[0]['messg'],'E');
					} 
				} else {
						jAlert(response[0][0].data[0]['messg'],'E');
				} 
				
				
				
				
			}
		});	
	}


}

/*------------- End OF BAcklog Story Update --------------     */

/*------------- Project Task View Actions --------------     */

function TaskViewer(node_ID) {
	$("html, body").animate({ scrollTop: 0 }, "slow");
	hide_message_box("gntFl-message-box");
	var tTask = '(Task: ';
	if (prjAgility == 1) tTask = '(ID: ';
	$.popgFLfrm._show();
	taskWork = 0;
	taskEarnedWork = 0;
	taskResWork = 0;
	taskResEarnedWork = 0;
	selNodeID = node_ID;
	var NodeInfo = getNodeInfo(node_ID);
	$('#gntTaskName-show').val(tTask +getOrigLink(node_ID)+') '+getNodeName(node_ID));
	help_tab_id = 21;
	$(".taskmenu > li").click(function(e){
		
		switch(e.target.id){ 
			case "tab_vw_progress": 
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 21;
				$("#tab_vw_progress").addClass("active");
				$("#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#content_tskProgress").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break;
			case "tab_vw_resource":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 20;
				$("#tab_vw_progress,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_resource").addClass("active");
				$("#content_tskResource").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskWork,#content_tskReviews,#content_tskProgress,#content_tskCost,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break;
			case "tab_vw_work":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 22;
				$("	#tab_vw_progress,#tab_vw_resource,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_work").addClass("active");
				$("#content_tskWork").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskProgress,#content_tskCost,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break;
			case "tab_vw_cost":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 23;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_meetings,#tab_vw_reports,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_cost").addClass("active");
				$("#content_tskCost").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_vw_meetings":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 24;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_reports,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_meetings").addClass("active");
				$("#content_tskMeetings").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskReports,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_vw_documents":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 25;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_documents").addClass("active");
				$("#content_tskDocuments").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskReports").css("display", "none");
			break; 
			case "tab_vw_reports":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 26;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_documents,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_preventive").removeClass("active");
				$("#tab_vw_reports").addClass("active");
				$("#content_tskReports").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_vw_reviews":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 27;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_corrective,#tab_vw_preventive,#tab_vw_documents	").removeClass("active");
				$("#tab_vw_reviews").addClass("active");
				$("#content_tskReviews").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskResource,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_vw_corrective":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 28;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_reviews,#tab_vw_preventive,#tab_vw_documents").removeClass("active");
				$("#tab_vw_corrective").addClass("active");
				$("#content_tskCorectiv").fadeIn();
				$("#content_tskPreventiv,#content_tskReviews,#content_tskResource,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_vw_preventive":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 29;
				$("#tab_vw_progress,#tab_vw_resource,#tab_vw_work,#tab_vw_cost,#tab_vw_meetings,#tab_vw_reports,#tab_vw_reviews,#tab_vw_corrective,#tab_vw_documents").removeClass("active");
				$("#tab_vw_preventive").addClass("active");
				$("#content_tskPreventiv").fadeIn();
				$("#content_tskCorectiv,#content_tskReviews,#content_tskResource,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
		}
		return false;
	});
	
	$("#content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskReports, #content_tskReviews, #content_tskDocuments").css("display", "none");
	// -----    or set in jsgantt_addm.css
	
	if (parseInt(NodeInfo["reviews"]) == 1) $("#tab_vw_reviews").css("display", "block");
		else $("#tab_vw_reviews").css("display", "none");
		
	if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
		$(".HideFinance, #tab_vw_cost, #tab_vw_reports").css("display", "none");
	} else {
		$(".HideFinance, #tab_vw_cost, #tab_vw_reports").css("display", "block");
	
	}
	if ((user_profile == 'stake') && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
		$(".HideActuals, #tab_vw_work").css("display", "none");  // Actuals block
		$("#gnt-est-fc-show").removeClass("flex-side-left").addClass("flex-center");
	} else { 
		$(".HideActuals, #tab_vw_work").css("display", "block"); // Show Actuals
		$("#gnt-est-fc-show").removeClass("flex-center").addClass("flex-side-left");
	}	
		
	//if (parseFloat(NodeInfo["progress"]) > 0) $("#no-progress-bugs").css("display", "block");
		
		
		
		
	switch (selNodeType) {
	
		case 'rMlTask': { // Milestone
			$("#tab_vw_work, #tab_vw_meetings, #tab_vw_reports, #tab_vw_corrective").css("display","none");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'rgTask': { // recur group
			$("#tab_vw_meetings, #tab_vw_reports, #tab_vw_corrective, #recur-task-noRisk").css("display","none");
			$("#flex-tsk-issuesLog").removeClass("flex-side-left").addClass("flex-center");
			break;
		}
		case 'root': { // project root
			$("#tab_vw_meetings, #tab_vw_reports").css("display","none");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'nTask': { // normal task
			$("#tab_vw_meetings, #tab_vw_reports").css("display","none");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'rtTask': { // recur child
			$("#tab_vw_corrective, #recur-task-noRisk").css("display","none");
			$("#flex-tsk-issuesLog").removeClass("flex-side-left").addClass("flex-center");
			break;
		}
		
	}


	
	
	
	tskProgress_bar = new JustGage({
		id: "tskProgress-bar", 
        value: 0, 
        min: 0,
        max: 100,
		gaugeColor: "#EBECE7", 
        title: "Task Progress",
		titleFontColor: "#9AA08D",  
        levelColors: ["#C1D693"],
        showMinMax: false, 
		valueFontColor: "#717171",
		gaugeWidthScale: 1.5, 
        label: "%", 
		labelFontColor: "#717171"  
	});
	
	
	show_upload_started();
	$.ajax({
		url: "phpPopulate.php",
		type: 'POST',
		data: {"page": "gantt-task-viewer", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);
			response = $.parseJSON(response);
			hide_all_errors();
			hide_upload_started();
			taskWork = parseFloat(response[0]["work"]);
			taskEarnedWork = parseFloat(response[0]["earnedwork"]);
			if (taskWork > 0) taskProgress = parseInt(taskEarnedWork / taskWork * 100);
				else taskProgress = 0;
			tskProgress_bar.refresh(taskProgress);
			if (parseInt(response[0]["meetings"]) == 0) $("#tab_vw_meetings").css("display","none");
			if (parseInt(response[0]["reports"]) == 0) $("#tab_vw_reports").css("display","none");
				else if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) $("#tab_vw_reports").css("display", "none");
			
			if (parseInt(response[0]["mom_circulate"]) == 0) $("#gnt-mom-sent").val("Not Circulated");
				else $("#gnt-mom-sent").val("Circulated: "+ response[0]["mom_circulate"] +" time(s)");
				
			if (parseInt(response[0]["report_circulate"]) == 0) $("#gnt-reports-sent").val("Not Circulated");
				else $("#gnt-reports-sent").val("Circulated: "+ response[0]["report_circulate"] +" time(s)");
				
			$('#gnt-CA').val(response[0]["control-account"]);	
			$('#gnt-total-est-fc').val(response[0]["total-est-fixcost"]);	
			$('#gnt-total-act-fc').val(response[0]["total-actual-fixcost"]);	
		}
	});	

	
	$("#tskProgres-show").spinner( "disable" ); // chech this whether needed
	
	if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) { 
		$("#flex-Resource").flexigrid ({  // Without Financials
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Resource', name : 'resource_id', width : 360, sortable : false, align: 'left'},
				{display: 'Role', name : 'resource_role', width : 175, sortable : false, align: 'left'},
				
				{display: 'Work Contour', name : 'work_mode', width : 360, sortable : true, align: 'left'},
				{display: 'Work Rate', name : 'work_rate', width : 175, sortable : true, align: 'center'},
				
				{display: 'Estimate Work', name : 'resource_hours', width : 175, sortable : true, align: 'right'},
				{display: 'Work Progress', name : 'resource_earned_work', width : 175, sortable : false, align: 'right'},
				
				{display: 'Actual Work', name : 'resource_actual_hours', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Regular Work', name : 'resource_actual_reg_hr', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Overtime Work', name : 'resource_actual_ot_hr', width : 175, sortable : false, align: 'right'}
				],
			sortname: "work_mode",
			sortorder: "asc",
			usepager: true,
			title: 'Task Resources Details',
			useRp: true,
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			singleSelect: false,
			appPage: "project-taskResource",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Finance'
		}); 
	} else if ((user_profile == 'stake') && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
		$("#flex-Resource").flexigrid ({  // Without Actuals
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Resource', name : 'resource_id', width : 360, sortable : false, align: 'left'},
				{display: 'Role', name : 'resource_role', width : 175, sortable : false, align: 'left'},
				{display: 'Hourly Rate', name : 'resource_rate', width : 175, sortable : false, align: 'right'},
				{display: 'Overtime Rate', name : 'resource_ot_rate', width : 175, sortable : false, align: 'right'},
				
				{display: 'Work Contour', name : 'work_mode', width : 360, sortable : true, align: 'left'},
				{display: 'Work Rate', name : 'work_rate', width : 175, sortable : true, align: 'center'},
				
				{display: 'Estimate Work', name : 'resource_hours', width : 175, sortable : true, align: 'right'},
				{display: 'Estimate Cost', name : 'resource_cost', width : 175, sortable : true, align: 'right'},
				{display: 'Work Progress', name : 'resource_earned_work', width : 175, sortable : false, align: 'right'}
				],
			sortname: "work_mode",
			sortorder: "asc",
			usepager: true,
			title: 'Task Resources Details',
			useRp: true,
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			singleSelect: false,
			appPage: "project-taskResource",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Actuals'
		}); 
	} else {
		$("#flex-Resource").flexigrid ({  // Complete
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Resource', name : 'resource_id', width : 360, sortable : false, align: 'left'},
				{display: 'Role', name : 'resource_role', width : 175, sortable : false, align: 'left'},
				{display: 'Hourly Rate', name : 'resource_rate', width : 175, sortable : false, align: 'right'},
				{display: 'Overtime Rate', name : 'resource_ot_rate', width : 175, sortable : false, align: 'right'},
				
				{display: 'Work Contour', name : 'work_mode', width : 360, sortable : true, align: 'left'},
				{display: 'Work Rate', name : 'work_rate', width : 175, sortable : true, align: 'center'},
				
				{display: 'Estimate Work', name : 'resource_hours', width : 175, sortable : true, align: 'right'},
				{display: 'Estimate Cost', name : 'resource_cost', width : 175, sortable : true, align: 'right'},
				{display: 'Work Progress', name : 'resource_earned_work', width : 175, sortable : false, align: 'right'},
				
				{display: 'Actual Work', name : 'resource_actual_hours', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Resource Cost', name : 'resource_actual_cost', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Regular Work', name : 'resource_actual_reg_hr', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Regular Cost', name : 'resource_actual_reg_cost', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Overtime Work', name : 'resource_actual_ot_hr', width : 175, sortable : false, align: 'right'},
				{display: 'Actual Overtime Cost', name : 'resource_actual_ot_cost', width : 175, sortable : false, align: 'right'}
				],
			sortname: "work_mode",
			sortorder: "asc",
			usepager: true,
			title: 'Task Resources Details',
			useRp: true,
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			singleSelect: false,
			appPage: "project-taskResource",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Complete'
		}); 
	}
	
	
	
	
	
	
	if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) { 
		$("#flex-tskResWork").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Resource', name : 'resource_id', width : 360, sortable : true, align: 'left'},
				{display: 'Start Date', name : 'res_actuals_startdate', width : 175, sortable : true, align: 'center'},
				{display: 'End Date', name : 'res_actuals_enddate', width : 175, sortable : true, align: 'center'},
				{display: 'Description', name : 'resorce_actual_desc', width : 360, sortable : true, align: 'left'},
				{display: 'Billable', name : 'billable', width : 120, sortable : true, align: 'left'},
				{display: 'Work Hours', name : 'resource_actual_hours', width : 120, sortable : true, align: 'right'},
				{display: 'Regular Hours', name : 'resource_actual_reg_hr', width : 120, sortable : true, align: 'right'},
				{display: 'Overtime Hours', name : 'resource_actual_ot_hr', width : 120, sortable : true, align: 'right'},
				{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
				{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
				],
			searchitems : [
				{display: 'Description', name : 'resorce_actual_desc', isdefault: true},
				{display: 'Updated by', name : 'updated_by'}
				], 
			sortname: "res_actuals_enddate",
			sortorder: "desc",
			usepager: true,
			title: 'Resources Actual Work',
			useRp: true,
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			
			singleSelect: false,
			appPage: "project-taskActResWork-woCost",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+user_profile
		}); 
	} else {
		if ((user_profile == 'portfolio') || (user_profile == 'project')) {		
			$("#flex-tskResWork").flexigrid ({
				url: 'phpFlexLoader.php', // Adjust ----
				dataType: 'json',
				colModel : [
					{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
					{display: 'Resource', name : 'resource_id', width : 360, sortable : true, align: 'left'},
					{display: 'Start Date', name : 'res_actuals_startdate', width : 175, sortable : true, align: 'center'},
					{display: 'End Date', name : 'res_actuals_enddate', width : 175, sortable : true, align: 'center'},
					{display: 'Description', name : 'resorce_actual_desc', width : 360, sortable : true, align: 'left'},
					{display: 'Billable', name : 'billable', width : 120, sortable : true, align: 'left'},
					{display: 'Work Hours', name : 'resource_actual_hours', width : 120, sortable : true, align: 'right'},
					{display: 'Resource Cost', name : 'resource_actual_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Regular Hours', name : 'resource_actual_reg_hr', width : 120, sortable : true, align: 'right'},
					{display: 'Regular Cost', name : 'resource_actual_reg_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Overtime Hours', name : 'resource_actual_ot_hr', width : 120, sortable : true, align: 'right'},
					{display: 'Overtime Cost', name : 'resource_actual_ot_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
					{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
					],
				searchitems : [
					{display: 'Description', name : 'resorce_actual_desc', isdefault: true},
					{display: 'Updated by', name : 'updated_by'}
					], 
				sortname: "res_actuals_enddate",
				sortorder: "desc",
				usepager: true,
				title: 'Resources Actual Work',
				useRp: true,
				rp: 10,
				showTableToggleBtn: false,
				
				height: 200,
				
				singleSelect: false,
				appPage: "project-taskActResWork",
				fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+user_profile
			}); 
		} else {
			$("#flex-tskResWork").flexigrid ({
				url: 'phpFlexLoader.php', // Adjust ----
				dataType: 'json',
				colModel : [
					{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
					{display: 'Resource', name : 'resource_id', width : 360, sortable : true, align: 'left'},
					{display: 'Start Date', name : 'res_actuals_startdate', width : 175, sortable : true, align: 'center'},
					{display: 'End Date', name : 'res_actuals_enddate', width : 175, sortable : true, align: 'center'},
					{display: 'Description', name : 'resorce_actual_desc', width : 360, sortable : true, align: 'left'},
					{display: 'Work Hours', name : 'resource_actual_hours', width : 120, sortable : true, align: 'right'},
					{display: 'Resource Cost', name : 'resource_actual_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Regular Hours', name : 'resource_actual_reg_hr', width : 120, sortable : true, align: 'right'},
					{display: 'Regular Cost', name : 'resource_actual_reg_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Overtime Hours', name : 'resource_actual_ot_hr', width : 120, sortable : true, align: 'right'},
					{display: 'Overtime Cost', name : 'resource_actual_ot_cost', width : 120, sortable : true, align: 'right'},
					{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
					{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
					],
				searchitems : [
					{display: 'Description', name : 'resorce_actual_desc', isdefault: true},
					{display: 'Updated by', name : 'updated_by'}
					], 
				sortname: "res_actuals_enddate",
				sortorder: "desc",
				usepager: true,
				title: 'Resources Actual Work',
				useRp: true,
				rp: 10,
				showTableToggleBtn: false,
				
				height: 200,
				
				singleSelect: false,
				appPage: "project-taskActResWork",
				fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+user_profile
			}); 
		}
	}
	
	$('#gnt-currency').val(currency);
	// Grid for fixed costs
	$("#flex-fixCost").flexigrid ({ // Sharing with EDIT flex functions
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		searchitems : [
			{display: 'Description', name : 'fc_description', isdefault: true}
			], 
		sortname: "fc_description",
		sortorder: "asc",
		usepager: true,
		title: 'Task Estimated Fixed Cost',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		singleSelect: false,
		appPage: "project-taskfc",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	
	// Grid for Task Actual Fixed Costs -- to be hidden if Stakeholder and HideActual is TRUE
	$("#flex-tskfixCost").flexigrid ({ // Sharing with UPDATE flex functions
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Date', name : 'fc_date', width : 175, sortable : true, align: 'center'},
			{display: 'Invoice No.', name : 'fc_invoice_no', width : 175, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		searchitems : [
			{display: 'Invoice No.', name : 'fc_invoice_no', isdefault: true},
			{display: 'Amount', name : 'fc_amount'},
			{display: 'Description', name : 'fc_description'},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "fc_date",
		sortorder: "desc",
		usepager: true,
		title: 'Task Actual Fixed Cost',
		useRp: true,
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		singleSelect: false,
		appPage: "project-taskFixCost",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	

	$("#flex-tsk-documents").flexigrid ({   // Sharing with UPLOAD flex functions
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
			{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Download', bclass: 'download', onpress : taskDocsLists},
			{name: 'View', bclass: 'view flx-prjDocsTsk-vwe', onpress : taskDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Task Deliverables',
		useRp: false,
		onDoubleClick: '.flx-prjDocsTsk-vwe',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskdelivs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	// Grid for Task Fixed Costs
	$("#flex-tskReviews").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Start Date', name : 'review_start_date', width : 175, sortable : true, align: 'center'},
			{display: 'End Date', name : 'review_end_date', width : 175, sortable : true, align: 'center'},
			{display: 'Title', name : 'review_title', width : 360, sortable : true, align: 'left'},
			{display: 'Duration (Hours)', name : 'review_duration', width : 175, sortable : true, align: 'right'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'View', bclass: 'view flx-prjRvwsTsk-vwe', onpress : taskReviews},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'review_title', isdefault: true},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "review_end_date",
		sortorder: "desc",
		usepager: true,
		title: 'Task Review Meetings',
		useRp: true,
		onDoubleClick: '.flx-prjRvwsTsk-vwe',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskReviews",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	$("#flex-tsk-participants").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 100, sortable : false, align: 'left', hide: true},
			{display: 'Participant Name', name : 'participant_name', width : 360, sortable : true, align: 'left'},
			{display: 'Participant Email', name : 'participant_email', width : 360, sortable : true, align: 'left'},
			{display: 'Participant Category', name : 'participant_type', width : 230, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'View', bclass: 'view flx-prjMomsPartt-vwe', onpress : MeetingParticipants},
			{separator: true}
			],
		searchitems : [
			{display: 'Participant Name', name : 'participant_name', isdefault: true},
			{display: 'Participant Email', name : 'participant_email'},
			{display: 'Participant Category', name : 'participant_type'},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "participant_type",
		sortorder: "asc",
		usepager: true,
		title: 'Meeting Participants',
		useRp: true,
		onDoubleClick: '.flx-prjMomsPartt-vwe',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-Meeting-Participants",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	$("#flex-tsk-minutes").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'File Name', name : 'id', width : 290, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Download', bclass: 'download', onpress : MOMDocsLists},
			{name: 'View', bclass: 'view flx-prjMomsTsk-vwe', onpress : MOMDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Minutes of Meeting',
		useRp: false,
		onDoubleClick: '.flx-prjMomsTsk-vwe',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		appPage: "project-taskMoMs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	
	$("#flex-tsk-progressReports").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'File Name', name : 'id', width : 290, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Download', bclass: 'download', onpress : ReportsDocsLists},
			{name: 'Create', bclass: 'generate', onpress : ReportsDocsLists},
			{name: 'View', bclass: 'view flx-prjRpsTsk-vwe', onpress : ReportsDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Progress Reports',
		useRp: false,
		onDoubleClick: '.flx-prjRpsTsk-vwe',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskRps",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	//alert('Project Status: '+prjStatus);
	if (prjStatus < 2) {
		if (parseFloat(NodeInfo["progress"]) <= 0) {
			$("#flex-tsk-CR").removeClass("flex-side-left").addClass("flex-center");
		}
		$("#flex-tsk-crs").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
				{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
				{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment', onpress : CRLists},
				{name: 'View', bclass: 'view', onpress : CRLists},
				{name: 'Add', bclass: 'add', onpress : CRLists},
				{name: 'Edit', bclass: 'edit flx-prjCRsprj-edit', onpress : CRLists},
				{name: 'History', bclass: 'history', onpress : CRLists},
				{name: 'Delete', bclass: 'delete', onpress : CRLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'cr_title', isdefault: true},
				{display: 'Ticket ID', name : 'cr_id'},
				{display: 'Requested by', name : 'requested_by'}
				], 
			sortname: "requested_on",
			sortorder: "desc",
			usepager: true,
			title: 'Change Requests',
			useRp: true,
			onDoubleClick: '.flx-prjCRsprj-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-projectCRs",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
		}); 
		
		
		if (parseFloat(NodeInfo["progress"]) > 0) {
			$("#no-progress-bugs").css("display", "block");
			$("#flex-tsk-CR").removeClass("flex-center").addClass("flex-side-left");
			
			$("#flex-tsk-bugs").flexigrid ({
				url: 'phpFlexLoader.php', // Adjust ----
				dataType: 'json',
				colModel : [
					{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
					{display: 'Title', name : 'bd_title', width : 360, sortable : true, align: 'left'},
					{display: 'Status', name : 'bd_status', width : 175, sortable : true, align: 'left'},
					{display: 'Priority', name : 'bd_priority', width : 175, sortable : true, align: 'left'},
					{display: 'Reported by', name : 'reported_by', width : 360, sortable : true, align: 'left'},
					{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
					{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
					{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
					{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
					],
				buttons : [
					{name: 'Comment', bclass: 'comment', onpress : BDLists},
					{name: 'View', bclass: 'view', onpress : BDLists},
					{name: 'Add', bclass: 'add', onpress : BDLists},
					{name: 'Edit', bclass: 'edit flx-prjBDsprj-edit', onpress : BDLists},
					{name: 'History', bclass: 'history', onpress : BDLists},
					{name: 'Delete', bclass: 'delete', onpress : BDLists},
					{separator: true}
					],
				searchitems : [
					{display: 'Title', name : 'bd_title', isdefault: true},
					{display: 'Ticket ID', name : 'bd_id'},
					{display: 'Reported by', name : 'reported_by'}
					], 
				sortname: "reported_on",
				sortorder: "desc",
				usepager: true,
				title: 'Bugs / Defects',
				useRp: true,
				onDoubleClick: '.flx-prjBDsprj-edit',
				rp: 10,
				showTableToggleBtn: false,
				
				height: 201,
				singleSelect: true,
				appPage: "project-projectBDs",
				fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
			}); 
		
		}

		$("#flex-tsk-issues").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
				{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
				{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
				{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment', onpress : IssueLogLists},
				{name: 'Add', bclass: 'add', onpress : IssueLogLists},
				{name: 'Edit', bclass: 'edit flx-prjIsueprj-edit', onpress : IssueLogLists},
				{name: 'History', bclass: 'history', onpress : IssueLogLists},
				{name: 'Delete', bclass: 'delete', onpress : IssueLogLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'issue_title', isdefault: true},
				{display: 'Ticket ID', name : 'issue_id'},
				{display: 'Reported by', name : 'raised_by'}
				], 
			sortname: "reported_on",
			sortorder: "desc",
			usepager: true,
			title: 'Issue Log',
			useRp: true,
			onDoubleClick: '.flx-prjIsueprj-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-taskIssues",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
		}); 
		
		$("#flex-tsk-risks").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'risk_title', width : 360, sortable : true, align: 'left'},
				{display: 'Category', name : 'risk_category', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'risk_status', width : 175, sortable : true, align: 'left'},
				{display: 'Impact', name : 'risk_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Identified by', name : 'identified_by', width : 360, sortable : true, align: 'left'},
				{display: 'Registered on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment', onpress : RiskRegisterLists},
				{name: 'Add', bclass: 'add', onpress : RiskRegisterLists},
				{name: 'Edit', bclass: 'edit flx-prjRiskprj-edit', onpress : RiskRegisterLists},
				{name: 'History', bclass: 'history', onpress : RiskRegisterLists},
				{name: 'Delete', bclass: 'delete', onpress : RiskRegisterLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'risk_title', isdefault: true},
				{display: 'Ticket ID', name : 'risk_id'},
				{display: 'Identified by', name : 'identified_by'}
				], 
			sortname: "reported_on",
			sortorder: "desc",
			usepager: true,
			title: 'Risk Register',
			useRp: true,
			onDoubleClick: '.flx-prjRiskprj-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-projectRisks",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'
		}); 
	} else { // other status
		$("#flex-tsk-crs").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
				{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
				{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment flx-prjCRsCmt-cmt', onpress : CRLists},
				{name: 'View', bclass: 'view', onpress : CRLists},
				{name: 'History', bclass: 'history', onpress : CRLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'cr_title', isdefault: true},
				{display: 'Ticket ID', name : 'cr_id'},
				{display: 'Requested by', name : 'requested_by'}
				], 
			sortname: "requested_on",
			sortorder: "desc",
			usepager: true,
			title: 'Change Requests',
			useRp: true,
			onDoubleClick: '.flx-prjCRsCmt-cmt',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-projectCRs",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
		}); 
		
		
		
		if (parseFloat(NodeInfo["progress"]) > 0) {
			$("#no-progress-bugs").css("display", "block");
		
			$("#flex-tsk-bugs").flexigrid ({
				url: 'phpFlexLoader.php', // Adjust ----
				dataType: 'json',
				colModel : [
					{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
					{display: 'Title', name : 'bd_title', width : 360, sortable : true, align: 'left'},
					{display: 'Status', name : 'bd_status', width : 175, sortable : true, align: 'left'},
					{display: 'Priority', name : 'bd_priority', width : 175, sortable : true, align: 'left'},
					{display: 'Reported by', name : 'reported_by', width : 360, sortable : true, align: 'left'},
					{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
					{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
					{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
					{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
					],
				buttons : [
					{name: 'Comment', bclass: 'comment flx-prjBDsCmt-cmt', onpress : BDLists},
					{name: 'View', bclass: 'view', onpress : BDLists},
					{name: 'History', bclass: 'history', onpress : BDLists},
					{separator: true}
					],
				searchitems : [
					{display: 'Title', name : 'bd_title', isdefault: true},
					{display: 'Ticket ID', name : 'bd_id'},
					{display: 'Reported by', name : 'reported_by'}
					], 
				sortname: "reported_on",
				sortorder: "desc",
				usepager: true,
				title: 'Bugs / Defects',
				useRp: true,
				onDoubleClick: '.flx-prjBDsCmt-cmt',
				rp: 10,
				showTableToggleBtn: false,
				
				height: 201,
				singleSelect: true,
				appPage: "project-projectBDs",
				fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
			}); 
		
		}

		$("#flex-tsk-issues").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
				{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
				{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
				{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment flx-prjIssuCmt-cmt', onpress : IssueLogLists},
				{name: 'History', bclass: 'history', onpress : IssueLogLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'issue_title', isdefault: true},
				{display: 'Ticket ID', name : 'issue_id'},
				{display: 'Reported by', name : 'raised_by'}
				], 
			sortname: "reported_on",
			sortorder: "desc",
			usepager: true,
			title: 'Issue Log',
			useRp: true,
			onDoubleClick: '.flx-prjIssuCmt-cmt',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-taskIssues",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'+','+user_profile
		}); 
		
		$("#flex-tsk-risks").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
				{display: 'Title', name : 'risk_title', width : 360, sortable : true, align: 'left'},
				{display: 'Category', name : 'risk_category', width : 360, sortable : true, align: 'left'},
				{display: 'Status', name : 'risk_status', width : 175, sortable : true, align: 'left'},
				{display: 'Impact', name : 'risk_priority', width : 175, sortable : true, align: 'left'},
				{display: 'Identified by', name : 'identified_by', width : 360, sortable : true, align: 'left'},
				{display: 'Registered on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
				{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
				{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
				],
			buttons : [
				{name: 'Comment', bclass: 'comment flx-prjRiskCmt-cmt', onpress : RiskRegisterLists},
				{name: 'History', bclass: 'history', onpress : RiskRegisterLists},
				{separator: true}
				],
			searchitems : [
				{display: 'Title', name : 'risk_title', isdefault: true},
				{display: 'Ticket ID', name : 'risk_id'},
				{display: 'Identified by', name : 'identified_by'}
				], 
			sortname: "reported_on",
			sortorder: "desc",
			usepager: true,
			title: 'Risk Register',
			useRp: true,
			onDoubleClick: '.flx-prjRiskCmt-cmt',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 201,
			singleSelect: true,
			appPage: "project-projectRisks",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'View'
		}); 
	}
}




/*------------- END OF Project Task View Actions --------------     */

/*------------- Project Task Update Actions --------------     */
function TaskUpdator(node_ID) {
	$("html, body").animate({ scrollTop: 0 }, "slow");
	hide_message_box("gntFl-message-box");
	var tTask = '(Task: ';
	if (prjAgility == 1) tTask = '(ID: ';
	$.popgFLfrm._show();
	taskWork = 0;
	taskEarnedWork = 0;
	taskResWork = 0;
	taskResEarnedWork = 0;
	selNodeID = node_ID;
	var NodeInfo = getNodeInfo(node_ID);
	$('#gntTaskName-show').val(tTask +getOrigLink(node_ID)+') '+getNodeName(node_ID));
	
	if ((parseInt(NodeInfo["update_allow"]) == 0) || (parseInt(NodeInfo["story-active"]) > 0)) {
		$("#UpdtPermit-1, #gFform_sav").css("display", "none");
		
	} else {
		$("#UpdtPermit-0").css("display", "none");
	}
	
	var prStDte = '';
	var pUpdtDat = NodeInfo["startdate"]; 
	var TodayDate = '';
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) {
		prStDte = tranformDate(prjStartDt);
		pUpdateDate = tranformDate(pUpdtDat);
		TodayDate = TodayInBrit();
	} else {
		prStDte = prjStartDt;
		pUpdateDate = pUpdtDat;
		TodayDate = TodayInUs();
	}	
	
	$('#tskProgres-last-date').val(pUpdateDate);
	
	$('#tskProgres-res-date').datepick({ 
		renderer: $.extend({}, $.datepick.defaultRenderer, 
				{picker: $.datepick.defaultRenderer.picker.replace(/\{link:clear\}/, '')}),
		dateFormat: prjDtIn,
		minDate: prStDte,
		maxDate: TodayDate,
		showOnFocus: false,
		showOtherMonths: true, 
		selectOtherMonths: true,
		customWeekends: weekEnds.toString(),
		showTrigger: '#calImg-RPrgDate'}).datepick('option', {defaultDate: pUpdateDate}).val(pUpdateDate).datepick('disable').addClass('disabled_fld');		
	help_tab_id = 11;
	$(".taskmenu > li").click(function(e){
		
		switch(e.target.id){ 
			case "tab_upd_progress": 
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 11;
				$("#tab_upd_progress").addClass("active");
				$("#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_documents,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#content_tskProgress").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_work":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 12;
				$("#tab_upd_work").addClass("active");
				$("#tab_upd_progress,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_documents,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#content_tskWork").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskProgress,#content_tskCost,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break;
			case "tab_upd_cost":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 13;
				$("#tab_upd_cost").addClass("active");
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_meetings,#tab_upd_reports,#tab_upd_documents,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#content_tskCost").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskMeetings,#content_tskReports,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_meetings":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 14;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_reports,#tab_upd_documents,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#tab_upd_meetings").addClass("active");
				$("#content_tskMeetings").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskReports,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_documents":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 15;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#tab_upd_documents").addClass("active");
				$("#content_tskDocuments").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskReports").css("display", "none");
			break; 
			case "tab_upd_reports":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 16;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_documents,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#tab_upd_reports").addClass("active");
				$("#content_tskReports").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReviews,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_reviews":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 17;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_documents,#tab_upd_corrective,#tab_upd_preventive").removeClass("active");
				$("#tab_upd_reviews").addClass("active");
				$("#content_tskReviews").fadeIn();
				$("#content_tskCorectiv,#content_tskPreventiv,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_corrective":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 18;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_reviews,#tab_upd_preventive,#tab_upd_documents").removeClass("active");
				$("#tab_upd_corrective").addClass("active");
				$("#content_tskCorectiv").fadeIn();
				$("#content_tskPreventiv,#content_tskReviews,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
			case "tab_upd_preventive":
				hide_all_errors();
				hide_upload_started();
				help_tab_id = 19;
				$("#tab_upd_progress,#tab_upd_work,#tab_upd_cost,#tab_upd_meetings,#tab_upd_reports,#tab_upd_reviews,#tab_upd_corrective,#tab_upd_documents").removeClass("active");
				$("#tab_upd_preventive").addClass("active");
				$("#content_tskPreventiv").fadeIn();
				$("#content_tskCorectiv,#content_tskReviews,#content_tskReports,#content_tskProgress,#content_tskWork,#content_tskCost,#content_tskMeetings,#content_tskDocuments").css("display", "none");
			break; 
		}
		return false;
	});
	
	$("#content_tskWork, #content_tskCost, #content_tskMeetings, #content_tskReports, #content_tskReviews, #content_tskDocuments").css("display", "none");
	//alert(NodeInfo["reviews"]);
	
	
	if ((parseInt(NodeInfo["reviews"]) == 1) && (parseInt(NodeInfo["update_allow"]) == 1)) $("#tab_upd_reviews").css("display", "block");
		else $("#tab_upd_reviews").css("display", "none");
	
	if (parseInt(NodeInfo["update_allow"]) == 0) $("#tab_upd_work, #tab_upd_cost").css("display", "none");
	
	
	
	switch (selNodeType) {
	
		case 'rMlTask': { 
			//$("#tab_upd_cost").trigger("click"); #tab_upd_progress, 
			$("#tab_upd_work, #tab_upd_meetings, #tab_upd_reports, #tab_upd_corrective").css("display","none");
			$("#gFform_sav").removeAttr("disabled");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'rgTask': {
			//$("#tab_upd_cost").trigger("click");
			$("#tab_upd_meetings, #tab_upd_reports, #tab_upd_corrective, #recur-task-noRisk").css("display","none");
			$("#gFform_sav").removeAttr("disabled");
			$("#flex-tsk-issuesLog").removeClass("flex-side-left").addClass("flex-center");
			break;
		}
		case 'root': {
			//$("#tab_upd_cost").trigger("click");
			$("#tab_upd_meetings, #tab_upd_reports").css("display","none");
			$("#gFform_sav").removeAttr("disabled");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'nTask': {
			//$("#tab_upd_cost").trigger("click");
			$("#tab_upd_meetings, #tab_upd_reports").css("display","none");
			$("#gFform_sav").removeAttr("disabled");
			$("#flex-tsk-issuesLog").removeClass("flex-center").addClass("flex-side-left");
			break;
		}
		case 'rtTask': { // recur child
			$("#tab_upd_corrective, #recur-task-noRisk").css("display","none");
			$("#gFform_sav").removeAttr("disabled");
			$("#flex-tsk-issuesLog").removeClass("flex-side-left").addClass("flex-center");
			break;
		}
	}


	if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
		$(".HideFinance, #tab_upd_reports").css("display", "none");
	} 

	
	
	tskProgress_bar = new JustGage({
		id: "tskProgress-bar", 
        value: 0, 
        min: 0,
        max: 100,
		gaugeColor: "#EBECE7", 
        title: "Task Progress",
		titleFontColor: "#9AA08D",  
        levelColors: ["#C1D693"],
        showMinMax: false, 
		valueFontColor: "#717171",
		gaugeWidthScale: 1.5, 
        label: "%", 
		labelFontColor: "#717171"  
	});
	
	/* setInterval(function() {
		tskProgress_bar.refresh(getRandomInt(0, 100));
	}, 2500);
	*/
	//$("#UpdateTask").css("display","none");
	
	show_upload_started();
	//$("#gnt-meeting-dur").spinner({min: 0, stepping: 0.25});
	$.ajax({
		url: "phpPopulate.php",
		type: 'POST',
		data: {"page": "gantt-task-progress", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			//alert(response);
			response = $.parseJSON(response);
			hide_all_errors();
			hide_upload_started();
			taskWork = parseFloat(response[0]["work"]);
			taskEarnedWork = parseFloat(response[0]["earnedwork"]);
			if (taskWork > 0) {
				taskProgress = parseInt(taskEarnedWork / taskWork * 100);
			} else {
					taskProgress = 0;
					//$("#tab_upd_work").trigger("click");
					$("#tskProgres-res-show").css("display","none");
					$("#gFform_sav").attr("disabled", "disabled");
				}	
			tskProgress_bar.refresh(taskProgress);
			if (parseInt(response[0]["meetings"]) == 0) $("#tab_upd_meetings").css("display","none");
			if (parseInt(response[0]["reports"]) == 0) $("#tab_upd_reports").css("display","none");
				else if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) $("#tab_upd_reports").css("display", "none");
					
			
			if (parseInt(response[0]["mom_circulate"]) == 0) $("#gnt-mom-sent").val("Not Circulated");
				else $("#gnt-mom-sent").val("Circulated: "+ response[0]["mom_circulate"] +" time(s)");
				
			if (parseInt(response[0]["report_circulate"]) == 0) $("#gnt-reports-sent").val("Not Circulated");
				else $("#gnt-reports-sent").val("Circulated: "+ response[0]["report_circulate"] +" time(s)");
				
				
			
			
		}
	});	

	
	$("#tskProgres-show, #tskProgres-res").spinner({min: 0, max: 100, stepping: 0.25});
	$("#tskProgres-show").spinner( "disable" ); // chech this whether needed
	
	
	$('#gntOnBhf-Res').addClass('populate_loading');
	$.ajax({
		url: "phpPopulate.php",
		type: 'POST',
		data: {"page": "gantt-task-resources", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID},
		timeout: xhr_timeout,
		error: function () {
			hide_all_errors();
			hide_upload_started();
			jAlert('Could not connect to server...','T');
		},
		success: function(response) {
			response = $.parseJSON(response);
			hide_all_errors();
			hide_upload_started();
			$('#gntOnBhf-Res').removeClass('populate_loading');
			$('#gntOnBhf-Res').append('<option selected="selected" value="0" disabled="disabled">&#45;&#45; select one &#45;&#45;</option>');
			if (response.length > 0) {
				for(i = 0; i< response.length; i++) {
					$('#gntOnBhf-Res').append('<option value='+ response[i]["value"] +'>' + response[i]["descr"] + '</option>');
				};
			};
		}
	});	

	$("#tskProgres-res").spinner( "disable" );
	$("#gFform_sav").attr("disabled", "disabled");
	// Grid for Resource Effort
	if ((user_profile == 'portfolio') || (user_profile == 'project')){
		$("#flex-tskResWork").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Start Date', name : 'res_actuals_startdate', width : 175, sortable : true, align: 'center'},
				{display: 'End Date', name : 'res_actuals_enddate', width : 175, sortable : true, align: 'center'},
				{display: 'Work Hours', name : 'resource_actual_hours', width : 120, sortable : true, align: 'right'},
				{display: 'Billable', name : 'billable', width : 120, sortable : true, align: 'left'},
				{display: 'Description', name : 'resorce_actual_desc', width : 360, sortable : true, align: 'left'},
				{display: 'Performed by', name : 'performed_resorce_id', width : 360, sortable : true, align: 'left'},
				{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
				{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
				],
			buttons : [
				{name: 'Add', bclass: 'add', onpress : taskResourceWork}, 
				{name: 'Edit', bclass: 'edit flx-prjTaskResWk-edt', onpress : taskResourceWork},
				{name: 'Delete', bclass: 'delete', onpress : taskResourceWork},
				{separator: true}
				],
			searchitems : [
				{display: 'Description', name : 'resorce_actual_desc', isdefault: true},
				{display: 'Updated by', name : 'updated_by'}
				], 
			sortname: "res_actuals_enddate",
			sortorder: "desc",
			usepager: true,
			title: 'Resource Work Hours',
			useRp: true,
			onDoubleClick: '.flx-prjTaskResWk-edt',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			
			singleSelect: true,
			appPage: "project-taskResWork",
			fldSelect: "tskresWrk"
		}); 
	} else {
		$("#flex-tskResWork").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
				{display: 'Start Date', name : 'res_actuals_startdate', width : 175, sortable : true, align: 'center'},
				{display: 'End Date', name : 'res_actuals_enddate', width : 175, sortable : true, align: 'center'},
				{display: 'Work Hours', name : 'resource_actual_hours', width : 120, sortable : true, align: 'right'},
				{display: 'Description', name : 'resorce_actual_desc', width : 360, sortable : true, align: 'left'},
				{display: 'Performed by', name : 'performed_resorce_id', width : 360, sortable : true, align: 'left'},
				{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
				{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
				],
			buttons : [
				{name: 'Add', bclass: 'add', onpress : taskResourceWork}, 
				{name: 'Edit', bclass: 'edit flx-prjTaskResWk-edit', onpress : taskResourceWork},
				{name: 'Delete', bclass: 'delete', onpress : taskResourceWork},
				{separator: true}
				],
			searchitems : [
				{display: 'Description', name : 'resorce_actual_desc', isdefault: true},
				{display: 'Updated by', name : 'updated_by'}
				], 
			sortname: "res_actuals_enddate",
			sortorder: "desc",
			usepager: true,
			title: 'Resource Work Hours',
			useRp: true,
			onDoubleClick: '.flx-prjTaskResWk-edit',
			rp: 10,
			showTableToggleBtn: false,
			
			height: 200,
			
			singleSelect: true,
			appPage: "project-taskResWork",
			fldSelect: "tskresWrk"
		}); 
	}
	
	// Grid for Task Fixed Costs
	$("#flex-tskfixCost").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Date', name : 'fc_date', width : 175, sortable : true, align: 'center'},
			{display: 'Invoice No.', name : 'fc_invoice_no', width : 175, sortable : true, align: 'left'},
			{display: 'Amount', name : 'fc_amount', width : 175, sortable : true, align: 'right'},
			{display: 'Description', name : 'fc_description', width : 360, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'},
			{display: 'Task', name : 'task_id', width : 360, sortable : false, align: 'left'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskFixedCost}, 
			{name: 'Edit', bclass: 'edit flx-prjTaskFC-edit', onpress : taskFixedCost},
			{name: 'Delete', bclass: 'delete', onpress : taskFixedCost},
			{separator: true}
			],
		searchitems : [
			{display: 'Date', name : 'fc_date', isdefault: true},
			{display: 'Invoice No.', name : 'fc_invoice_no'},
			{display: 'Amount', name : 'fc_amount'},
			{display: 'Description', name : 'fc_description'},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "fc_date",
		sortorder: "desc",
		usepager: true,
		title: 'Task Fixed Cost',
		useRp: true,
		onDoubleClick: '.flx-prjTaskFC-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskFixCost",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	if (user_previlege == 0) {
		$("#flex-tsk-documents").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
				{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
				{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
				{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
				{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
				],
			buttons : [
				{name: 'Upload', bclass: 'upload', onpress : taskDocsLists},
				{name: 'Delete', bclass: 'delete', onpress : taskDocsLists},
				{name: 'Download', bclass: 'download', onpress : taskDocsLists},
				{name: 'View', bclass: 'view flx-prjTaskDeli-viwe', onpress : taskDocsLists},
				{separator: true}
				],
			sortname: "node_name",
			sortorder: "asc",
			usepager: true,
			title: 'Task Deliverables',
			useRp: false,
			onDoubleClick: '.flx-prjTaskDeli-viwe',
			//rp: 100,
			showTableToggleBtn: false,
			
			height: 201,
			
			appPage: "project-taskdelivs",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID
		}); 
	} else {
		$("#flex-tsk-documents").flexigrid ({
			url: 'phpFlexLoader.php', // Adjust ----
			dataType: 'json',
			colModel : [
				{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
				{display: 'Task Name', name : 'node_name', width : 360, sortable : false, align: 'left'},
				{display: 'File Name', name : 'id', width : 360, sortable : false, align: 'left'},
				{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
				{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
				],
			buttons : [
				{name: 'Upload', bclass: 'upload', onpress : taskDocsLists},
				{name: 'Download', bclass: 'download', onpress : taskDocsLists},
				{name: 'View', bclass: 'view flx-prjTaskDeli-vwe', onpress : taskDocsLists},
				{separator: true}
				],
			sortname: "node_name",
			sortorder: "asc",
			usepager: true,
			title: 'Task Deliverables',
			useRp: false,
			onDoubleClick: '.flx-prjTaskDeli-vwe',
			//rp: 100,
			showTableToggleBtn: false,
			
			height: 201,
			
			appPage: "project-taskdelivs",
			fldSelect: $('#gantt-select-devp').val()+','+node_ID
		}); 
	}

// Grid for Task Reviews
	$("#flex-tskReviews").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 120, sortable : false, align: 'left', hide: true},
			{display: 'Start Date', name : 'review_start_date', width : 175, sortable : true, align: 'center'},
			{display: 'End Date', name : 'review_end_date', width : 175, sortable : true, align: 'center'},
			{display: 'Title', name : 'review_title', width : 360, sortable : true, align: 'left'},
			{display: 'Duration (Hours)', name : 'review_duration', width : 175, sortable : true, align: 'right'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : taskReviews}, 
			{name: 'Edit', bclass: 'edit flx-prjTaskRvw-edit', onpress : taskReviews},
			{name: 'Delete', bclass: 'delete', onpress : taskReviews},
			{name: 'Email', bclass: 'email', onpress : taskReviews},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'review_title', isdefault: true},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "review_end_date",
		sortorder: "desc",
		usepager: true,
		title: 'Task Review Meetings',
		useRp: true,
		onDoubleClick: '.flx-prjTaskRvw-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 200,
		
		singleSelect: true,
		appPage: "project-taskReviews",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 

	$("#flex-tsk-participants").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 100, sortable : false, align: 'left', hide: true},
			{display: 'Participant Name', name : 'participant_name', width : 360, sortable : true, align: 'left'},
			{display: 'Participant Email', name : 'participant_email', width : 360, sortable : true, align: 'left'},
			{display: 'Participant Category', name : 'participant_type', width : 230, sortable : true, align: 'left'},
			{display: 'Updated by', name : 'updated_by', width : 360, sortable : true, align: 'left'},
			{display: 'Updated on', name : 'cr_date ', width : 175, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Add', bclass: 'add', onpress : MeetingParticipants}, 
			{name: 'Edit', bclass: 'edit flx-prjMeetPart-edit', onpress : MeetingParticipants},
			{name: 'Delete', bclass: 'delete', onpress : MeetingParticipants},
			{separator: true}
			],
		searchitems : [
			{display: 'Participant Name', name : 'participant_name', isdefault: true},
			{display: 'Participant Email', name : 'participant_email'},
			{display: 'Participant Category', name : 'participant_type'},
			{display: 'Updated by', name : 'updated_by'}
			], 
		sortname: "participant_type",
		sortorder: "asc",
		usepager: true,
		title: 'Meeting Participants',
		useRp: true,
		onDoubleClick: '.flx-prjMeetPart-edit',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-Meeting-Participants",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 


	$("#flex-tsk-minutes").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'File Name', name : 'id', width : 290, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Upload', bclass: 'upload', onpress : MOMDocsLists},
			{name: 'Delete', bclass: 'delete', onpress : MOMDocsLists},
			{name: 'Download', bclass: 'download', onpress : MOMDocsLists},
			{name: 'View', bclass: 'view flx-prjTskMoms-view', onpress : MOMDocsLists},
			{name: 'Circulate', bclass: 'email', onpress : MOMDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Minutes of Meeting',
		useRp: false,
		onDoubleClick: '.flx-prjTskMoms-view',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		appPage: "project-taskMoMs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 


	$("#flex-tsk-progressReports").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'ID', name : 'id', width : 360, sortable : false, align: 'left', hide: true},
			{display: 'File Name', name : 'id', width : 290, sortable : false, align: 'left'},
			{display: 'Size', name : 'fsize', width : 230, sortable : false, align: 'right'},
			{display: 'Upload Date', name : 'fdate', width : 230, sortable : false, align: 'center'}
			],
		buttons : [
			{name: 'Upload', bclass: 'upload', onpress : ReportsDocsLists},
			{name: 'Delete', bclass: 'delete', onpress : ReportsDocsLists},
			{name: 'Download', bclass: 'download', onpress : ReportsDocsLists},
			{name: 'Generate', bclass: 'generate', onpress : ReportsDocsLists},
			{name: 'View', bclass: 'view flx-prjTskRps-view', onpress : ReportsDocsLists},
			{name: 'Circulate', bclass: 'email', onpress : ReportsDocsLists},
			{separator: true}
			],
		sortname: "node_name",
		sortorder: "asc",
		usepager: true,
		title: 'Progress Reports',
		useRp: false,
		onDoubleClick: '.flx-prjTskRps-view',
		//rp: 100,
		showTableToggleBtn: false,
		
		height: 201,
		
		appPage: "project-taskRps",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID
	}); 
	
	$("#flex-tsk-crs").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'cr_title', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'cr_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'cr_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Requested by', name : 'requested_by', width : 360, sortable : true, align: 'left'},
			{display: 'Requested on', name : 'requested_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [
			{name: 'Update', bclass: 'update', onpress : CRLists},
			{name: 'View', bclass: 'view', onpress : CRLists},
			{name: 'Comment', bclass: 'comment flx-prjPrjCRs-cmt', onpress : CRLists},
			{name: 'History', bclass: 'history', onpress : CRLists},
			{name: 'Purge', bclass: 'purge', onpress : CRLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'cr_title', isdefault: true},
			{display: 'Ticket ID', name : 'cr_id'},
			{display: 'Requested by', name : 'requested_by'}
			], 
		sortname: "requested_on",
		sortorder: "desc",
		usepager: true,
		title: 'Change Requests',
		useRp: true,
		onDoubleClick: '.flx-prjPrjCRs-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-projectCRs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 
	
	$("#flex-tsk-bugs").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'bd_title', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'bd_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'bd_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Reported by', name : 'reported_by', width : 360, sortable : true, align: 'left'},
			{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Documents', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [
			{name: 'Update', bclass: 'update', onpress : BDLists},
			{name: 'Comment', bclass: 'comment', onpress : BDLists},
			{name: 'View', bclass: 'view flx-prjPrjBDs-vwe', onpress : BDLists},
			{name: 'History', bclass: 'history', onpress : BDLists},
			{name: 'Purge', bclass: 'purge', onpress : BDLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'bd_title', isdefault: true},
			{display: 'Ticket ID', name : 'bd_id'},
			{display: 'Reported by', name : 'reported_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Bugs / Defects',
		useRp: true,
		onDoubleClick: '.flx-prjPrjBDs-vwe',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-projectBDs",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 
	
	$("#flex-tsk-issues").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'issue_title', width : 360, sortable : true, align: 'left'},
			{display: 'Category', name : 'issue_category', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'issue_status', width : 175, sortable : true, align: 'left'},
			{display: 'Priority', name : 'issue_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Reported by', name : 'raised_by', width : 360, sortable : true, align: 'left'},
			{display: 'Reported on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [
			{name: 'Update', bclass: 'update', onpress : IssueLogLists},
			{name: 'Comment', bclass: 'comment flx-prjTskIsu-cmt', onpress : IssueLogLists},
			{name: 'History', bclass: 'history', onpress : IssueLogLists},
			{name: 'Purge', bclass: 'purge', onpress : IssueLogLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'issue_title', isdefault: true},
			{display: 'Ticket ID', name : 'issue_id'},
			{display: 'Reported by', name : 'raised_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Issue Log',
		useRp: true,
		onDoubleClick: '.flx-prjTskIsu-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-taskIssues",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'+','+user_profile
	}); 
	
	
	$("#flex-tsk-risks").flexigrid ({
		url: 'phpFlexLoader.php', // Adjust ----
		dataType: 'json',
		colModel : [
			{display: 'Ticket ID', name : 'id', width : 100, sortable : false, align: 'center'},
			{display: 'Title', name : 'risk_title', width : 360, sortable : true, align: 'left'},
			{display: 'Category', name : 'risk_category', width : 360, sortable : true, align: 'left'},
			{display: 'Status', name : 'risk_status', width : 175, sortable : true, align: 'left'},
			{display: 'Impact', name : 'risk_priority', width : 175, sortable : true, align: 'left'},
			{display: 'Identified by', name : 'identified_by', width : 360, sortable : true, align: 'left'},
			{display: 'Registered on', name : 'reported_on ', width : 175, sortable : true, align: 'center'},
			{display: 'Risk Owner', name : 'risk_owner', width : 360, sortable : true, align: 'left'},
			{display: 'Comments', name : 'id', width : 100, sortable : false, align: 'right'},
			{display: 'Task', name : 'task_id', width : 360, sortable : true, align: 'left'}
			],
		buttons : [
			{name: 'Update', bclass: 'update', onpress : RiskRegisterLists},
			{name: 'Comment', bclass: 'comment flx-prjprjRisk-cmt', onpress : RiskRegisterLists},
			{name: 'History', bclass: 'history', onpress : RiskRegisterLists},
			{name: 'Purge', bclass: 'purge', onpress : RiskRegisterLists},
			{separator: true}
			],
		searchitems : [
			{display: 'Title', name : 'risk_title', isdefault: true},
			{display: 'Ticket ID', name : 'risk_id'},
			{display: 'Identified by', name : 'identified_by'}
			], 
		sortname: "reported_on",
		sortorder: "desc",
		usepager: true,
		title: 'Risk Register',
		useRp: true,
		onDoubleClick: '.flx-prjprjRisk-cmt',
		rp: 10,
		showTableToggleBtn: false,
		
		height: 201,
		singleSelect: true,
		appPage: "project-projectRisks",
		fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+'Update'
	}); 
		
	
	$('#gntOnBhf-Res').change(function(){
		hide_all_errors();
		
		jQuery('#flex-tskResWork').flexOptions({fldSelect: $('#gantt-select-devp').val()+','+node_ID+','+$('#gntOnBhf-Res').val()+','+user_profile});
		jQuery("#flex-tskResWork").flexReload();
		
		if (taskWork > 0) taskProgress = parseInt(taskEarnedWork / taskWork * 100);
			else taskProgress = 0;
		tskProgress_bar.refresh(taskProgress);
		show_upload_started();
		$.ajax({
			url: "phpPopulate.php",
			type: 'POST',
			data: {"page": "gantt-tskRes-progress", "project-id": $('#gantt-select-devp').val(), "node-id": node_ID, "res-id":$('#gntOnBhf-Res').val()},
			timeout: xhr_timeout,
			error: function () {
				hide_all_errors();
				hide_upload_started();
				jAlert('Could not connect to server...','T');
			},
			success: function(response) {
				//alert(response);
				response = $.parseJSON(response);
				hide_all_errors();
				hide_upload_started();
				//if (selNodeType != 'rMlTask') { // selNodeType 'rMlTask'
					taskResWork = parseFloat(response[0]["work"]);
					taskResEarnedWork = parseFloat(response[0]["earnedwork"]);
					taskResActWork = parseFloat(response[0]["actualwork"]);
					taskResPrgDte = response[0]["progress-date"];
					if (taskResPrgDte == '') taskResPrgDte = prStDte;
					
					if (taskResWork > 0) {
						taskResProgress = parseFloat(taskResEarnedWork / taskResWork * 100).toFixed(2);
						$("#tskProgres-res").spinner( "enable" );
						$('#tskProgres-res-date').datepick('option', {minDate: prjPrgsLmt}).datepick('option', {defaultDate: taskResPrgDte}).val(taskResPrgDte).datepick('enable').removeClass('disabled_fld');
						$("#gFform_sav").removeAttr("disabled");
					} else {
						taskResProgress = parseFloat(0).toFixed(2);
						$("#tskProgres-res").spinner( "disable" );  
						$('#tskProgres-res-date').datepick('option', {minDate: prjPrgsLmt}).datepick('option', {defaultDate: taskResPrgDte}).val(taskResPrgDte).datepick('disable').addClass('disabled_fld');
						$("#gFform_sav").attr("disabled", "disabled");
					}

					$('#tskProgres-last-date').val(taskResPrgDte);
					
					$('#tskProgres-res').val(taskResProgress);
					
					$("#tskProgres-res").on( "spinchange", function( event, ui ) { 
						var newResEarnedWork = taskResWork * parseFloat($("#tskProgres-res").val().replace(/[^0-9\-\.]/g, '')) / 100;
						var newtskEarnedWork = taskEarnedWork - taskResEarnedWork + newResEarnedWork;
						var taskTmpProgress = 0;
						if (taskWork > 0) taskTmpProgress = parseInt(newtskEarnedWork / taskWork * 100);
						tskProgress_bar.refresh(taskTmpProgress);
						$('#tskProgres-res-date').datepick('option', {defaultDate: ''}).val('');
						
					});
				
			}
		});	


	}); 
	
	
	
	
	

}



function submitTaskUpdate(node_ID){

//alert('Update Progress: '+node_ID);

/*	var NodeInfo = getNodeInfo(node_ID);
	var meeting_duration = -1;
	if (parseInt(NodeInfo['meetings']) > 0) meeting_duration = $('#gnt-meeting-dur').val().replace(/[^0-9\-\.]/g, '');
*/
	var NodeInfo = getNodeInfo(selNodeID);
	if (parseInt(NodeInfo["update_allow"]) == 0) {
		jAlert('No Permission to Update this Task...', 'E', function(){
			return false;
		});
	} else {
		show_upload_started();
		empty_message_box("gntFl-message-box");
		var ValidStatus = true;
		var MesgStrg = '';
		if ($("#tskProgres-res-date").val() == '') {	
			MesgStrg += '<p><i>Progress Date</i></p>' + '<p>&#9830; Progress Date is not entered</p>';
		}; 
		if (MesgStrg.length > 0) {
			ValidStatus = false;
			$("#gntFl-message-box").append(MesgStrg);
		};	
		if (ValidStatus == false) { // change
			show_message_box("gntFl-message-box");
			hide_upload_started();
			jAlert('Correct the errors indicated...','E', function(){
				return;
			});
		} else {
			$.ajax({
				url: "phpGanttService.php",
				type: 'POST',
				data: {"page": "task-updt-resource-progress", 
						"project-id": $('#gantt-select-devp').val(), 
						"node-id": node_ID, 
						"res-id": $('#gntOnBhf-Res').val(),
						"progress-val": $('#tskProgres-res').val().replace(/[^0-9\-\.]/g, ''),
						"progress-date": $("#tskProgres-res-date").val(),
						"user-id": user_id,
						"user-profile": user_profile,
						"user-sys-id": user_sys_id 
					},
				timeout: xhr_timeout,
				error: function () {
					hide_all_errors();
					hide_upload_started();
					jAlert('Could not connect to server...','T');
				},
				success: function(response) {
					hide_all_errors();
					hide_upload_started();
					response = $.parseJSON(response);
					if (response[0][0].status == "error") {
						hide_upload_started();
						hide_message_box("gntFl-message-box");
						jAlert(response[0][0].data['messg'],'E', function() {
								$.popgFLfrm._hide();
								loadProjectGantt('');
						});
					} else if (response[0][0].status == "success") {
						// --- check  and correct
						hide_upload_started();
						if (response[0][0].data[0]['node-id'] != '-1') {
							jAlert(response[0][0].data[0]['messg'],'S',function() {
								$.popgFLfrm._hide();
								loadProjectGantt('');
							});
						} else {
							jAlert(response[0][0].data[0]['messg'],'E');
						} 
					} else {
							jAlert(response[0][0].data[0]['messg'],'E');
					} 
					
					
					
					
				}
			});	
		}
	}



}


function taskResourceWork(com,grid) {
/*	var NodeInfo = getNodeInfo(selNodeID);
	if (parseInt(NodeInfo["update_allow"]) == 0) {
		jAlert('No Permission to Update this Task...', 'E', function(){
			return false;
		});
	} else { */
		if (com=='Delete') {
			if ($('.trSelected',grid).length>0) {
				jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
					if (user_act) {
						var items = $('.trSelected',grid);
						var itemlist =items[0].id.substr(3);
	 
						$.ajax({
							url: "phpGanttService.php",
							type: 'POST',
							data: {"page": 'gnt-task-actual-rw-delete',
								   "project-id": $('#gantt-select-devp').val(), 
								   "node-id": selNodeID,
								   "rwRec-id": itemlist, 
								   "res-id": $("#gntOnBhf-Res").val(),
								   "user-id": user_id
							},
							timeout: xhr_timeout,
							error: function () {
								hide_all_errors(); //
								hide_upload_started(); //
								jAlert('Could not connect to server...','T');
							},
							success: function(response) {
								//alert(response);
								response = $.parseJSON(response); 
								if (response[0][0].status == "error") {
									hide_upload_started();
									hide_message_box("gntSl-message-box");
									jAlert(response[0][0].data[0]['messg'],'E');
								} else if (response[0][0].status == "success") {
									hide_upload_started();
									if (response[0][0].data[0]['node-id'] != '-1') {
										jAlert(response[0][0].data[0]['messg'],'S',function() {
											jQuery("#flex-tskResWork").flexReload();
											loadProjectGantt('');
										});
									} else {
										jAlert(response[0][0].data[0]['messg'],'E');
									}  
								}
							}
						});			
					} else {
						return false;
					};
				}); 
			} else {
				jAlert('Record NOT selected !', 'E');
			};
		} else if (com=='Add') {
			tab_toggler = true;
			if (parseInt($('#gntOnBhf-Res').val()) == 0) {
				jAlert('Resource NOT selected !', 'E', function(){
					return false;
				});
			} else {
				/* jConfirm('Add Work Performed by Resource<b>?</b>', '', function(user_act) {
					if (user_act) { */
						jgSforms('GntactRWAdd', selNodeID,'Submit Resource Work...');
				/*	} else {
						return false;
					};
				}); */
			}
		} else if (com=='Edit') {
			tab_toggler = true;
			if (parseInt($('#gntOnBhf-Res').val()) == 0) {
				jAlert('Resource NOT selected !', 'E', function(){
					return false;
				});
			} else {
				if ($('.trSelected',grid).length>0) {
					/* jConfirm('Edit Work Performed by Resource<b>?</b>', '', function(user_act) {
						if (user_act) { */
							var items = $('.trSelected',grid);
							var itemlist =items[0].id.substr(3);
							jgSforms('GntactRWEdit', itemlist,'Edit Resource Work...');
					/*	} else {
							return false;
						};
					}); */
				} else {
					jAlert('Record NOT selected !', 'E');
				};
			}
		}
	//}	
}

function taskFixedCost(com,grid) {
	/* var NodeInfo = getNodeInfo(selNodeID);
	if (parseInt(NodeInfo["update_allow"]) == 0) {
		jAlert('No Permission to Update this Task...', 'E', function(){
			return false;
		});
	} else { */
		if (com=='Delete') {
			if ($('.trSelected',grid).length>0) {
				jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
					if (user_act) {
						var items = $('.trSelected',grid);
						var itemlist =items[0].id.substr(3);
	 
						$.ajax({
							url: "phpGanttService.php",
							type: 'POST',
							data: {"page": 'gnt-task-actual-fc-delete',
								   "project-id": $('#gantt-select-devp').val(), 
								   "node-id": selNodeID, 
								   "fc-uid": itemlist,
								   "user-id": user_id
							},
							timeout: xhr_timeout,
							error: function () {
								hide_all_errors(); //
								hide_upload_started(); //
								jAlert('Could not connect to server...','T');
							},
							success: function(response) {
								
								response = $.parseJSON(response); 
								if (response[0][0].status == "error") {
									hide_upload_started();
									hide_message_box("gntSl-message-box");
									jAlert(response[0][0].data[0]['messg'],'E', function() {
											$.popgSLfrm._hide();
									});
								} else if (response[0][0].status == "success") {
									hide_upload_started();
									if (response[0][0].data[0]['node-id'] != '-1') {
										jAlert(response[0][0].data[0]['messg'],'S',function() {
											$.popgSLfrm._hide();
											jQuery("#flex-tskfixCost").flexReload();
											loadProjectGantt('');
										});
									} else {
										jAlert(response[0][0].data[0]['messg'],'E');
									}  
								}
							}
						});			
					} else {
						return false;
					};
				}); 
			} else {
				jAlert('Record NOT selected !', 'E');
			};
		} else if (com=='Add') {
			tab_toggler = true;
			/* jConfirm('Add Fixed Cost incurred<b>?</b>', '', function(user_act) {
				if (user_act) { */
					jgSforms('GntactFCAdd', selNodeID,'Submit Incurred Fixed Cost...');
			/*	} else {
					return false;
				};
			}); */
		} else if (com=='Edit') {
			tab_toggler = true;
			if ($('.trSelected',grid).length>0) {
				/* jConfirm('Edit the Incurred Fixed Cost<b>?</b>', '', function(user_act) {
					if (user_act) { */
						var items = $('.trSelected',grid);
						var itemlist =items[0].id.substr(3);
						jgSforms('GntactFCEdit', itemlist,'Edit Incurred Fixed Cost...');
				/*	} else {
						return false;
					};
				}); */
			} else {
				jAlert('Record NOT selected !', 'E');
			};
		}
	//}
}




function taskDocsLists(com,grid) {
    if (com=='Delete') {

		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist ='';
					 for(i=0;i<items.length;i++){
						itemlist+= items[i].id.substr(3)+",";
					} 
					$.ajax({
					   type: "POST",
					   url: "phpFlexService.php",
					   data: {"page": "gnt-task-deliv-delete", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					   	timeout: xhr_timeout,
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						},
					   success: function(data){
						// alert(data);
						$("#flex-tsk-documents").flexReload();
					   }
					 }); 
				} else {
					return false;
				};
			});
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='Download') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			 
			zipDownloader("gnt-task-deliv-dwl", $('#gantt-select-devp').val(), itemlist); 
			 
		} else {
			jAlert('Files NOT selected !', 'E');
		};
    } else if (com=='Upload') {
        /* jConfirm('Upload new Delivarable<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntDelivUpload', selNodeID,'Upload Deliverable...');
		/*	} else {
				return false;
			};
		});  */
    } else if (com=='View') {
		if ($('.trSelected',grid).length>0) {  
			if ($('.trSelected',grid).length>1) { 
				jAlert('Too many documents selected! Select one...', 'E');	
			} else {
				var items = $('.trSelected',grid); // MA University of Kerala.pdf
				var itemlist ='';
				 for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3);
				} 
				//alert(itemlist);
				$.ajax({
				   type: "POST",
				   url: "phpFlexService.php",
				   data: {"page": "gnt-task-deliv-view", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					timeout: xhr_timeout,
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					},
				   success: function(data){
						response = $.parseJSON(data); 
						var FileName = response[0]["file-to-view"].replace(/ /g, '%20');
						var FileMIME = response[0]["file-mime-type"];
						if(FileMIME != '') {
							var myWindow = window.open("","_blank","fullscreen=yes, location=no, menubar=no, toolbar=no");
							myWindow.document.write('<object data='+ FileName +' type='+ FileMIME +' width="100%" height="100%"><p>Cannot open the document directly.  <a href='+ FileName +'>Click here to download the file...</a></p></object>');
						} else jAlert('Unable to open the document...', 'E');
				   }
				 }); 
			}; 
		
		} else {
			jAlert('Document NOT selected !', 'E');
		}; 
    }



	
}

function taskReviews(com,grid) {

	if (com=='View') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('View the Review Meeting<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskReviewView', itemlist,'View Review Meeting...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
	} else {
		var NodeInfo = getNodeInfo(selNodeID);
		if (parseInt(NodeInfo["update_allow"]) == 0) {
			jAlert('No Permission to Update this Task...', 'E', function(){
				return false;
			});
		} else {
			if (com=='Delete') {
				if ($('.trSelected',grid).length>0) {
					jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
						if (user_act) {
							var items = $('.trSelected',grid);
							var itemlist =items[0].id.substr(3);
		 
							$.ajax({
								url: "phpGanttService.php",
								type: 'POST',
								data: {"page": 'gnt-task-review-delete',
									   "project-id": $('#gantt-select-devp').val(), 
									   "node-id": selNodeID, 
									   "review-id": itemlist,
									   "user-id": user_id
								},
								timeout: xhr_timeout,
								error: function () {
									hide_all_errors(); //
									hide_upload_started(); //
									jAlert('Could not connect to server...','T');
								},
								success: function(response) {
									
									response = $.parseJSON(response); 
									if (response[0][0].status == "error") {
										hide_upload_started();
										hide_message_box("gntSl-message-box");
										jAlert(response[0][0].data['messg'],'E', function() {
												$.popgSLfrm._hide();
										});
									} else if (response[0][0].status == "success") {
										hide_upload_started();
										if (response[0][0].data[0]['node-id'] != '-1') {
											jAlert(response[0][0].data[0]['messg'],'S',function() {
												$.popgSLfrm._hide();
												jQuery("#flex-tskReviews").flexReload();
												loadProjectGantt('');
											});
										} else {
											jAlert(response[0][0].data[0]['messg'],'E');
										}  
									}
								}
							});			
						} else {
							return false;
						};
					}); 
				} else {
					jAlert('Record NOT selected !', 'E');
				};
			} else if (com=='Add') {
				tab_toggler = true;
				/*jConfirm('Add new Review Meeting<b>?</b>', '', function(user_act) {
					if (user_act) { */
						jgSforms('GntTaskReviewAdd', selNodeID,'Add Review Meeting...');
				/*	} else {
						return false;
					};
				}); */
			} else if (com=='Edit') {
				tab_toggler = true;
				if ($('.trSelected',grid).length>0) {
					/* jConfirm('Edit the Review Meeting<b>?</b>', '', function(user_act) {
						if (user_act) { */
							var items = $('.trSelected',grid);
							var itemlist =items[0].id.substr(3);
							jgIForms('GntTaskReviewEdit', itemlist,'Edit Review Meeting...');
					/*	} else {
							return false;
						};
					}); */
				} else {
					jAlert('Record NOT selected !', 'E');
				};
			} else if (com=='Email') {
				tab_toggler = true;
				if ($('.trSelected',grid).length>0) {
					/* jConfirm('Send Email on the Review Meeting<b>?</b>', '', function(user_act) {
						if (user_act) { */
							var items = $('.trSelected',grid);
							var itemlist =items[0].id.substr(3);
							jgIForms('GntTaskReviewEmail', itemlist,'Communicate Review Meeting...');
					/*	} else {
							return false;
						};
					}); */
				} else {
					jAlert('Record NOT selected !', 'E');
				};
			}
		}	
	}
}







function MeetingParticipants(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
 
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-task-meeting-participants-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "participant-uid": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-participants").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
        /* jConfirm('Add Details of Meeting Participants<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntParticipantAdd', selNodeID,'Add Meeting Participants...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Edit the Meeting Participant<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntParticipantEdit', itemlist,'Edit Meeting Participant...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='View') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('View the Meeting Participant<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntParticipantView', itemlist,'View Meeting Participant...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }    
}

function checkMoMEmails() {
	jgIForms('GntTaskMoMDetails', selNodeID,'Regular Meeting Emails..');
}
function checkRpsEmails() {
	jgIForms('GntTaskRpsDetails', selNodeID,'Regular Status Reports Emails..');
}


function MOMDocsLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist ='';
					 for(i=0;i<items.length;i++){
						itemlist+= items[i].id.substr(3)+",";
					} 
					$.ajax({
					   type: "POST",
					   url: "phpFlexService.php",
					   data: {"page": "gnt-task-MOMs-delete", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					   	timeout: xhr_timeout,
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						},
					   success: function(data){
							$("#flex-tsk-minutes").flexReload();
					   }
					 }); 
				} else {
					return false;
				};
			});
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    } else if (com=='Download') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			
			zipDownloader("gnt-task-MoMs-dwl", $('#gantt-select-devp').val(), itemlist); 
			
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    } else if (com=='Upload') {
        /*jConfirm('Upload new MOM Documents<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntMOMsUpload', selNodeID,'Upload MOM Documents...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='View') {
		if ($('.trSelected',grid).length>0) {  
			if ($('.trSelected',grid).length>1) { 
				jAlert('Too many documents selected! Select one...', 'E');	
			} else {
				var items = $('.trSelected',grid); // MA University of Kerala.pdf
				var itemlist ='';
				 for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3);
				} 
				//alert(itemlist);
				$.ajax({
				   type: "POST",
				   url: "phpFlexService.php",
				   data: {"page": "gnt-task-MoMs-view", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					timeout: xhr_timeout,
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					},
				   success: function(data){
						response = $.parseJSON(data); 
						var FileName = response[0]["file-to-view"].replace(/ /g, '%20');
						var FileMIME = response[0]["file-mime-type"];
						if(FileMIME != '') {
							var myWindow = window.open("","_blank","fullscreen=yes, location=no, menubar=no, toolbar=no");
							myWindow.document.write('<object data='+ FileName +' type='+ FileMIME +' width="100%" height="100%"><p>Cannot open the document directly.  <a href='+ FileName +'>Click here to download the file...</a></p></object>');
						} else jAlert('Unable to open the document...', 'E');
				   }
				 }); 
			}; 
		
		} else {
			jAlert('Document NOT selected !', 'E');
		}; 
    } else if (com=='Circulate') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			}
			jgIForms('GntTaskMoMCirc', itemlist,'Circulate Meeting Documents...');
			
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    } 
	
}

function ReportsDocsLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist ='';
					 for(i=0;i<items.length;i++){
						itemlist+= items[i].id.substr(3)+",";
					} 
					
					$.ajax({
					   type: "POST",
					   url: "phpFlexService.php",
					   data: {"page": "gnt-task-Reports-delete", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					   	timeout: xhr_timeout,
						error: function () {
							hide_all_errors();
							hide_upload_started();
							jAlert('Could not connect to server...','T');
						},
					   success: function(data){
							$("#flex-tsk-progressReports").flexReload();
					   }
					 }); 
				} else {
					return false;
				};
			});
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    } else if (com=='Download') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			 
			zipDownloader("gnt-task-Reports-dwl", $('#gantt-select-devp').val(), itemlist); 
			
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    } else if (com=='Upload') {
       /* jConfirm('Upload new Reports Documents<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntRpsUpload', selNodeID,'Upload Reports Documents...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Generate') {
       /* jConfirm('Generate new Report Document<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntRpsGenerate', selNodeID,'Generate Report Document...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Create') {
        /*jConfirm('Generate new Custom Report<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntRpsCreate', selNodeID,'Generate Custom Report...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='View') {
		if ($('.trSelected',grid).length>0) {  
			if ($('.trSelected',grid).length>1) { 
				jAlert('Too many documents selected! Select one...', 'E');	
			} else {
				var items = $('.trSelected',grid); // MA University of Kerala.pdf
				var itemlist ='';
				 for(i=0;i<items.length;i++){
					itemlist+= items[i].id.substr(3);
				} 
				//alert(itemlist);
				$.ajax({
				   type: "POST",
				   url: "phpFlexService.php",
				   data: {"page": "gnt-task-Reports-view", "field":$('#gantt-select-devp').val(), "entities":itemlist},
					timeout: xhr_timeout,
					error: function () {
						hide_all_errors();
						hide_upload_started();
						jAlert('Could not connect to server...','T');
					},
				   success: function(data){
						response = $.parseJSON(data); 
						var FileName = response[0]["file-to-view"].replace(/ /g, '%20');
						var FileMIME = response[0]["file-mime-type"];
						if(FileMIME != '') {
							var myWindow = window.open("","_blank","fullscreen=yes, location=no, menubar=no, toolbar=no");
							myWindow.document.write('<object data='+ FileName +' type='+ FileMIME +' width="100%" height="100%"><p>Cannot open the document directly.  <a href='+ FileName +'>Click here to download the file...</a></p></object>');
						} else jAlert('Unable to open the document...', 'E');
				   }
				 }); 
			}; 
		
		} else {
			jAlert('Document NOT selected !', 'E');
		}; 
    } else if (com=='Circulate') {
		if ($('.trSelected',grid).length>0) {
			var items = $('.trSelected',grid);
			var itemlist ='';
			 for(i=0;i<items.length;i++){
				itemlist+= items[i].id.substr(3)+",";
			} 
			jgIForms('GntTaskRpsCirc', itemlist,'Circulate Report Documents...');
			
			
			
			/*$.ajax({
			   type: "POST",
			   url: "phpFlexService.php",
			   data: {"page": "gnt-task-Reports-sent", "field":$('#gantt-select-devp').val(), "node-id":selNodeID, "entities":itemlist},
			   	timeout: xhr_timeout,
				error: function () {
					hide_all_errors();
					hide_upload_started();
					jAlert('Could not connect to server...','T');
				},
			   success: function(data){
					//alert(data);
					response = $.parseJSON(data); 
					if (response[0]['status'] == 'error') {
						jAlert(response[0]['data'],'E');
					} else if (response[0]['status'] == 'success') {
						jAlert(response[0]['data'],'S', function(){
							if (parseInt(response[0]["ciculation-status"]) == 0) $("#gnt-reports-sent").val("Not Circulated");
								else $("#gnt-reports-sent").val("Circulated: "+ response[0]["ciculation-status"] +" time(s)");
						});
					}
					//if (data != '') jAlert(data, 'Documents Circulate');
			   }
			 }); */
		} else {
			jAlert('Documents NOT selected !', 'E');
		};
    }
	
}

function CRLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-cr-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "cr-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-crs").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-crs").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
        /* jConfirm('Add new Change Request Entry<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntProjectCRAdd', selNodeID,'Submit Change Request...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Edit the Change Request Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCREdit', itemlist,'Edit Change Request...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Comment') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { //COMMENT
			/*jConfirm('Comment on the Change Request Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCRComment', itemlist,'Comment on Change Request Details...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='View') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { // VIEW
			/* jConfirm('View the Change Request Entry Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCRView', itemlist,'View Change Request...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-cr-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "cr-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-crs").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-crs").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Update the Change Request Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskCRUpdt', itemlist,'Update Change Request...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='History') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('View the Change Request History<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskCRHistory', itemlist,'History Change Request...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }         
}



function BDLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-bd-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "bd-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-bugs").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-bugs").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
       /* jConfirm('Add new Bug or Defect Entry<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntProjectBDAdd', selNodeID,'Submit Bug or Defect...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Edit the Bug or Defect Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectBDEdit', itemlist,'Edit Bug or Defect...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Comment') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { //COMMENT
			/*jConfirm('Comment on the Bug or Defect Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectBDComment', itemlist,'Comment on Bug or Defect Entry Details...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='View') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { // VIEW
			/* jConfirm('View the Bug or Defect Entry Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectBDView', itemlist,'View Bug or Defect...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-bd-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "bd-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-bugs").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-bugs").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Update the Bug-Defect Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskBDUpdt', itemlist,'Update Bug-Defect...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='History') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('View the Bug-Defect History<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskBDHistory', itemlist,'History Bug-Defect...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }       
}


function IssueLogLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-task-issue-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "issue-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-issues").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-issues").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
        /* jConfirm('Add new Issue Log Entry<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntTaskIssueAdd', selNodeID,'Submit Issue...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Edit the Issue Log Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskIssueEdit', itemlist,'Edit Issue...');
			/*	} else {
					return false;
				};
			});  */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='Comment') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('Comment on the Issue Log Entry Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskIssueView', itemlist,'Comment on Issue Log Entry Details...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-task-issue-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "issue-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-issues").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-issues").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Update the Issue Log Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskIssueUpdt', itemlist,'Update Issue Log...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='History') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/* jConfirm('View the Issue Log History<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskIssueHistory', itemlist,'History Issue Log...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }         
}

function RiskRegisterLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-risk-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "risk-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-risks").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-risks").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
        /*jConfirm('Add new Risk Register Entry<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntProjectRiskAdd', selNodeID,'Submit Risk...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Edit the Risk Register Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntProjectRiskEdit', itemlist,'Edit Risk...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='Comment') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Comment on the Risk Register Entry Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectRiskView', itemlist,'Comment on Risk Register Details...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpGanttService.php",
						type: 'POST',
						data: {"page": 'gnt-project-risk-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "risk-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-risks").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-tsk-risks").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Update the Risk Register Entry<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskRiskUpdt', itemlist,'Update Risk Register...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='History') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('View the Risk History<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskRiskHistory', itemlist,'History Risk...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }          
}

/*------------- END OF Project Task Update Actions --------------     */

/* --------------------   Backlog Actions -------------------------  */

function styUpdHistory(com,grid) {
    if (com=='View') { 
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { 
			/*jConfirm('View the Update History Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('styBakUpdHist', itemlist,'View Update History...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }       
}



function GTLists(com,grid) {
    if (com=='Delete') { //--
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'backlog-story-gt-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "cr-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-gts").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-gts").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') { //--
		tab_toggler = true;
        /*jConfirm('Add new Grooming Tip<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntProjectCRAdd', selNodeID,'Submit Grooming Tip...');
		/*	} else {
				return false;
			};
		}); */
    } else if (com=='Edit') { //--
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
			/*jConfirm('Edit the Grooming Tip<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCREdit', itemlist,'Edit Grooming Tip...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Comment') { //-- 
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { //COMMENT
			/*jConfirm('Comment on the Grooming Tip<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCRComment', itemlist,'Comment on Grooming Tip Details...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='View') { //-- 
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) { // VIEW
			/*jConfirm('View the Grooming Tip Details<b>?</b>', '', function(user_act) {
				if (user_act) { */
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntProjectCRView', itemlist,'View Grooming Tip...');
			/*	} else {
					return false;
				};
			}); */
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') { //--
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'backlog-story-gt-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "cr-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-gts").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-gts").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') { //-- working
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskCRUpdt', itemlist,'Update Grooming Tip...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='History') { //-- 
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskCRHistory', itemlist,'History Grooming Tip...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }         
}




function BacklogIssueLists(com,grid) {
    if (com=='Delete') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'backlog-story-issue-delete',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "issue-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-issues").flexReload();
										loadProjectGantt('');
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-issues").flexReload();
										loadProjectGantt('');
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Add') {
		tab_toggler = true;
				jgSforms('GntTaskIssueAdd', selNodeID,'Submit Backlog Challenge...');
    } else if (com=='Edit') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskIssueEdit', itemlist,'Edit Backlog Challenge...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }  else if (com=='Comment') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskIssueView', itemlist,'Comment on Backlog Challenge Entry Details...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Purge') {
		if ($('.trSelected',grid).length>0) {
			jConfirm('<b>Action cannot be reverted ! </b> Confirm...', '', function(user_act) {
				if (user_act) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					show_upload_started();
					$.ajax({
						url: "phpBacklogService.php",
						type: 'POST',
						data: {"page": 'backlog-story-issue-purge',
							   "project-id": $('#gantt-select-devp').val(), 
							   "node-id": selNodeID, 
							   "issue-id": itemlist,
							   "user-id": user_id
						},
						timeout: xhr_timeout,
						error: function () {
							hide_all_errors(); //
							hide_upload_started(); //
							jAlert('Could not connect to server...','T');
						},
						success: function(response) {
							//alert(response);
							response = $.parseJSON(response); 
							if (response[0][0].status == "error") {
								hide_upload_started();
								hide_message_box("gntSl-message-box");
								jAlert(response[0][0].data['messg'],'E', function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-issues").flexReload();
								});
							} else if (response[0][0].status == "success") {
								hide_upload_started();
								if (response[0][0].data[0]['node-id'] != '-1') {
									jAlert(response[0][0].data[0]['messg'],'S',function() {
										$.popgSLfrm._hide();
										jQuery("#flex-sty-issues").flexReload();
									});
								} else {
									jAlert(response[0][0].data[0]['messg'],'E');
								}  
							}
						}
					});			
				} else {
					return false;
				};
			}); 
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='Update') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgSforms('GntTaskIssueUpdt', itemlist,'Update Backlog Challenge...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    } else if (com=='History') {
		tab_toggler = true;
		if ($('.trSelected',grid).length>0) {
					var items = $('.trSelected',grid);
					var itemlist =items[0].id.substr(3);
					jgIForms('GntTaskIssueHistory', itemlist,'History Backlog Challenge...');
		} else {
			jAlert('Record NOT selected !', 'E');
		};
    }         
}




/* ---------------- END of Backlog Actions ----------------------  */

/*------------- Project Gantt Action Functions --------------     */

function actionProjectGovern() {
	if ($("#project_governance").hasClass('baklog_detach') == false) jgfForms('ProjectBacklog', $('#gantt-select-devp').val(),'Project Governance and Work Log...');	
}


function actionProjectSettings() {

	jPrompt('The existing Gantt chart page will be <b>REFRESHED</b> with the action. Continue...<b>?</b>', '', function(user_act) {
		if (user_act) {
			hide_all_errors();
			hide_upload_started();
			$('#nav li').children('ul').hide().end();
			$("#fnMenu-Projects").trigger("click");
		} else {
			return;
		};
	}); 
}


function actionGanttAnalyzer() {

	jPrompt('The existing Gantt chart page will be <b>REFRESHED</b> with the action. Continue...<b>?</b>', '', function(user_act) {
		if (user_act) {
			
			hide_all_errors();
			hide_upload_started();
			$('#nav li').children('ul').hide().end();
			$("#fnMenu-Analyzer").trigger("click");
		} else {
			return;
		};
	}); 
}


function actionGanttSave() {
	if (prjAgility == 0)  {
		/* jPrompt('Save the project as WBS Template<b>?</b>', '', function(user_act) {
			if (user_act) { */
				jgSforms('GntSaveAs', $('#gantt-select-devp').val(),'Save Project as WBS Template');	
		/*	} else {
				return;
			};
		}); */
	} else {
		var prmTitle = (bakLogShow == 0) ? 'Product Backlog' : 'Sprint Planner';
		var prmMssg = (bakLogShow == 0) ? 'Switch to <b>Product Backlog</b>?' : 'Switch to <b>Sprint Planner</b>?';
		/* jPrompt(prmMssg, '', function(user_act) {
			if (user_act) { */
				first_time_load = true;
				bakLogShow = (bakLogShow == 0) ? 1 : 0;
				procesMode = 2;
				$('#gnt-process-mode option[value="2"]').attr('selected', 'selected');
				loadProjectGantt('');	
		/*	} else {
				return;
			};
		}); */
	}
}

function actionGanttPrint() {
	if (!$('#print_ctrl').hasClass('printer_detach')) {
	/*	jPrompt('Print the Gantt chart<b>?</b>', '', function(user_act) {
			if (user_act) { */
				$("div.PrintArea").printArea({ mode : "iframe", popClose : false });
	/*		} else {
				return;
			};
		});  */
	} else return;
}

function actionGanttBaseline() {

	/* jPrompt('Manage Project Baselines<b>?</b>', '', function(user_act) {
		if (user_act) { */
			jgSforms('GntBaseline', $('#gantt-select-devp').val(),'Manage Project Baselines');	
	/*	} else {
			return;
		};
	}); */

}

 function actionGanttDisplay() {
 
	if (prjAgility == 0) {
		$('#lbl_gWork_h').text(" Hours");
		$('#lbl_gWork_d').text(" Days");
	} else {
		$('#lbl_gWork_h').text(' Units');
		$('#lbl_gWork_d').text(' Story Points');
	}

	var offset = $('#display_ctrl').offset();
	var intWidth = $(window).innerWidth();
	var outWidth = $('#displayparam').outerWidth();
	var xPos = Math.floor((intWidth / 2) - (outWidth / 2));

	if ((user_profile == 'stake') && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
				$("#Gantt-PWTrack-lbl, #Gantt-PWTrack").css('display', 'none');
	}

	$("#dispSettings-button").css({
		 "min-width": "99.8%",
		 "height": "20px"
	});
	
	$('#displayparam').bPopup({
		modal: true,
		modalColor: '#F5F9FA',
		position: [xPos, offset.top],
		opacity: 0.2, 
		positionStyle: 'fixed',
		fadeSpeed: 'slow', followSpeed: 500, speed: 550              //transition: 'slideDown'
		        });
				
}

function actionGanttResource() {

	/* jPrompt('List Resource Usage chart<b>?</b>', '', function(user_act) {
		if (user_act) { */
			jgfForms('GntResourceUsage', $('#gantt-select-devp').val(),'Resource Usage...');
	/*	} else {
			return;
		};
	}); */

}

function PrintResourceUsage(val) {

	/*jPrompt('Print Resource Usage List<b>?</b>', '', function(user_act) {
		if (user_act) { */
			$("div.ResPrintArea").printArea({ mode : "iframe", popClose : false });
	/*	} else {
			return;
		};
	}); */

}


function actionStoryBreakList() {

	/* jPrompt('List Story-wise Breakup<b>?</b>', '', function(user_act) {
		if (user_act) { */
			jgfForms('GntStoryUsage', $('#gantt-select-devp').val(),'Story-wise Breakup...');
	/*	} else {
			return;
		};
	}); */

}

function PrintStoryBreakList(val) {

	/* jPrompt('Print Story-wise Breakup<b>?</b>', '', function(user_act) {
		if (user_act) { */
			$("div.SBSPrintArea").printArea({ mode : "iframe", popClose : false });
	/*	} else {
			return;
		};
	}); */

}


function actionCreateReport() {

	/* jPrompt('Generate Status Report<b>?</b>', '', function(user_act) {
		if (user_act) { */
			selNodeID=1;
			jgSforms('GntRpsCreate', 1,'Status Reports...');
	/*	} else {
			return;
		};
	}); */

}



function showResourceRates(res_ID) {
	jgSforms('ShwResRate', res_ID,'Resource Hourly Rates');	

}

function actionGanttCtrlAcnt() {

	/* jPrompt('List Control Account Breakdown<b>?</b>', '', function(user_act) {
		if (user_act) { */
			jgfForms('GntCAUsage', $('#gantt-select-devp').val(),'Control Account Breakup...');
	/*	} else {
			return;
		};
	}); */

}


function PrintCABreakdown(val) {

	/* jPrompt('Print Control Account Breakdown List<b>?</b>', '', function(user_act) {
		if (user_act) { */
			$("div.CAPrintArea").printArea({ mode : "iframe", popClose : false });
	/*	} else {
			return;
		};
	}); */

}


/*------------- END of Project Gantt Action Functions --------------     */


