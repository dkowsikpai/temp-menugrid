var JSBaklog;
if (!JSBaklog) JSBaklog = {};
var vTimeout = 0;
var vBenchTime = new Date().getTime();
JSBaklog.TaskItem = function (pID, pName, pLink, pMile, pRes, pComp, pGroup, pParent, pOpen, pDepend, pCaption,pRole, pEstimWork, pAdjEstWrk, pNotes, pNumDocs, ptIssues, poIssues, ptCRs, poCRs, pWorkTolnce, pWorkTolnceNotes, pStryNum, pStrySts, pPriority, pActive, pRelsdWork, pFlagValue, pColor, pEstimBasis) {
    var vID = pID;
    var vName = pName;
    var vLink = pLink;
    var vRole = pRole;
    var vNotes = pNotes;
    var vNumDocs = pNumDocs;
    var vEstimWork = pEstimWork;
    var vAdjEstWrk = pAdjEstWrk;
	var vRelsdWork= pRelsdWork;
	var vtIssues = ptIssues;
	var voIssues = poIssues;
	var vtCRs = ptCRs;
	var voCRs = poCRs;
	var vWorkTolnce = pWorkTolnce;
	var vWorkTolnceNotes = pWorkTolnceNotes;
	var vEstimBasis = pEstimBasis;
    var vMile = pMile;
    var vRes = pRes;
    var vComp = parseInt(pComp);
    var vsComp = parseFloat(pComp).toFixed(2);
    var vGroup = pGroup;
    var vParent = pParent;
    var vOpen = pOpen;
    var vDepend = pDepend;
    var vCaption = pCaption;
    var vActive = pActive;
    var vLevel = 0;
    var vNumKid = 0;
    var vVisible = 1;
   // var x1, y1, x2, y2;
    var vStryNum = pStryNum;
	var vStrySts = pStrySts;
	var vPriority = pPriority;
	var vFlagValue = pFlagValue;
	var vColor = pColor;
	
	this.getActive = function () {
        return vActive
    };
    this.getFlagValue = function () {
        return vFlagValue
    };
    this.getPriorityStr = function () {
        return vPriority
    };
    this.getStryStsStr = function () {
        if (vFlagValue == 1) return 'Deleted';
			else if (vFlagValue == 2) return 'Released';
			else if (vFlagValue == 3) return 'In Progress';
			else if (vFlagValue == 4) return 'In Sprint';
			else if (vFlagValue == 5) return 'Completed';
			else if (vFlagValue == 6) return 'Past Progress';
			else if (vFlagValue == 7) return 'Past Sprint';
			else return '-';
    };
    this.getStrySts = function () {
        return vStrySts
    };
    this.getStryNum = function () {
        return vStryNum
    };
    this.getID = function () {
        return vID
    };
    this.getName = function () {
        return vName
    };
    this.getWorkToleranceStr = function () {
        if (vWorkTolnce == 0) return "-";
			else return vWorkTolnce.toFixed(2)+"%";
    };
    this.getTolnceNotes = function () {
        return vWorkTolnceNotes;
    };
    this.getEstimateBasis = function () {
        return vEstimBasis;
    };
	
    this.getLink = function () {
        return vLink
    };
    this.getEstimWork = function () {
       // return vEstimWork;
        var zEstWork = parseFloat(vEstimWork).toFixed(2);
		if (zEstWork > 0) {
			if (WorkShow == 'H') return zEstWork + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zEstWork = parseFloat(zEstWork / prjSp2Hrs).toFixed(2);
					return zEstWork + ' Sps';
			    } else return zEstWork + ' Hrs';
			}
		} else return '-';
    }; // Compute Hour or Day here  MSD 
	
    this.getAdjtEstimate = function () { 
        var zAdjEstWrk = parseFloat(vAdjEstWrk).toFixed(2);
		if (zAdjEstWrk > 0) {
			if (WorkShow == 'H') return zAdjEstWrk + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zAdjEstWrk = parseFloat(zAdjEstWrk / prjSp2Hrs).toFixed(2);
					return zAdjEstWrk + ' Sps';
			    } else return zAdjEstWrk + ' Hrs';
			}
		} else return '-';
    } // Compute Hour or Day here  MSD 
	
    this.getReleasedWork = function () { 
        var zRelsdWrk = parseFloat(vRelsdWork).toFixed(2);
		if (zRelsdWrk > 0) {
			if (WorkShow == 'H') return zRelsdWrk + ' Hrs';
			else {
				if (prjSp2Hrs > 0) { 
					zRelsdWrk = parseFloat(zRelsdWrk / prjSp2Hrs).toFixed(2);
					return zRelsdWrk + ' Sps';
			    } else return zRelsdWrk + ' Hrs';
			}
		} else return '-';
    } // Compute Hour or Day here  MSD 
	
	
	
	this.getTIssues = function () {
		return vtIssues;
    };
	this.getOIssues = function () {
		return voIssues;
    };
	this.getTCRs = function () {
		return vtCRs;
    };
	this.getOCRs = function () {
		return voCRs;
    };
    this.getNotes = function () {
        return vNotes;
    };
    this.getNumDocs = function () {
        return vNumDocs
    };
	this.getMile = function () {
        return vMile
    };
	
    this.getDepend = function () {
        if (vDepend) return vDepend;
        else return ''
    };
    this.getCaption = function () {
        if (vCaption) return vCaption;
        else return '';
    };
    this.getResource = function () {
        if (RoleName == 1) {
            if (vRes) return vRes;
            else return '&nbsp';
        } else {
            if (vRole) return vRole;
            else return '&nbsp';
        }
    };
    this.getCompVal = function () {
        if (vComp) return vComp;
        else return 0;
    }; // Remove getCompVal 
    this.getProgressVal = function () {
        if (vsComp) return vsComp;
        else return 0;
    };
	
	
    this.getProgressStr = function () {
        if (vsComp > 0) return vsComp + '%';
        else return '';
    };
	
    this.getCompStr = function () {
		var vWComp = parseInt((ColWidths[0]['StoryStatus'] + 21) * vStrySts / 100);
		if (vWComp > 0) return vWComp + 'px';
			else return '0px';
    };
	
	this.getColor = function () {
        return vColor
    };
	
    this.getParent = function () {
        return vParent
    };
    this.getGroup = function () {
        return vGroup
    };
    this.getOpen = function () {
        return vOpen
    };
    this.getLevel = function () {
        return vLevel
    };
    this.getNumKids = function () {
        return vNumKid
    };
    this.getVisible = function () {
        return vVisible
    };
    this.setDepend = function (pDepend) {
        vDepend = pDepend;
    };
    this.setStart = function (pStart) {
        vStart = pStart;
    };

    this.setEnd = function (pEnd) {
        vEnd = pEnd;
    };
    this.setLevel = function (pLevel) {
        vLevel = pLevel;
    };
    this.setNumKid = function (pNumKid) {
        vNumKid = pNumKid;
    };
    this.setCompVal = function (pCompVal) {
        vComp = pCompVal;
    };
    this.setOpen = function (pOpen) {
        vOpen = pOpen;
    };
    this.setVisible = function (pVisible) {
        vVisible = pVisible;
    };

};

JSBaklog.GanttChart = function (pGanttVar, pDiv, pFormat) {
    var vGanttVar = pGanttVar;
    var vDiv = pDiv;
    var vFormat = pFormat;
    var vShowRes = 1;
    var vShowDur = 1;
    var vShowComp = 1;
    var vShowStartDate = 1;
    var vShowEndDate = 1;
    var vDateInputFormat = "mm/dd/yyyy";
    var vDateDisplayFormat = "mm/dd/yy";
    var vNumUnits = 0;
    var vCaptionType;
    var vDepId = 1;
    var vTaskList = new Array();
    var vFormatArr = new Array("day", "week", "month", "quarter");
    var vQuarterArr = new Array(1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4);
    var vMonthDaysArr = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    var vMonthArr = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    this.setFormatArr = function () {
        vFormatArr = new Array();
        for (var i = 0; i < arguments.length; i++) {
            vFormatArr[i] = arguments[i];
        }
        if (vFormatArr.length > 4) {
            vFormatArr.length = 4;
        }
    };
    this.setFormat = function (pFormat) {
        vFormat = pFormat;
        this.Draw();
    };
    this.getCaptionType = function () {
        return vCaptionType
    };

    this.AddTaskItem = function (value) {
        vTaskList.push(value);
    };
    this.getList = function () {
        return vTaskList
    };

    this.DrawDependencies = function () {
		return false;
    };

    this.getArrayLocationByID = function (pId) {

        var vList = this.getList();
        for (var i = 0; i < vList.length; i++) {
            if (vList[i].getID() == pId) return i;
        }
    };

    this.Draw = function () {
        var vMaxDate = new Date();
        var vMinDate = new Date();
        var vTmpDate = new Date();
        var vNxtDate = new Date();
        var vCurrDate = new Date();
        var vTaskLeft = 0;
        var vTaskRight = 0;
        var vNumCols = 0;
        var vID = 0;
        var vMainTable = "";
        var vLeftTable = "";
        var vRightTable = "";
        var vDateRowStr = "";
        var vItemRowStr = "";
        var vColWidth = 0;
        var vColUnit = 0;
        var vChartWidth = 0;
        var vNumDays = 0;
        var vDayWidth = 0;
        var vStr = "";

        var vNameWidth = ColWidths[0]['Tasks'] + 90;
        var vIDWidth = ColWidths[0]['ID'];
        var vNotesWidth = ColWidths[0]['Notes'];
		var vRegistryWidth = ColWidths[0]['Registry'];
        var vResourceWidth = ColWidths[0]['Resource'];
        var vProgressWidth = ColWidths[0]['Progress'] + 40;
        var vAdjtEstimateWidth = ColWidths[0]['AdjtEstimate'];
        var vEstimateWorkWidth = ColWidths[0]['EstimateWork'];
		var vReleasedWorkWidth = ColWidths[0]['ReleasedWork'];
		var vWorkToleranceWidth = ColWidths[0]['WorkTolerance'];
		var vStoryNumWidth = ColWidths[0]['StoryNum'];
		var vStoryStatusWidth = ColWidths[0]['StoryStatus'];
		var vPriorityWidth = ColWidths[0]['Priority'] + 50;
		
        var vScreenWidth = ColWidths[0]['Screen'];
        var vLeftWidth = 0;

        if (vTaskList.length > 0) {

            JSBaklog.processRows(vTaskList, 0, -1, 1, 1);
            if (vFormat == 'day') {
                vColWidth = 18;
                vColUnit = 1;
            } else if (vFormat == 'week') {
                vColWidth = 37;
                vColUnit = 7;
            } else if (vFormat == 'month') {
                vColWidth = 37;
                vColUnit = 30;
            } else if (vFormat == 'quarter') {
                vColWidth = 60;
                vColUnit = 90;
            } else if (vFormat == 'hour') {
                vColWidth = 18;
                vColUnit = 1;
            } else if (vFormat == 'minute') {
                vColWidth = 18;
                vColUnit = 1;
            }


            vChartWidth = vNumUnits * vColWidth + 1;
            vDayWidth = (vColWidth / vColUnit) + (1 / vColUnit);

            //  from here --------------------------------------------------------------- getPriority

            vMainTable = '<TABLE id=theTable cellSpacing=0 cellPadding=0 border=0 style="margin: 0px auto;"><TBODY><TR>' + '<TD vAlign=top bgColor=#ffffff>';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
					case 'Notes':
						vLeftWidth += vNotesWidth + 35;
						break;
					case 'Registry':
						vLeftWidth += vRegistryWidth + 35;
						break;
					case 'Tasks': 
						vLeftWidth += vNameWidth + 21;
						break;
					case 'Resource':
						vLeftWidth += vResourceWidth + 21;
						break;
					case 'Progress':
						vLeftWidth += vProgressWidth + 22;
						break;
					case 'ID':
						vLeftWidth += vIDWidth + 21;
						break;
					case 'AdjtEstimate':
						vLeftWidth += vAdjtEstimateWidth + 21;
						break;
					case 'EstimateWork':
						vLeftWidth += vEstimateWorkWidth + 21;
						break;
					case 'WorkTolerance':
						vLeftWidth += vWorkToleranceWidth + 21;
						break;
					case 'StoryNum':
						vLeftWidth += vStoryNumWidth + 21;
						break; 
					case 'StoryStatus':
						vLeftWidth += vStoryStatusWidth + 21;
						break;
					case 'Priority':
						vLeftWidth += vPriorityWidth + 21;
						break;
					case 'ReleasedWork':
						vLeftWidth += vReleasedWorkWidth + 21;
						break;               
				}
            }
			
            if(vLeftWidth > vScreenWidth) vLeftWidth = vScreenWidth;  
			//if(vLeftWidth < 1000) vLeftWidth = 1000; 

            var lsDisplay = "block";
            var rsDisplay = "none";

            // DRAW the Left-side of the chart MSD -- add display none to hide DIV id leftside to hide spreadsheet
            vLeftTable = '<DIV class=scroll id=leftside style="width:' + vLeftWidth + 'px; display:' + lsDisplay + ';">' +
            //'<DIV id=lefttopfill style="width:' + vLeftWidth + 'px; HEIGHT: 17px"></DIV>' +
            '<TABLE id="tLeft" cellSpacing=0 cellPadding=0 border=0><THEAD>';

            vLeftTable += '<TR style="HEIGHT: 25px">';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
                case 'Notes':
                    vLeftTable += '<TH id="Notes_h" class="lTabCol" style="WIDTH: ' + vNotesWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap><div style="font-size: 18px;"><b><i>i</i></b></div></TH>'; // <img src="css/jsgantt/info.jpg" width="23" height="17">
                    break;
                case 'Registry':
                    vLeftTable += '<TH id="Registry_h" class="lTabCol" style="WIDTH: ' + vRegistryWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Registers</TH>'; // <img src="css/jsgantt/info.jpg" width="23" height="17">
                    break;
                case 'Tasks':
                    vLeftTable += '<TH id="Tasks_h" class="lTabCol" style="WIDTH: ' + vNameWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Title</TH>';
                    break;
                case 'Resource':
                    vLeftTable += '<TH id="Resource_h" class="lTabCol" style="WIDTH: ' + vResourceWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Estimators</TH>';
                    break;
                case 'Progress':
                    vLeftTable += '  <TH id="Progress_h" class="lTabCol" style="WIDTH: ' + vProgressWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Progress</TH>';
                    break;
                case 'ID':
                    vLeftTable += '  <TH id="ID_h" class="lTabCol" style="WIDTH: ' + vIDWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>ID</TH>';
                    break;
                case 'AdjtEstimate':
                    vLeftTable += '  <TH id="AdjtEstimate_h" class="lTabCol" style="WIDTH: ' + vAdjtEstimateWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Adjusted Estimate</TH>';
                    break;
                case 'EstimateWork':
                    vLeftTable += '  <TH id="EstimateWork_h" class="lTabCol" style="WIDTH: ' + vEstimateWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Estimate Work</TH>';
                    break;
                case 'ReleasedWork':
                    vLeftTable += '  <TH id="ReleasedWork_h" class="lTabCol" style="WIDTH: ' + vReleasedWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Released Work</TH>';
                    break;
					
					
					
                case 'WorkTolerance':
                    vLeftTable += '  <TH id="WorkTolerance_h" class="lTabCol" style="WIDTH: ' + vWorkToleranceWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Work Tolerance</TH>';
                    break;
                case 'StoryNum': 
                    vLeftTable += '  <TH id="StoryNum_h" class="lTabCol" style="WIDTH: ' + vStoryNumWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Story ID</TH>';
                    break;
                case 'StoryStatus': 
                    vLeftTable += '  <TH id="StoryStatus_h" class="lTabCol" style="WIDTH: ' + vStoryStatusWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Status</TH>';
                    break;
                case 'Priority': 
                    vLeftTable += '  <TH id="Priority_h" class="lTabCol" style="WIDTH: ' + vPriorityWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap>Priority</TH>';
                    break;
                } 
            }
            vLeftTable += '</TR><TR style="HEIGHT: 15px">';

            for (colC = 0; colC < ColOrder.length; colC++) {

                switch (ColOrder[colC]) {
                case 'Notes':
                    vLeftTable += '<TD id="Notes" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vNotesWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Registry':
                    vLeftTable += '<TD id="Registry" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vRegistryWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Tasks':
                    vLeftTable += '<TD id="Tasks" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vNameWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Resource':
                    vLeftTable += '<TD id="Resource" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vResourceWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Progress':
                    vLeftTable += '  <TD id="Progress" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vProgressWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'ID':
                    vLeftTable += '  <TD id="ID" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vIDWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'AdjtEstimate':
                    vLeftTable += '  <TD id="AdjtEstimate" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vAdjtEstimateWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'EstimateWork':
                    vLeftTable += '  <TD id="EstimateWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vEstimateWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
                case 'ReleasedWork':
                    vLeftTable += '  <TD id="ReleasedWork" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vReleasedWorkWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=center nowrap></TD>';
                    break;
					
					
					
                case 'WorkTolerance':
                    vLeftTable += '  <TD id="WorkTolerance" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vWorkToleranceWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'StoryNum':
                    vLeftTable += '  <TD id="StoryNum" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vStoryNumWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'StoryStatus':
                    vLeftTable += '  <TD id="StoryStatus" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vStoryStatusWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
                case 'Priority':
                    vLeftTable += '  <TD id="Priority" class="lTabClk" title="Right Click to Hide/Show Column" style="WIDTH: ' + vPriorityWidth + 'px" onclick="JSBaklog.resizePopup(this.id);" align=right nowrap></TD>';
                    break;
				
                } 
            }

            vLeftTable += '</TR></THEAD><TBODY>';

            for (i = 0; i < vTaskList.length; i++) {
                if (vTaskList[i].getGroup()) {
                    if (vTaskList[i].getLink() % 2 == 1) {
                        vBGColor = "ffffff";
                    } else {
                        vBGColor = "eee";
                    }
                    vRowType = "group"; // Row colors  MSD 98F8ED
                } else {
                    if (vTaskList[i].getLink() % 2 == 1) {
                        vBGColor = "ffffff";
                    } else {
                        vBGColor = "eee";
                    }
                    vRowType = "row";
                }

                vID = vTaskList[i].getID();

                if (vTaskList[i].getVisible() == 0) vLeftTable += '<TR id=child_' + vID + ' bgcolor=#' + vBGColor + ' style="display:none"  onMouseover=g.mouseOver(this,' + vID + ',"left","' + vRowType + '") onMouseout=g.mouseOut(this,' + vID + ',"left","' + vRowType + '")>';
					else vLeftTable += '<TR id=child_' + vID + ' bgcolor=#' + vBGColor + ' onMouseover=g.mouseOver(this,' + vID + ',"left","' + vRowType + '") onMouseout=g.mouseOut(this,' + vID + ',"left","' + vRowType + '")>';
				
				var pblcVwCol = (publicView == 0) ? " lTabCol" : " nlTabCol";
				var pblcVwCur = (publicView == 0) ? "pointer" : "default";
				for (colC = 0; colC < ColOrder.length; colC++) {

                    blankattach = 'blank_indicator';
                    blanknotes = 'blank_indicator';
                    blankconstr = 'blank_indicator';
					
                    blankrisk = 'blank_indicator';
                    blankissue = 'blank_indicator';
                    blankcrs = 'blank_indicator';
					blankbds = 'blank_indicator';
                    switch (ColOrder[colC]) {
                    case 'Notes':
                        vLeftTable += '<TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Notes"); style="WIDTH: ' + vNotesWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" >' + '<div id="tattach_' + vTaskList[i].getID() + '" class="' + blankattach + '">&nbsp;&nbsp;&nbsp;&nbsp;</div>' + '<div id="tnotes_' + vTaskList[i].getID() + '" class="' + blanknotes + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tconstr_' + vTaskList[i].getID() + '" class="' + blankconstr + '">&nbsp&nbsp&nbsp&nbsp</div>' + '</TD>';
                        break;
						
						
                    case 'Registry':
                        vLeftTable += '<TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Registry"); style="WIDTH: ' + vRegistryWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" >' + '<div id="trisk_' + vTaskList[i].getID() + '" class="' + blankrisk + '">&nbsp;&nbsp;&nbsp;&nbsp;</div>' + '<div id="tissue_' + vTaskList[i].getID() + '" class="' + blankissue + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tcrs_' + vTaskList[i].getID() + '" class="' + blankcrs + '">&nbsp&nbsp&nbsp&nbsp</div>' + '<div id="tbds_' + vTaskList[i].getID() + '" class="' + blankbds + '">&nbsp&nbsp&nbsp&nbsp</div>' + '</TD>';
                        break;
						
						
                    case 'Tasks':
                        {
                            vLeftTable += '<TD class="gname '+ pblcVwCol +'" style="WIDTH: ' + vNameWidth + 'px" nowrap><NOBR><span style="color: #aaaaaa">';

                            for (j = 1; j < vTaskList[i].getLevel(); j++) {
                                vLeftTable += '&nbsp&nbsp';
                            }
                            vLeftTable += '</span>';
							
							
							if (vTaskList[i].getGroup()) taskClr = GroupClr;
								else taskClr = StryClr;
							
							if (vTaskList[i].getActive() == 2) delClass = 'DelStory';
								else delClass = 'NonDelStory';
							
                            if (vTaskList[i].getGroup()) {
                                if (vTaskList[i].getOpen() == 1) vLeftTable += '<DIV id="group_' + vID + '" class="openGroup" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" onclick="JSBaklog.folder(' + vID + ',' + vGanttVar + ');' + vGanttVar + '.DrawDependencies();"></DIV><span style="color:#000000">&nbsp</SPAN>';
									else vLeftTable += '<DIV id="group_' + vID + '" class="closeGroup" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" onclick="JSBaklog.folder(' + vID + ',' + vGanttVar + ');' + vGanttVar + '.DrawDependencies();"></DIV><span style="color:#000000">&nbsp</SPAN>';
                            } else {
                                vLeftTable += '<span style="color: #000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px">&nbsp&nbsp&nbsp</span>';
                            }
							if (vTaskList[i].getID() == 1) {
								if (prjLockSts == 1) vLeftTable += '<DIV id="lock_' + vID + '" class="lockPrjkt" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Tasks");></DIV><span style="color:#000000">&nbsp</SPAN>';
								if (prjNdaSts == 1) vLeftTable += '<DIV id="nda_' + vID + '" class="ndaPrjkt" style="color:#000000; font-weight:bold; FONT-SIZE: 12px; PADDING-LEFT: 3px" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Tasks");></DIV><span style="color:#000000">&nbsp</SPAN>';
							}
                            vLeftTable += '<span ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Tasks"); class="'+ delClass +'" style="WIDTH: ' + vNameWidth + 'px; OVERFLOW: hidden; TEXT-ALIGN: left; DISPLAY:inline-block; color: #' + taskClr + '" > ' + vTaskList[i].getName() + '</span></NOBR></TD>';
                            break;
                        }
                    case 'Resource':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Resource"); style="WIDTH: ' + vResourceWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vResourceWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getResource() + '</span></NOBR></TD>';
                        break;
                    case 'Progress':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Progress"); style="WIDTH: ' + vProgressWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getProgressStr() + '</NOBR></TD>';
                        break;
                    case 'ID':
                        // MSD Include right click option
						
                        if (vTaskList[i].getMile()) vLeftTable += '  <TD id="gntMlnode_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","ID"); style="WIDTH: ' + vIDWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getLink() + '</NOBR></TD>';
                        else vLeftTable += '  <TD id="gntnode_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","ID"); style="WIDTH: ' + vIDWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getLink() + '</NOBR></TD>';
                        break;
                    case 'AdjtEstimate':
                        vLeftTable += '  <TD id="twtestm_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","AdjtEstimate"); style="WIDTH: ' + vAdjtEstimateWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vAdjtEstimateWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getAdjtEstimate() + '</span></NOBR></TD>';
                        break;
                    case 'EstimateWork':
                        vLeftTable += '  <TD id="tEstmWrk_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","EstimateWork"); style="WIDTH: ' + vEstimateWorkWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vEstimateWorkWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getEstimWork() + '</span></NOBR></TD>';
                        break;
                    case 'ReleasedWork':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","ReleasedWork"); style="WIDTH: ' + vReleasedWorkWidth + 'px; TEXT-ALIGN: right; PADDING-LEFT: 3px" align=center><NOBR><span style="WIDTH: ' + vReleasedWorkWidth + 'px; OVERFLOW: hidden; DISPLAY:inline-block">' + vTaskList[i].getReleasedWork() + '</span></NOBR></TD>';
                        break;
						
						
                    case 'WorkTolerance':
                        vLeftTable += '  <TD id="twtnotes_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","WorkTolerance"); style="WIDTH: ' + vWorkToleranceWidth + 'px; TEXT-ALIGN: right; PADDING-RIGHT: 3px" align=center><NOBR>' + vTaskList[i].getWorkToleranceStr() + '</NOBR></TD>';
                        break;
                    case 'StoryNum':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","StoryNum"); style="WIDTH: ' + vStoryNumWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px"><NOBR>' + vTaskList[i].getStryNum() + '</NOBR></TD>';
                        break;
                    case 'StoryStatus':
                        if (vTaskList[i].getColor() != 'ffffff') vLeftTable += '  <TD id="tstysts_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" style="background-color:#' + vTaskList[i].getColor() + '; opacity:0.9; position: relative; " ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","StoryStatus"); style="WIDTH: ' + vStoryStatusWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px">' + '<div style="Z-INDEX: -4; float:left; background-color:#'+ gBakClr +'; height:5px; margin-top:2px; filter: alpha(opacity=50); opacity:0.5; width:' + vTaskList[i].getCompStr() + '; overflow:hidden">' + '</div>'+'<DIV style="position: absolute; float: center; Z-INDEX: 2; width: 100%; height: 100%; left: 0;"><NOBR>' + vTaskList[i].getStryStsStr() + '</NOBR></DIV>'+'</TD>';
							else vLeftTable += '  <TD id="tstysts_' + vTaskList[i].getID() + '" class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","StoryStatus"); style="WIDTH: ' + vStoryStatusWidth + 'px; TEXT-ALIGN: center; PADDING-LEFT: 3px"><NOBR>' + vTaskList[i].getStryStsStr() + '</NOBR></TD>';
						break;
                    case 'Priority':
                        vLeftTable += '  <TD class="gname '+ pblcVwCol +'" ondblclick=JSBaklog.taskLink("' + vTaskList[i].getID() + '","Priority"); style="WIDTH: ' + vStoryNumWidth + 'px; TEXT-ALIGN: left; PADDING-LEFT: 3px"><NOBR>' + vTaskList[i].getPriorityStr() + '</NOBR></TD>';
                        break;
                    }
                } 

                vLeftTable += '</TR>';
            }
            vLeftTable += '</TD></TR>';
            vLeftTable += '</TBODY></TABLE></DIV>';
            vLeftTable += '<DIV id=leftbotfill style="width:' + vLeftWidth + 'px; HEIGHT: 20px; display:none">'; //MSD
            vLeftTable += '<p border=1 align=left style="BORDER-TOP: #efefef 1px solid; FONT-SIZE: 11px; BORDER-LEFT: #efefef 1px solid; height=18px; ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Display Format:';

            if (vFormatArr.join().indexOf("minute") != -1) {
                if (vFormat == 'minute') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="minute" checked>Minute';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("minute",' + vGanttVar + '); VALUE="minute">Minute';
            }

            if (vFormatArr.join().indexOf("hour") != -1) {
                if (vFormat == 'hour') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="hour" checked>Hour';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("hour",' + vGanttVar + '); VALUE="hour">Hour';
            }

            if (vFormatArr.join().indexOf("day") != -1) {
                if (vFormat == 'day') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="day" checked>Day';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("day",' + vGanttVar + '); VALUE="day">Day';
            }

            if (vFormatArr.join().indexOf("week") != -1) {
                if (vFormat == 'week') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="week" checked>Week';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("week",' + vGanttVar + ') VALUE="week">Week';
            }

            if (vFormatArr.join().indexOf("month") != -1) {
                if (vFormat == 'month') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="month" checked>Month';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("month",' + vGanttVar + ') VALUE="month">Month';
            }

            if (vFormatArr.join().indexOf("quarter") != -1) {
                if (vFormat == 'quarter') vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" VALUE="quarter" checked>Quarter';
					else vLeftTable += '<INPUT TYPE=RADIO NAME="radFormat" onclick=JSBaklog.changeFormat("quarter",' + vGanttVar + ') VALUE="quarter">Quarter';
            }

            vLeftTable += '</p></DIV></TD></TR></TBODY></TABLE>';
            vMainTable += vLeftTable;
            if (vDiv != null) $("#" + vDiv.id).html(vMainTable).css("margin", "0px auto");

            for (i = 0; i < vTaskList.length; i++) {
                if (vTaskList[i].getNotes() != '') {
                    $("#tnotes_" + vTaskList[i].getID()).addClass("extNotes").attr("title", vTaskList[i].getNotes());
                }

                switch (vTaskList[i].getFlagValue()) {
                    case 0:
                        {
                            flagClass = 'blank_indicator';
							titleMsg = '';
                            break;
                        }
                    case 1: // Deleted
                        {
                            flagClass = 'extDeltd';
							titleMsg = 'Story deleted from Product Backlog';
                            break;
                        }
                    case 2: // Completed
                        {
                            flagClass = 'extCompltd';
							titleMsg = 'Story released';
                            break;
                        }
                    case 3: // Some Progress
                        {
                            flagClass = 'extSprnt50';
							if (vTaskList[i].getID() != 1) titleMsg = 'Story development in progress';
								else titleMsg = 'Project development in progress';
                            break;
                        }
                    case 4: // In Sprint - no progress
                        {
                            flagClass = 'extSprnt0';
							titleMsg = 'Story included in sprint';
                            break;
                        }
                    case 5: // Completed, but not released
                        {
                            flagClass = 'extChngd';
							titleMsg = 'Story completed, not released';
                            break;
                        }
                    case 6: // Progress, but in past sprint
                        {
                            flagClass = 'extAside';
							titleMsg = 'Story progress in past sprint';
                            break;
                        }
                    case 7: // In Sprint - no progress
                        {
                            flagClass = 'extOnce';
							titleMsg = 'Story considered in previous sprint';
                            break;
                        }
						
                }
                $("#tconstr_" + vTaskList[i].getID()).addClass(flagClass);       
				if (titleMsg != '') $("#tconstr_" + vTaskList[i].getID()).attr("title", titleMsg);
				
				
				if (vTaskList[i].getTolnceNotes() != '') {
                    $("#twtnotes_" + vTaskList[i].getID()).attr("title", vTaskList[i].getTolnceNotes());
					$("#twtestm_" + vTaskList[i].getID()).attr("title", vTaskList[i].getTolnceNotes());
                }				

				if (vTaskList[i].getEstimateBasis() != '') {
                    $("#tEstmWrk_" + vTaskList[i].getID()).attr("title", vTaskList[i].getEstimateBasis());
                }				
				
                if (vTaskList[i].getNumDocs() > 0) {
                    $("#tattach_" + vTaskList[i].getID()).addClass("extAttach");
                }
				
				
				// HERE issues(challenges), crs(GTs)  getEstimateBasis
				
					//=================
				
				if (vTaskList[i].getTIssues() > 0) {	
					if (vTaskList[i].getOIssues() > 0) $("#tissue_" + vTaskList[i].getID()).addClass("opIssues").attr("title", "Total Challenges: "+vTaskList[i].getTIssues()+" and Active Challenges: "+vTaskList[i].getOIssues());
						else  $("#tissue_" + vTaskList[i].getID()).addClass("tlIssues").attr("title", "Total Challenges: "+vTaskList[i].getTIssues());
				}
				
				if (vTaskList[i].getTCRs() > 0) {	
					if (vTaskList[i].getOCRs() > 0) $("#tcrs_" + vTaskList[i].getID()).addClass("opCRs").attr("title", "Total GTs: "+vTaskList[i].getTCRs()+" and Active GTs: "+vTaskList[i].getOCRs());
						else  $("#tcrs_" + vTaskList[i].getID()).addClass("tlCRs").attr("title", "Total GTs: "+vTaskList[i].getTCRs());
				}
				
            }


            if ($("#Notes").length > 0) callRClick('Notes');
			if ($("#Registry").length > 0) callRClick('Registry');
            if ($("#ID").length > 0) callRClick('ID');
            if ($("#Tasks").length > 0) callRClick('Tasks');
            if ($("#Resource").length > 0) callRClick('Resource');
            if ($("#Progress").length > 0) callRClick('Progress');
            if ($("#AdjtEstimate").length > 0) callRClick('AdjtEstimate');
            if ($("#EstimateWork").length > 0) callRClick('EstimateWork');
			if ($("#ReleasedWork").length > 0) callRClick('ReleasedWork');
			if ($("#WorkTolerance").length > 0) callRClick('WorkTolerance');
			if ($("#Priority").length > 0) callRClick('Priority');
			if ($("#StoryNum").length > 0) callRClick('StoryNum');
			if ($("#StoryStatus").length > 0) callRClick('StoryStatus');
			if ($("#Priority").length > 0) callRClick('Priority');
			
            //MSD Change this to rightclick menu - cut-rename etc   
            if (procesMode == 0) {

				$("[id^='gntnode_']").not('#gntnode_1').contextMenu({
					menu: 'myMenuBaklog',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "pStory", "baklog"); // func in Gantt_Masters.js
				});
				
				$("#gntnode_1").contextMenu({
					menu: 'myMenuRootBaklog',
					elementID: 'context_main'
				}, function (action, el, pos) {

					actionAgileDevp(action, $(el).attr("id"), "pBaklog", "baklog"); // func in Gantt_Masters.js
				});

            }

            // to here ------------------------------------------------------------------------------------------------
        };
		return;
    }; //this.draw 

    function callRClick(aColID) {
        $("#" + aColID + "_h").rBakClickMenu({
            menu: 'BakColHideShow',
            elID: aColID
        }, function (action, status, elID) {
            if (action == 'update') {
                UpdateColsArray();
                setColumnPos(elID);
            } else {
                reDrawAgile();
            }
        });
        $("#" + aColID).rBakClickMenu({
            menu: 'BakColHideShow',
            elID: aColID
        }, function (action, status, elID) {
            if (action == 'update') {
                UpdateColsArray();
                setColumnPos(elID);
            } else {
                reDrawAgile();
            }
        });
    }

    this.mouseOver = function (pObj, pID, pPos, pType) {
        if (pPos == 'right') vID = 'child_' + pID;
        else vID = 'childrow_' + pID;

        pObj.bgColor = "#d5effc";
    };

    this.mouseOut = function (pObj, pID, pPos, pType) {
        if (pPos == 'right') vID = 'child_' + pID;
        else vID = 'childrow_' + pID;

        pObj.bgColor = "#ffffff"; // Row colors ---MSD
		if (pType == "group") {
			if (getOrigLink(pID) % 2 == 1) pObj.bgColor = "#ffffff";
			 else pObj.bgColor = "#eee";
			
		} else {

			if (getOrigLink(pID) % 2 == 1) pObj.bgColor = "#ffffff";
			 else pObj.bgColor = "#eee";
			
		}
    };

}; //GanttChart
JSBaklog.isIE = function () {

    if (typeof document.all != 'undefined') {
        return true;
    } else {
        return false;
    }
};

JSBaklog.processRows = function (pList, pID, pRow, pLevel, pOpen) {

    var vMinSet = 0;
    var vMaxSet = 0;
    var vList = pList;
    var vLevel = pLevel;
    var i = 0;
    var vNumKid = 0;
    var vCompSum = 0;
    var vVisible = pOpen;

    for (i = 0; i < pList.length; i++) {
        if (pList[i].getParent() == pID) {
            vVisible = pOpen;
            pList[i].setVisible(vVisible);
            if (vVisible == 1 && pList[i].getOpen() == 0) {
                vVisible = 0;
            }

            pList[i].setLevel(vLevel);
            vNumKid++;

            if (pList[i].getGroup() == 1) {
                JSBaklog.processRows(vList, pList[i].getID(), i, vLevel + 1, vVisible);
            };

            vCompSum += pList[i].getCompVal();

        }
    }

    if (pRow >= 0) {
        pList[pRow].setNumKid(vNumKid);
        pList[pRow].setCompVal(Math.ceil(vCompSum / vNumKid));
    }

};



JSBaklog.findObj = function (theObj, theDoc)
{
    var p, i, foundObj;
    if (!theDoc) {
        theDoc = document;
    }
    if ((p = theObj.indexOf("?")) > 0 && parent.frames.length) {
        theDoc = parent.frames[theObj.substring(p + 1)].document;
        theObj = theObj.substring(0, p);
    }
    if (!(foundObj = theDoc[theObj]) && theDoc.all)
    {
        foundObj = theDoc.all[theObj];
    }

    for (i = 0; !foundObj && i < theDoc.forms.length; i++) {
        foundObj = theDoc.forms[i][theObj];
    }

    for (i = 0; !foundObj && theDoc.layers && i < theDoc.layers.length; i++) {
        foundObj = JSBaklog.findObj(theObj, theDoc.layers[i].document);
    }
    if (!foundObj && document.getElementById){
        foundObj = document.getElementById(theObj);
    }
    return foundObj;
};

JSBaklog.changeFormat = function (pFormat, ganttObj) {
    UpdateColsArray(); // Newly added -MSD
    if (ganttObj) {
        ganttObj.setFormat(pFormat);
        ganttObj.DrawDependencies();
    } else {
        alert('Chart undefined');
    };
};

JSBaklog.folder = function (pID, ganttObj) {
    var vList = ganttObj.getList();
    for (i = 0; i < vList.length; i++) {
        if (vList[i].getID() == pID) {
            if (vList[i].getOpen() == 1) {
                vList[i].setOpen(0);
                JSBaklog.hide(pID, ganttObj);
                $('#group_' + pID).removeClass('openGroup').addClass('closeGroup');
            } else {
                vList[i].setOpen(1);
                JSBaklog.show(pID, 1, ganttObj);
                $('#group_' + pID).removeClass('closeGroup').addClass('openGroup');
            }
        }
    }
};

JSBaklog.hide = function (pID, ganttObj) {
    var vList = ganttObj.getList();
    var vID = 0;

    for (var i = 0; i < vList.length; i++) {
        if (vList[i].getParent() == pID) {
            vID = vList[i].getID();
            JSBaklog.findObj('child_' + vID).style.display = "none";
            vList[i].setVisible(0);
            if (vList[i].getGroup() == 1) {
                JSBaklog.hide(vID, ganttObj);
            }
        }
    }
};

JSBaklog.show = function (pID, pTop, ganttObj) {
    var vList = ganttObj.getList();
    var vID = 0;

    for (var i = 0; i < vList.length; i++) {
        if (vList[i].getParent() == pID) {
            vID = vList[i].getID();
            if (pTop == 1) {
                if (JSBaklog.isIE()) { // IE;
                    if ($('#group_' + pID).hasClass('closeGroup')) {
                        JSBaklog.findObj('child_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                } else {
                    if ($('#group_' + pID).hasClass('closeGroup')) {
                        JSBaklog.findObj('child_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                }
            } else {
                if (JSBaklog.isIE()) { // IE;
                    if ($('#group_' + pID).hasClass('openGroup')) {
                        JSBaklog.findObj('child_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                } else {
                    if ($('#group_' + pID).hasClass('openGroup')) {
                        JSBaklog.findObj('child_' + vID).style.display = "";
                        vList[i].setVisible(1);
                    }
                }
            }

            if (vList[i].getGroup() == 1) {
                JSBaklog.show(vID, 0, ganttObj);
            }
        }
    }
};
JSBaklog.taskLink = function (pRef, pClickCol) {
	var jsProcessMode = 3;
	if (publicView == 0) jsProcessMode = procesMode;
	
    switch (jsProcessMode) {
    case 0:
        {
			var prjStatusStr = "";
			if ((prjStatus == 2) || (prjStatus == 4) || (prjStatus == 5)) {
				switch (prjStatus) {
					case 2:
						prjStatusStr = 'Completed';
						break;
					case 4:
						prjStatusStr = 'Cancelled';
						break;
					case 5:
						prjStatusStr = 'Locked';
						break;				
				}
				jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Edit the Story...','E');
			
			} else {
				var nodeinfo = getNodeInfo(pRef);
				selNodeData = pClickCol;
				selNodeType = 'nStory';
				jgfForms('BakStoryEdit', pRef, 'Edit Story...'); 
			}
            break;
        }
    case 1:
        {
            //alert(pRef + " -- " + pClickCol + " -- " + "Update");
			var prjStatusStr = "";
			if ((prjStatus == 0) || (prjStatus == 1) || (prjStatus == 3)) {
				var nodeinfo = getNodeInfo(pRef);
				/*
				
				
				
				*/
				
				if (parseInt(pRef) == 1) selNodeType = 'baklog';
				else selNodeType = 'nStory';
				selNodeData = pClickCol;
				if (parseInt(pRef) != 1) jgfForms('BakStoryUpdate', pRef, 'Update Story...');
			} else {
				switch (prjStatus) {
					case 2:
						prjStatusStr = 'Completed';
						break;
					case 4:
						prjStatusStr = 'Cancelled';
						break;
					case 5:
						prjStatusStr = 'Locked';
						break;				
				}
			
				jAlert('Project Status: <b>'+ prjStatusStr +'</b>. Cannot Update the Story...','E');
			
			}
            break;
        }

    case 2:
        {
            //alert(pRef + " -- " + pClickCol + " -- " + "View");
			var nodeinfo = getNodeInfo(pRef);
			/*
			
			
			*/
			
			if (parseInt(pRef) == 1) selNodeType = 'baklog';
			else selNodeType = 'nStory';
			selNodeData = pClickCol;
			if (parseInt(pRef) != 1) jgfForms('BakStoryView', pRef, 'View Story...');
            break;
        }

    };
	return true;
};

JSBaklog.getDispDepend = function (origDepend) {
    var dispDepend = '';

    if (origDepend != '') {

        var vDependStr = origDepend + '';
        var vDepList = vDependStr.split(',');
        var n = vDepList.length;

        for (var k = 0; k < n; k++) {

            var cTask = '';
            var zTask = '';
            var zDelay = '';
            if (vDepList[k].indexOf('-') != -1) {
                cTask = vDepList[k];
                cTask = cTask.split("-");
                zTask = cTask[0];
                zDelay = ' - ' + cTask[1];
            } else if (vDepList[k].indexOf('+') != -1) {
                cTask = vDepList[k];
                cTask = cTask.split("+");
                zTask = cTask[0];
                zDelay = ' + ' + cTask[1];
            } else zTask = vDepList[k];

            for (ik = 0; ik < prjkt.length; ik++) {
                if (prjkt[ik]['pID'] == parseInt(zTask)) vTask = prjkt[ik]['pLink'];
            }

            var vRelate = zTask.replace(/\d+/g, '');
            vDepList[k] = vTask + vRelate + zDelay;
        }
        dispDepend = vDepList.toString();
    }
    return dispDepend;
}




JSBaklog.resizePopup = function (elID) {
    var elemID = elID.split("_");
    var elID = elemID[0];
    if (elID == 'Notes') return;
	 else if (elID == 'Registry') return;
    var offset = $('#' + elID).offset(); 
    var elText = '';
    if (elID == 'StoryNum') elText = 'Story ID';
	else if (elID == 'WorkTolerance') elText = 'Work Tolerance';
	else if (elID == 'EstimateWork') elText = 'Estimate Work';
	else if (elID == 'ReleasedWork') elText = 'Released Work';
	else if (elID == 'AdjtEstimate') elText = 'Adjusted Estimate';
	else if (elID == 'Tasks') elText = 'Title';
	else if (elID == 'StoryStatus') elText = 'Status';
	else if (elID == 'Resource') elText = 'Estimators';
    else elText = elID; 

    $('.colmWidth').text(elText); 
	
	
	

    $('#colWSet').bPopup({
        onOpen: function () {
            if ($('#colmWidth').length != 0) $('#colmWidth').spinner({
                min: 10,
                max: 640,
                stepping: 5
            }).val(ColWidths[0][elID]); /* alert('onOpen fired'); */
        },
        onClose: function () {
            if ($('#colmWidth').length != 0) {
                if (parseInt($('#colmWidth').val()) > 10) ColWidths[0][elID] = parseInt($('#colmWidth').val());
            }
            reDrawAgile(); /* alert('onClose fired'); */
        },
        modal: true,
        modalColor: '#D3D3D3',
        position: [offset.left, offset.top],
        opacity: 0.3,
        positionStyle: 'fixed',
        fadeSpeed: 'fast',
        followSpeed: 1500,
        speed: 450 //transition: 'slideDown'
    }, function () { /* alert('Callback fired'); */
    });
	return false;
}


JSBaklog.formatDateStr = function (pDate, pFormatStr) {
    vYear4Str = pDate.getFullYear() + '';
    vYear2Str = vYear4Str.substring(2, 4);
    vMonthStr = (pDate.getMonth() + 1) + '';
    vDayStr = pDate.getDate() + '';

    var vDateStr = "";

    switch (pFormatStr) {
    case 'mm/dd/yyyy':
        return (vMonthStr + '/' + vDayStr + '/' + vYear4Str);
    case 'dd/mm/yyyy':
        return (vDayStr + '/' + vMonthStr + '/' + vYear4Str);
    case 'yyyy-mm-dd':
        return (vYear4Str + '-' + vMonthStr + '-' + vDayStr);
    case 'mm/dd/yy':
        return (vMonthStr + '/' + vDayStr + '/' + vYear2Str);
    case 'dd/mm/yy':
        return (vDayStr + '/' + vMonthStr + '/' + vYear2Str);
    case 'yy-mm-dd':
        return (vYear2Str + '-' + vMonthStr + '-' + vDayStr);
    case 'mm/dd':
        return (vMonthStr + '/' + vDayStr);
    case 'dd/mm':
        return (vDayStr + '/' + vMonthStr);
    }

};

JSBaklog.AddJSONTask = function (pGanttVar) {

    var n = prjkt.length; // the number of tasks. IE gets this right, but mozilla add extra ones (Whitespace)
	for (var i = 0; i < n; i++) {
        if (prjkt[i]["pID"] != 0) {
            var pID = prjkt[i]["pID"];
            var pName = prjkt[i]["pName"];
			var pActive = prjkt[i]["pActive"];
            var pLink = prjkt[i]["pLink"];
            var pMile = prjkt[i]["pMile"];
			var pBudgetWork = prjkt[i]["pBudgetWork"];
			var pEstimWork = prjkt[i]["pEstimWork"];
			var pRelsdWork = prjkt[i]["pRelWrk"];
            var pRes = prjkt[i]["pRes"];
			var pRole = prjkt[i]["pRole"];
            var pComp = prjkt[i]["pComp"];
            var pGroup = prjkt[i]["p-Group"];
            var pParent = prjkt[i]["pParent"];
            var pOpen = prjkt[i]["pOpen"];
            var pDepend = prjkt[i]["pDepend"];
            var pCaption = prjkt[i]["pCaption"];
            var pPriorty = prjkt[i]["priorty"];
            var pAdjEstWrk = prjkt[i]["pAdjEstWrk"];
            var pNotes = prjkt[i]["notes"];
            var pNumDocs = prjkt[i]["numDocs"];
			var ptIssues = prjkt[i]["ptIssues"];
			var poIssues = prjkt[i]["poIssues"];
			var ptCRs = prjkt[i]["ptCRs"];
			var poCRs = prjkt[i]["poCRs"];
			var pWorkTolnce = prjkt[i]["wr_tolerance"];
			var pWorkTolnceNotes = prjkt[i]["tolerance-desc"];
			var pEstimBasis = prjkt[i]["pEstimBasis"];
			var pStryNum = prjkt[i]["pStyNum"];
			var pStrySts = prjkt[i]["pStySts"];
			var pPriority = prjkt[i]["priorty-str"];
			var pFlagValue = prjkt[i]["flag-status"];
			var pColor = prjkt[i]["pColor"];
			
            pGanttVar.AddTaskItem(new JSBaklog.TaskItem(pID, pName, pLink, pMile, pRes, pComp, pGroup, pParent, pOpen, pDepend, pCaption, pRole, pEstimWork, pAdjEstWrk, pNotes, pNumDocs, ptIssues, poIssues, ptCRs, poCRs, pWorkTolnce, pWorkTolnceNotes, pStryNum, pStrySts, pPriority, pActive, pRelsdWork, pFlagValue, pColor, pEstimBasis));

        };
    }
};


JSBaklog.benchMark = function (pItem) {
    var vEndTime = new Date().getTime();
    alert(pItem + ': Elapsed time: ' + ((vEndTime - vBenchTime) / 1000) + ' seconds.');
    vBenchTime = new Date().getTime();
};