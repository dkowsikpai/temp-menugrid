$(function(){
	$("body").addClass('body-login').load("LoginData.html", function(responseText, statusText, xhr) {
		if ($.browser.msie) {
			$('.login_container').css({
				'margin-left' : -$('.login_container').outerWidth()/2,
				'margin-top' : -$('.login_container').outerHeight()/2
			}); 
		}
		$('#user-name-login').focus();
		event_binder();
		
		$(window).bind("capsOn", function(event) {
			if ($("#CapsSts").length) $("#CapsSts").css({"visibility":"visible"}).html("CAPS LOCK ON");
		});
		$(window).bind("capsOff", function(event) {
			if ($("#CapsSts").length) $("#CapsSts").css({"visibility":"hidden"}).html("off");
		});		
		$(window).capslockstate();
		
		jQuery(document).unbind("active.idleTimer").unbind("idle.idleTimer");
		$("#user-name-login").focus();
		if(statusText == "error") {
			alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
		}
	});
	
});