// jQuery Context Menu Plugin
//
// Version 1.01
//
// Cory S.N. LaViska
// A Beautiful Site (http://abeautifulsite.net/)
//
// More info: http://abeautifulsite.net/2008/09/jquery-context-menu-plugin/
//
// Terms of Use
//
// This plugin is dual-licensed under the GNU General Public License
//   and the MIT License and is copyright A Beautiful Site, LLC.
//
if(jQuery)( function() {
	$.extend($.fn, {
		
		rAglClickMenu: function(o, callback) {
			// Defaults
			if( o.menu == undefined ) return false;
			if( o.inSpeed == undefined ) o.inSpeed = 150;
			if( o.outSpeed == undefined ) o.outSpeed = 75;
			if( o.elID == undefined ) o.elID = '';

			// 0 needs to be -1 for expected results (no fade)
			if( o.inSpeed == 0 ) o.inSpeed = -1;
			if( o.outSpeed == 0 ) o.outSpeed = -1;
			// Loop each context menu
			$(this).each( function() {
				var el = $(this);
				var offset = $(el).offset();
				// Add contextMenu class
				$('#' + o.menu).addClass('rAglClickMenu');
				// Simulate a true right click
				$(this).mousedown( function(e) {
					var evt = e;
					evt.stopPropagation();
					//e.preventDefault();

					$(this).mouseup( function(e) {
						e.stopPropagation();
						//e.preventDefault();
						var srcElement = $(this);
						$(this).unbind('mouseup');
						if( evt.button == 2 ) {
							// Hide context menus that may be showing
							$(".rAglClickMenu").hide();
							
							// Get this context menu
							var menu = $('#' + o.menu);
							
							if( $(el).hasClass('disabled') ) return false;
							
							// Detect mouse position
							var d = {}, x, y;
							if( self.innerHeight ) {
								d.pageYOffset = self.pageYOffset;
								d.pageXOffset = self.pageXOffset;
								d.innerHeight = self.innerHeight;
								d.innerWidth = self.innerWidth;
							} else if( document.documentElement &&
								document.documentElement.clientHeight ) {
								d.pageYOffset = document.documentElement.scrollTop;
								d.pageXOffset = document.documentElement.scrollLeft;
								d.innerHeight = document.documentElement.clientHeight;
								d.innerWidth = document.documentElement.clientWidth;
							} else if( document.body ) {
								d.pageYOffset = document.body.scrollTop;
								d.pageXOffset = document.body.scrollLeft;
								d.innerHeight = document.body.clientHeight;
								d.innerWidth = document.body.clientWidth;
							}
							(e.pageX) ? x = e.pageX : x = e.clientX + d.scrollLeft;
							(e.pageY) ? y = e.pageY : y = e.clientY + d.scrollTop;
							
							if ($.browser.chrome) {
								if ((e.clientY + $('#' + o.menu).outerHeight()) > $(window).height()) y -= $('#' + o.menu).outerHeight() + 85;
								else y -= 10;
							} else {
								if ((e.clientY + $('#' + o.menu).outerHeight()) > $(window).height()) y -= $('#' + o.menu).outerHeight() + 50;
								else y -= 5;
							}
							
							/*if (o.elementID == '') {
								if ((e.clientX + $('#' + o.menu).outerWidth()) > $(window).width()) x -= $('#' + o.menu).outerWidth();
							} else {
								if ((e.clientX + $('#' + o.menu).outerWidth()) > ( $('#' + o.elementID).offset.left() + $('#' + o.elementID).innerWidth())) x -= $('#' + o.menu).outerWidth();
							} */
							if ((e.clientX + $('#' + o.menu).outerWidth()) > $(window).width()) x -= $('#' + o.menu).outerWidth();
								if ($.browser.chrome) {
									$(menu).css({ top: y, left: x }).fadeIn(o.inSpeed); 
								} else {
									$(menu).css({ top: y, left: x }).fadeIn(o.inSpeed); 
								}
							
							
							
							// Show the menu

$('input:checkbox[name=showCols]:checked').removeAttr('checked');
for(colC=0; colC<ColOrder.length; colC++){
	if (bakLogShow == 0) {
		if(ColOrder[colC] == 'Notes') $("input:checkbox[name=showCols][value=aglNotes]").attr("checked","checked");
			else if (ColOrder[colC] == 'Registry') $("input:checkbox[name=showCols][value=aglRegistry]").attr("checked","checked");
			else if (ColOrder[colC] == 'Tasks') $("input:checkbox[name=showCols][value='aglTasks']").attr("checked","checked");
			else if (ColOrder[colC] == 'Resource') $("input:checkbox[name=showCols][value='aglResource']").attr("checked","checked");
			else if (ColOrder[colC] == 'Duration') $("input:checkbox[name=showCols][value='aglDuration']").attr("checked","checked");
			else if (ColOrder[colC] == 'Cost') $("input:checkbox[name=showCols][value='aglCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'Progress') $("input:checkbox[name=showCols][value='aglProgress']").attr("checked","checked");
			else if (ColOrder[colC] == 'StartDate') $("input:checkbox[name=showCols][value='aglStartDate']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActStartDate') $("input:checkbox[name=showCols][value='aglActStartDate']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActEndDate') $("input:checkbox[name=showCols][value='aglActEndDate']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActDuration') $("input:checkbox[name=showCols][value='aglActDuration']").attr("checked","checked");
			else if (ColOrder[colC] == 'EndDate') $("input:checkbox[name=showCols][value='aglEndDate']").attr("checked","checked");
			else if (ColOrder[colC] == 'Predecessor') $("input:checkbox[name=showCols][value='aglPredecessor']").attr("checked","checked");
			else if (ColOrder[colC] == 'BudgetWork') $("input:checkbox[name=showCols][value='aglBudgetWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'EstimateWork') $("input:checkbox[name=showCols][value='aglEstimateWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'AdjtEstimate') $("input:checkbox[name=showCols][value='aglAdjtEstimate']").attr("checked","checked");
			else if (ColOrder[colC] == 'ID') $("input:checkbox[name=showCols][value='aglID']").attr("checked","checked");
			else if (ColOrder[colC] == 'Work') $("input:checkbox[name=showCols][value='aglWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'Constraints') $("input:checkbox[name=showCols][value='aglConstraints']").attr("checked","checked");
			else if (ColOrder[colC] == 'Priority') $("input:checkbox[name=showCols][value='aglPriority']").attr("checked","checked");
			else if (ColOrder[colC] == 'FixedCost') $("input:checkbox[name=showCols][value='aglFixedCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActFixedCost') $("input:checkbox[name=showCols][value='aglActFixedCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActualWork') $("input:checkbox[name=showCols][value='aglActualWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActualCost') $("input:checkbox[name=showCols][value='aglActualCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'ActWorkRatio') $("input:checkbox[name=showCols][value='aglActWorkRatio']").attr("checked","checked");
			else if (ColOrder[colC] == 'CtrlAccnt') $("input:checkbox[name=showCols][value='aglCtrlAccnt']").attr("checked","checked");
			else if (ColOrder[colC] == 'TotalCost') $("input:checkbox[name=showCols][value='aglTotalCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'TotalWork') $("input:checkbox[name=showCols][value='aglTotalWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'AdjustedCost') $("input:checkbox[name=showCols][value='aglAdjustedCost']").attr("checked","checked");
			else if (ColOrder[colC] == 'AdjustedWork') $("input:checkbox[name=showCols][value='aglAdjustedWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'WorkTolerance') $("input:checkbox[name=showCols][value='aglWorkTolerance']").attr("checked","checked");
			else if (ColOrder[colC] == 'ReleasedWork') $("input:checkbox[name=showCols][value='aglReleasedWork']").attr("checked","checked");
			else if (ColOrder[colC] == 'StoryStatus') $("input:checkbox[name=showCols][value='aglStoryStatus']").attr("checked","checked");

	}
}





							$(document).unbind('click');
							$(menu).css({ top: y, left: x }).fadeIn(o.inSpeed);
							// Hover events
							$(menu).find('A').mouseover( function() {
								$(menu).find('LI.hover').removeClass('hover');
								$(this).parent().addClass('hover');
							}).mouseout( function() {
								$(menu).find('LI.hover').removeClass('hover');
							});
							
							// Keyboard
							$(document).keypress( function(e) {
								switch( e.keyCode ) {
								/*	case 38: // up
										if( $(menu).find('LI.hover').size() == 0 ) {
											$(menu).find('LI:last').addClass('hover');
										} else {
											$(menu).find('LI.hover').removeClass('hover').prevAll('LI:not(.disabled)').eq(0).addClass('hover');
											if( $(menu).find('LI.hover').size() == 0 ) $(menu).find('LI:last').addClass('hover');
										}
									break;
									case 40: // down
										if( $(menu).find('LI.hover').size() == 0 ) {
											$(menu).find('LI:first').addClass('hover');
										} else {
											$(menu).find('LI.hover').removeClass('hover').nextAll('LI:not(.disabled)').eq(0).addClass('hover');
											if( $(menu).find('LI.hover').size() == 0 ) $(menu).find('LI:first').addClass('hover');
										}
									break;
									case 13: // enter
										$(menu).find('LI.hover A').trigger('click');
									break; */
									case 27: // esc
										$(document).trigger('click');
									break
								}
							}); 
							
							// When items are selected
							//$('#' + o.menu).find('A').unbind('click');
							$('#' + o.menu).find('LI:not(.disabled) A').click( function() {
								$(document).unbind('click').unbind('keypress');



								$(".rAglClickMenu").hide();







								// Callback
								//if( callback ) callback( $(this).attr('href').substr(1), $(srcElement), {x: x - offset.left, y: y - offset.top, docX: x, docY: y} );
								return false;
							}); 
							
							// Hide bindings
							setTimeout( function() { // Delay for Mozilla
								$(document).click( function() {
									$(document).unbind('click').unbind('keypress');
if( callback ) callback('update','',o.elID);
var selected = [];
//alert(AddPosition);
$("input:checkbox[name=showCols]:checked").each(function()
{
    selected.push($(this).val().substring(3));
});									
                                                      
var identified = '';
if (ColOrder.length > selected.length) {
	for (colC =0; colC<ColOrder.length; colC++) {
		identified = ColOrder[colC];
		var isElem = false;
		for(selC=0; selC<selected.length; selC++) {
			if(selected[selC] == identified) {
			 isElem = true;
			 break;
			}
		}
		if (isElem == false) break;
      }

      var newCol = [];
	for (colC =0; colC<ColOrder.length; colC++) {
		if (ColOrder[colC] != identified) newCol.push(ColOrder[colC]);
	}
	ColOrder = newCol;
	

} else if (ColOrder.length < selected.length) {
	//identified = 'Added';
	for (selC =0; selC<selected.length; selC++) {
		identified = selected[selC];
		var isElem = false;
		for(colC=0; colC<ColOrder.length; colC++) {
			if(ColOrder[colC] == identified) {
			 isElem = true;
			 break;
			}
		}
		if (isElem == false) break;
      }

	var newCol = [];
	
	for(colC=0; colC<ColOrder.length; colC++) {
		if (colC === AddPosition){
			
			newCol.push(identified);
			newCol.push(ColOrder[colC]);
		} else newCol.push(ColOrder[colC]);
	}
	ColOrder = newCol;

	


} else identified = 'No Change';
if( callback ) callback('redraw','redraw',o.elID);






                                                      $(menu).fadeOut(o.outSpeed);
									return false;
								});
							}, 0);
						}
					});
				});
				
				// Disable text selection
				if( $.browser.mozilla ) {
					$('#' + o.menu).each( function() { $(this).css({ 'MozUserSelect' : 'none' }); });
				} else if( $.browser.msie ) {
					$('#' + o.menu).each( function() { $(this).bind('selectstart.disableTextSelect', function() { return false; }); });
				} else {
					$('#' + o.menu).each(function() { $(this).bind('mousedown.disableTextSelect', function() { return false; }); });
				}
				// Disable browser context menu (requires both selectors to work in IE/Safari + FF/Chrome)
				$(el).add($('UL.rAglClickMenu')).bind('contextmenu', function() { return false; });
				
			});
			return $(this);
		}
		

		
	});
})(jQuery);