
user_previlege = 5; // set based on previlage of the user from project's tables.
hide_fins = 0;
hide_acts = 0;

currency = '';
projectCustomer_id = 0;
customer = '';
deliv_extns = 'txt';
weekEnds = [0,6];
HoliDays = [];
prjDtIn = 'mmddyyyy';
ganttDtIn = 'mm/dd/yyyy';
ganttDtOut = 'dd/mm/yyyy';
prjLockSts = 0;
prjNdaSts = 0;


prjAgility = 0;
prjSp2Hrs = 0;
prjSprDur = 1;
prjStartDt = '';
prjEndDt = '';			
prjAudit = 0;
prjStatus = 0;
prjPayment = 0;
prjPrgsLmt = -7;
hoursAday = 8; // for Effort column 
hoursAweek = 40;
daysAmonth = 20;

procesMode = 2; // Edit, update or view

bakLogShow = 0;
primeDispStak = 1;
primeDispTeam = 0;
WorkShow = 'H'; // for Effort column 
ProgressActual = 0;
RoleName = 0;

brow_height = 26;
brow_tuner = -1;

GroupClr = '000000';
NormClr = '343434';
MileClr = '00009b';
RGrpClr = '656565';
RTskClr = '9b9b9b';
StryClr = '545454';

gCmpClr = '343434';
gActClr = '303498';
gBakClr = '000000';
gRlsClr = '000000';

sgMode = 0; // show gantt , spreadsheet or both 
gtType = 0; // show day, week, month or quarter



ColGantter = ['ID','Notes','Registry','Tasks','StartDate','EndDate','Duration'];
ColAgiler = ['ID','Notes','Registry','Tasks','StoryStatus','BudgetWork','EstimateWork','Work','ReleasedWork','Resource'];
ColBaklog = ['ID','Notes','Registry','StoryNum','Tasks','Priority','StoryStatus','EstimateWork','ReleasedWork'];

ColOrder = ['ID','Notes','Tasks','StartDate','EndDate','Duration'];
ColWidths =[{'Screen': 2048,
				'ID': 30,
				'Notes': 15,
				'Tasks': 260,
				'StartDate': 80,
				'EndDate': 80,
				'Duration': 60,
				'Progress': 40,
				'Resource': 260,
				'Cost': 60,
				'Predecessor': 60,
				'BudgetWork': 120,
				'EstimateWork': 120,
				'AdjtEstimate': 120,
				'ReleasedWork': 120,
				'Work': 60,
				'Constraints': 190,
				'Priority': 30,
				'FixedCost': 60,
				'ActualWork': 60,
				'ActWorkRatio': 80,
				'CtrlAccnt': 160,
				'Registry': 20,
				'ActStartDate': 80,
				'ActEndDate': 80,
				'ActualCost': 60,
				'ActFixedCost': 90,
				'ActDuration': 60,
				'TotalCost': 60,
				'TotalWork': 60,
				'AdjustedCost': 60,
				'AdjustedWork': 60,
				'WorkTolerance': 120,
				'Status': 190,
				'StoryNum': 120,
				'StoryStatus': 120
				
			}];
AddPosition = 0;

prjktResRate = [];
prjkt = '';

selNodeData = '';
selNodeType = '';
selNodeID = 0;

//--------------------------------------------------------------------------------------------------
ResOrder =['ResName','TaskName','Contour','EstWork'];
ResWidths =[{'Screen': 2000,
			'ResName': 260,
			'TaskName': 260,
			'Contour':130,
			'EstWork': 130,
			'EstCost': 130,
			'rAdjWork': 130,
			'rAdjCost': 130
			}];
AddResPosition = 0; 
prjres = '';

SBSOrder =['StyID','StyTaskName','EstimWork','StyEstWork'];
SBSWidths =[{'Screen': 2000,
			'StyID': 120,
			'StyTaskName': 400,
			'EstimWork':130,
			'AdjustEstimWork':130,
			'StyEstWork': 130,
			'StyEstCost': 130,
			'StyAdjWork': 130,
			'StyAdjCost': 130,
			'StyFixedCost': 130,
			'StyActualWork': 130,
			'StyTotalWork': 130,
			'StyActFixedCost': 130,
			'StyActualCost': 130,
			'StyTotalCost': 130
			}];
AddSBSPosition = 0; 
prjsbs = '';


CAOrder =['CAName','caTaskName','caEstWork'];
CAWidths =[{'Screen': 2000,
			'CAName': 260,
			'caTaskName': 260,
			'caEstWork': 130,
			'caEstFCost': 130,
			'caEstCost': 130,
			'caAdjWork': 130,
			'caAdjCost': 130,
			'caActFCost': 130,
			'caActCost': 130,
			'caActWork': 130,
			'caTotCost': 130,
			'caTotWork': 130
			}];
AddCAPosition = 0; 
prjca = '';

//--------------------------------------------------------------------------------------------------

function checkWeekEnd(refDate) {
		var n = weekEnds.length;
		var isWkEnd = false;
		for (ji=0;ji<n; ji++){
			if(weekEnds[ji] == refDate.getDay()){
				isWkEnd = true;
				break;
			}
		}
return isWkEnd;
}

function checkHoliDay(aDate) {
	var rfDate = chgdateFormat(aDate);
	var isHlDay = false;
	var n = HoliDays.length;
	
	for (ji=0;ji<n; ji++){
		if(HoliDays[ji] == rfDate){
			isHlDay = true;
			break;
		}
	}
return isHlDay;
}

function chgdateFormat(d){
	date = d.getDate();
		date = date < 10 ? "0"+date : date;
	mon = d.getMonth()+1;
		mon = mon < 10 ? "0"+mon : mon;
	year = d.getFullYear();
	return (mon+"/"+date+"/"+year);
}

function getNodeID(taskLink) {
 
	for(i=0; i<prjkt.length; i++) {
		if (prjkt[i]['pLink'] == parseInt(taskLink)) alert(prjkt[i]['pID']);
	}

}


function getOrigLink(taskID) {
 
	for(i=0; i<prjkt.length; i++) {
		if (prjkt[i]['pID'] == parseInt(taskID)) {
			return prjkt[i]['pLink'];
		}
	}

}

function getNodeName(node_ID) {
	var node_Name = '';
	for (i=0; i< prjkt.length; i++) {
		if (parseInt(prjkt[i]["pID"]) == parseInt(node_ID))
			{
				node_Name = prjkt[i]["pName"];
				break;
			}
	}
	return node_Name;
}

function getNodeStart(node_ID) {
	var node_Start = '';
	for (i=0; i< prjkt.length; i++) {
		if (parseInt(prjkt[i]["pID"]) == parseInt(node_ID))
			{
				node_Start = prjkt[i]["pStart"];
				break;
			}
	}
	return node_Start;
}

function getNodeEnd(node_ID) {
	var node_End = '';
	for (i=0; i< prjkt.length; i++) {
		if (parseInt(prjkt[i]["pID"]) == parseInt(node_ID))
			{
				node_End = prjkt[i]["pEnd"];
				break;
			}
	}
	return node_End;
}


function getNodeInfo(node_ID) {
	var node_info = {
			"startdate": '',
			"enddate": '',
			"grptask": 0,
			"milestone": 0,
			"rTask": 0,
			"agile-type": 0,
			"notes-desc": '',
			"delivs": 0,
			"reviews": 0,
			"sCday": 0,
			"duration": 1,
			"progress": 0,
			"cost": 0,
			"ot_allowance": 0,
			"work_dur_link": 0,
			"ot_hours": 0,
			"work": 0,
			"ca": 1,
			"priorty": 500,
			"constrnt": 0,
			"constdate":'',
			"wr_tolerance": 0,
			"tolerance-desc": '',
			"update_allow": 0,
			"meetings": 0,
			"reports": 0,
			"budget-work": 0,
			"estimate-work":0,
			"estimate-fix":0,
			"parent-node": 1,
			"node-contour": 'P',
			"node-wRate": 0,
			"story-no":'-',
			"story-status": 0,
			"story-active": 0
			};
	for (i=0; i< prjkt.length; i++) {
		if (parseInt(prjkt[i]["pID"]) == parseInt(node_ID))
			{
				node_info["startdate"] = prjkt[i]["pStart"];
				node_info["enddate"] = prjkt[i]["pEnd"];
				node_info["grptask"] = prjkt[i]["p-Group"];
				node_info["milestone"] = prjkt[i]["pMile"];
				node_info["rTask"] = prjkt[i]["pRtask"];
				node_info["agile-type"] = prjkt[i]["pAgile"];
				node_info["notes-desc"] = prjkt[i]["notes-desc"];
				node_info["delivs"] = prjkt[i]["delivs"];
				node_info["reviews"] = prjkt[i]["reviews"];
				node_info["sCday"] = prjkt[i]["pCalDay"];
				node_info["duration"] = prjkt[i]["duration"];
				node_info["progress"] = prjkt[i]["pComp"];
				node_info["cost"] = prjkt[i]["pCost"];
				node_info["ot_allowance"] = prjkt[i]["ot_allowance"];
				node_info["work_dur_link"] = prjkt[i]["work_dur_link"];
				node_info["work"] = prjkt[i]["pWork"];
				node_info["ot_hours"] = prjkt[i]["ot_hours"];
				node_info["ca"] = prjkt[i]["ca"];
				node_info["priorty"] = prjkt[i]["priorty"];
				node_info["constrnt"] = prjkt[i]["constrnt"];
				if (prjkt[i]["constDate"] != '00/00/0000') node_info["constdate"] = prjkt[i]["constDate"];
				node_info["wr_tolerance"] = prjkt[i]["wr_tolerance"];
				node_info["tolerance-desc"] = prjkt[i]["tolerance-desc"];
				node_info["update_allow"] = prjkt[i]["update_allow"];
				node_info["meetings"] = prjkt[i]["pMeetings"];
				node_info["reports"] = prjkt[i]["pReports"];
				node_info["budget-work"] = prjkt[i]["pBudgetWork"];
				node_info["estimate-work"] = prjkt[i]["pEstimWork"];
				node_info["parent-node"] = prjkt[i]["pParent"];
				if (prjSp2Hrs > 0) node_info["estimate-fix"] = prjkt[i]["pFixEstWrk"] / prjSp2Hrs;
				node_info["node-contour"] = prjkt[i]["pWrkCntr"];
				node_info["node-wRate"] = prjkt[i]["pWrkRate"];
				node_info["story-no"] = prjkt[i]["pStyNum"];
				node_info["story-status"] = prjkt[i]["pStySts"];
				node_info["story-active"] = prjkt[i]["pActive"];
				
				break;
			}
	}
	//alert('frm: '+node_info["cost"]);
	return node_info;
}



function UpdateColsArray() {
	var nidCols = [];
	$('#tLeft th').each(function () {
		var headID = $(this).attr("id").split("_");
    		nidCols.push(headID[0]);
	});
	ColOrder = nidCols;
}

function setColumnPos(aCol) {
	for(colC =0; colC<ColOrder.length; colC++){
		if(ColOrder[colC] == aCol) AddPosition =colC;
	}
}

function DrawGantt() {
	g = new JSGantt.GanttChart('g',document.getElementById('GanttChartDIV'), 'day');
	g.setDateInputFormat(ganttDtIn);  // Set format of input dates ('mm/dd/yyyy', 'dd/mm/yyyy', 'yyyy-mm-dd')
	g.setDateDisplayFormat(ganttDtOut);
	g.setCaptionType('None');  // Set to Show Caption (None,Caption,Resource,Duration,Complete)
	if( g ) {
		JSGantt.AddJSONTask(g);
		g.Draw();	
		g.DrawDependencies(); 
		setIDclr();
		hide_upload_started();
	} else {
		alert("not defined");
	} 
} 

function reDrawGantt() {
	g = undefined;
	$("#GanttChartDIV").empty();
	g = new JSGantt.GanttChart('g',document.getElementById('GanttChartDIV'), 'day');
	g.setDateInputFormat(ganttDtIn);  // Set format of input dates ('mm/dd/yyyy', 'dd/mm/yyyy', 'yyyy-mm-dd')
	g.setDateDisplayFormat(ganttDtOut);
	g.setCaptionType('None');  // Set to Show Caption (None,Caption,Resource,Duration,Complete)
	if( g ) {
		JSGantt.AddJSONTask(g);
		g.Draw();
		g.DrawDependencies(); 
		setIDclr();
		hide_upload_started();
	} else {
		alert("not defined");
	} 
} 


function reDrawAgile() {
	g = undefined;
	$("#GanttChartDIV").empty();
	if (bakLogShow == 0) {
		g = new JSAgile.GanttChart('g',document.getElementById('GanttChartDIV'), 'day');
		g.setDateInputFormat(ganttDtIn);  // Set format of input dates ('mm/dd/yyyy', 'dd/mm/yyyy', 'yyyy-mm-dd')
		g.setDateDisplayFormat(ganttDtOut);
		g.setCaptionType('None');  // Set to Show Caption (None,Caption,Resource,Duration,Complete)
		if( g ) {
			JSAgile.AddJSONTask(g);
			g.Draw();
			setIDclr();
			hide_upload_started();
		} else {
			alert("not defined");
		} 
	} else {
		g = new JSBaklog.GanttChart('g',document.getElementById('GanttChartDIV'), 'day');
		if( g ) {
			JSBaklog.AddJSONTask(g);
			g.Draw();
			setIDclr();
			hide_upload_started();
		} else {
			alert("not defined");
		} 
	}	
} 


function setIDclr(){  //MSD ID background color
	$("[id^='gntnode_']").each(function(){
		var nodID = this.id.split("_");
		    nodLink = getOrigLink(parseInt(nodID[1]));
	 if (parseInt(nodLink)%2 == 0) $(this).addClass("idEven");
				else $(this).addClass("idOdd");
	 });
	$("[id^='gntMlnode_']").each(function(){
		var nodID = this.id.split("_");
		    nodLink = getOrigLink(parseInt(nodID[1]));
	 if (parseInt(nodLink)%2 == 0) $(this).addClass("idEven");
				else $(this).addClass("idOdd");
	 });
 
	$("[id^='gntRGnode_']").each(function(){
		var nodID = this.id.split("_");
		    nodLink = getOrigLink(parseInt(nodID[1]));
	 if (parseInt(nodLink)%2 == 0) $(this).addClass("idEven");
				else $(this).addClass("idOdd");
	 });
	 
	$("[id^='gntRTnode_']").each(function(){
		var nodID = this.id.split("_");
		    nodLink = getOrigLink(parseInt(nodID[1]));
	 if (parseInt(nodLink)%2 == 0) $(this).addClass("idEven");
				else $(this).addClass("idOdd");
	 });
}


function getEndDate(aDateStr, bDays){
	// Date String in mm/dd/yyyy format
	var bDate = new Date(Date.parse(aDateStr));
	var actDate = new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	var actEndDate =  new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	if (bDays > 1) {
		var ij = 1;
		while (ij<=bDays) { 
			if(checkWeekEnd(actEndDate) == true) actEndDate=new Date(actEndDate.getFullYear(),actEndDate.getMonth(),actEndDate.getDate()+1);
				else if(checkHoliDay(actEndDate) == true) actEndDate=new Date(actEndDate.getFullYear(),actEndDate.getMonth(),actEndDate.getDate()+1);
				else {
					actEndDate=new Date(actEndDate.getFullYear(),actEndDate.getMonth(),actEndDate.getDate()+1);
					ij++; 
				}
			}
		actEndDate=new Date(actEndDate.getFullYear(),actEndDate.getMonth(),actEndDate.getDate()-1);
	}
	var actMonth = actEndDate.getMonth()+1;
	//if (actEndDate.getMonth() < 10) actMonth = '0' + actMonth;
	var actDate = actEndDate.getDate();
	//if (actEndDate.getDate() < 10) actDate = '0' + actDate;
    return( actMonth +'/'+actDate+'/'+actEndDate.getFullYear() )
};

function getCalEndDate(aDateStr, cDays){
	// Date String in mm/dd/yyyy format
	var bDate = new Date(Date.parse(aDateStr));
	var actDate = new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	var actEndDate =  new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	if (cDays > 1) {
		actEndDate=new Date(actEndDate.getFullYear(),actEndDate.getMonth(),actEndDate.getDate()+cDays-1);
	}
	var actMonth = actEndDate.getMonth()+1;
	//if (actEndDate.getMonth() < 10) actMonth = '0' + actMonth;
	var actDate = actEndDate.getDate();
	//if (actEndDate.getDate() < 10) actDate = '0' + actDate;
    return( actMonth +'/'+actDate+'/'+actEndDate.getFullYear() )
};

function getBuzdays(sDate, eDate){

	//alert(sDate+' - '+ eDate);
	// Date Strings in mm/dd/yyyy format
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var aDate = tranformDate(sDate);
		else aDate = sDate;
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var bDate = tranformDate(eDate);
		else bDate = eDate;
	//alert(aDate+' - '+ bDate);
	aDate = new Date(Date.parse(aDate));
	bDate = new Date(Date.parse(bDate));
	 
	tmpPer =  Math.ceil((bDate - aDate) /  (24 * 60 * 60 * 1000) + 1);     // Cal Days ----   
	var bDays = 0;
	for (ij=0; ij<tmpPer; ij++) { 
		refDate = new Date(aDate.getFullYear(), aDate.getMonth(), aDate.getDate()+ij);
		if(checkWeekEnd(refDate) == false) {
			if(checkHoliDay(refDate) == false) bDays++;
		}
	}
	//alert(bDays);
	tmpPer = bDays; 
	return(tmpPer)
};

 function getCdays(sDate, eDate){
	// Date Strings in mm/dd/yyyy format
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var aDate = tranformDate(sDate);
		else aDate = sDate;
	if ((prjDtIn == 'dd/mm/yyyy') || (prjDtIn == 'ddmmyyyy') ) var bDate = tranformDate(eDate);
		else bDate = eDate;
	aDate = new Date(Date.parse(aDate));
	bDate = new Date(Date.parse(bDate));
	 
	tmpPer =  Math.ceil((bDate - aDate) /  (24 * 60 * 60 * 1000) + 1);     // Cal Days ----   
	return(tmpPer)
}; 
/*
function getUBNumber(aNumber){
	// Number decimal
	var aNum = parseFloat(aNumber).toFixed(2);
	var rNum = Math.round(aNum); 
	if (aNum > rNum) rNum++;
	return(rNum)
};
*/
function getStartDate(aDateStr, bDays){
	// Date String in mm/dd/yyyy format
	//alert(aDateStr);
	var bDate = new Date(Date.parse(aDateStr));
	var actDate = new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	var actStartDate =  new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	if (bDays > 1) {
		var ij = 1;
		while (ij<=bDays) { 
			if(checkWeekEnd(actStartDate) == true) actStartDate=new Date(actStartDate.getFullYear(),actStartDate.getMonth(),actStartDate.getDate()-1);
				else if(checkHoliDay(actStartDate) == true) actStartDate=new Date(actStartDate.getFullYear(),actStartDate.getMonth(),actStartDate.getDate()-1);
				else {
					actStartDate=new Date(actStartDate.getFullYear(),actStartDate.getMonth(),actStartDate.getDate()-1);
					ij++; 
				}
			}
		actStartDate=new Date(actStartDate.getFullYear(),actStartDate.getMonth(),actStartDate.getDate()+1);
	}
	var actMonth = actStartDate.getMonth()+1;
	//if (actStartDate.getMonth() < 10) actMonth = '0' + actMonth;
	var actDate = actStartDate.getDate();
	//if (actStartDate.getDate() < 10) actDate = '0' + actDate;
    return( actMonth +'/'+actDate+'/'+actStartDate.getFullYear() )
};

function getCalStartDate(aDateStr, cDays){
	// Date String in mm/dd/yyyy format
	var bDate = new Date(Date.parse(aDateStr));
	var actDate = new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	var actStartDate =  new Date(bDate.getFullYear(),bDate.getMonth(),bDate.getDate());
	if (cDays > 1) {
		actStartDate=new Date(actStartDate.getFullYear(),actStartDate.getMonth(),actStartDate.getDate()-cDays+1);
	}
	var actMonth = actStartDate.getMonth()+1;
	//if (actStartDate.getMonth() < 10) actMonth = '0' + actMonth;
	var actDate = actStartDate.getDate();
	//if (actStartDate.getDate() < 10) actDate = '0' + actDate;
    return( actMonth +'/'+actDate+'/'+actStartDate.getFullYear() )
};


