
(function($) {
	
	$.popgFLfrm = {
		
		// These properties can be read/written by accessing $.popgFLfrm.propertyName from your scripts at any time
		
		verticalOffset: -220,                // vertical offset of the dialog from center screen, in pixels
		horizontalOffset: 0,                // horizontal offset of the dialog from center screen, in pixels/
		repositionOnResize: false,           // re-centers the dialog on window resize
		overlayOpacity: .01,                // transparency level of overlay 
		overlayColor: '#B5B5B5',               // base color of overlay
		draggable: true,                    // make the dialogs draggable (requires UI Draggables plugin)
		okButton: '&nbsp;OK&nbsp;',         // text for the OK button
		savButton: '&nbsp;Save&nbsp;',
		delButton: '&nbsp;Delete&nbsp;',
		clrButton: '&nbsp;Clear&nbsp;',
		cancelButton: '&nbsp;Cancel&nbsp;', // text for the Cancel button
		cntrlFlg: false, 
		cnTxtHelp: -200,
		cnTxtHelpSid: false,
		styleIds: [],
		// Public methods
		
		GntTaskAdd: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskAdd';
			$.popgFLfrm.cnTxtHelp = 201;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskAdd', styles);
		},
		GntTaskMeeting: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskMeeting';
			$.popgFLfrm.cnTxtHelp = 202;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskMeeting', styles);
		},
		AglAddSprint: function(message, value, title, styles) {
			if( title == null ) title = 'AglAddSprint';
			$.popgFLfrm.cnTxtHelp = 203;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglAddSprint', styles);
		},
		BakStoryAdd: function(message, value, title, styles) {
			if( title == null ) title = 'BakStoryAdd';
			$.popgFLfrm.cnTxtHelp = 204;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'BakStoryAdd', styles);
		},
		BakStoryInsert: function(message, value, title, styles) {
			if( title == null ) title = 'BakStoryInsert';
			$.popgFLfrm.cnTxtHelp = 205;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'BakStoryInsert', styles);
		},
		GntTaskInsert: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskInsert';
			$.popgFLfrm.cnTxtHelp = 206;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskInsert', styles);
		},
		GntInsertMeeting: function(message, value, title, styles) {
			if( title == null ) title = 'GntInsertMeeting';
			$.popgFLfrm.cnTxtHelp = 207;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntInsertMeeting', styles);
		},
		AglInsertSprint: function(message, value, title, styles) {
			if( title == null ) title = 'AglInsertSprint';
			$.popgFLfrm.cnTxtHelp = 208;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglInsertSprint', styles);
		},
		GntTaskEdit: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskEdit';
			$.popgFLfrm.cnTxtHelp = 209;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskEdit', styles);
		},
		GntEditMeeting: function(message, value, title, styles) {
			if( title == null ) title = 'GntEditMeeting';
			$.popgFLfrm.cnTxtHelp = 210;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntEditMeeting', styles);
		},
		AglEditSprint: function(message, value, title, styles) {
			if( title == null ) title = 'AglEditSprint';
			$.popgFLfrm.cnTxtHelp = 211;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglEditSprint', styles);
		},
		BakStoryEdit: function(message, value, title, styles) {
			if( title == null ) title = 'BakStoryEdit';
			$.popgFLfrm.cnTxtHelp = 212;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'BakStoryEdit', styles);
		},
		BakStoryUpdate: function(message, value, title, styles) {
			if( title == null ) title = 'BakStoryUpdate';
			$.popgFLfrm.cnTxtHelp = 213;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'BakStoryUpdate', styles);
		},
		BakStoryView: function(message, value, title, styles) {
			if( title == null ) title = 'BakStoryView';
			$.popgFLfrm.cnTxtHelp = 214;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'BakStoryView', styles);
		},
		GntResourceUsage: function(message, value, title, styles) {
			if( title == null ) title = 'GntResourceUsage';
			$.popgFLfrm.cnTxtHelp = 215;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'GntResourceUsage', styles);
		},
		GntCAUsage: function(message, value, title, styles) {
			if( title == null ) title = 'GntCAUsage';
			$.popgFLfrm.cnTxtHelp = 216;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'GntCAUsage', styles);
		},
		GntTaskUpdate: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskUpdate';
			$.popgFLfrm.cnTxtHelp = 217;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskUpdate', styles);
		},
		GntTaskView: function(message, value, title, styles) {
			if( title == null ) title = 'GntTaskView';
			$.popgFLfrm.cnTxtHelp = 218;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'GntTaskView', styles);
		},
		StakeGeneralView: function(message, value, title, styles) {
			if( title == null ) title = 'StakeGeneralView';
			$.popgFLfrm.cnTxtHelp = -219;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'StakeGeneralView', styles);
		},
		ConsultantView: function(message, value, title, styles) {
			if( title == null ) title = 'ConsultantView';
			$.popgFLfrm.cnTxtHelp = -220;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'ConsultantView', styles);
		},
		RskRegCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'RskRegCommentView';
			$.popgFLfrm.cnTxtHelp = -221;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'RskRegCommentView', styles);
		},
		IsuRegCommentView: function(message, value, title, styles) {
			if( title == null ) title = 'IsuRegCommentView';
			$.popgFLfrm.cnTxtHelp = -222;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'IsuRegCommentView', styles);
		},
		SponsorRegisterView: function(message, value, title, styles) {
			if( title == null ) title = 'SponsorRegisterView';
			$.popgFLfrm.cnTxtHelp = -223;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'SponsorRegisterView', styles);
		},
		ProjectDetailsView: function(message, value, title, styles) {
			if( title == null ) title = 'ProjectDetailsView';
			$.popgFLfrm.cnTxtHelp = -224;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'ProjectDetailsView', styles);
		},
		ProjectBacklog: function(message, value, title, styles) {
			if( title == null ) title = 'ProjectBacklog';
			$.popgFLfrm.cnTxtHelp = 225;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'ProjectBacklog', styles);
		},
		AglPullStory: function(message, value, title, styles) {
			if( title == null ) title = 'AglPullStory';
			$.popgFLfrm.cnTxtHelp = 226;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglPullStory', styles);
		},
		AglInsertStory: function(message, value, title, styles) {
			if( title == null ) title = 'AglInsertStory';
			$.popgFLfrm.cnTxtHelp = 227;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglInsertStory', styles);
		},
		AglEditStory: function(message, value, title, styles) {
			if( title == null ) title = 'AglEditStory';
			$.popgFLfrm.cnTxtHelp = 228;
			$.popgFLfrm.cnTxtHelpSid = true;
			$.popgFLfrm._create(title, message, value, 'AglEditStory', styles);
		},
		GntStoryUsage: function(message, value, title, styles) {
			if( title == null ) title = 'GntStoryUsage';
			$.popgFLfrm.cnTxtHelp = 229;
			$.popgFLfrm.cnTxtHelpSid = false;
			$.popgFLfrm._create(title, message, value, 'GntStoryUsage', styles);
		},
		
		// Private methods     
		
		_create: function(title, msg, value, type, styles) {
			
			if (styles != undefined) $.popgFLfrm.styleIds = styles.split('|');
			if (($.popgFLfrm.styleIds[0] == undefined) || ($.popgFLfrm.styleIds[0] == '')) {
				$.popgFLfrm._hide();
				//$.popgFLfrm._overlay('show');
				$("BODY").append(
				  '<div id="gFform_container" style="display: none;">' +
					'<h1 id="gFform_title"></h1>' +
					'<div id="gFLform_errors" style="display: none;"><div class="error_title">ERRORS:</div></div>' +
					'<div id="gFform_content">' +
					  '<div id="gFform_message"></div>' +
					'</div>' +
				  '</div>');
				//$("BODY").css("overflow", "hidden");
				$("html, body").animate({ scrollTop: 0 }, "slow");
				
				// IE6 Fix
				var pos = ($.browser.msie && parseInt($.browser.version) <= 6 ) ? 'absolute' : 'fixed'; 
				
				$("#gFform_container").css({
					position: pos,
					zIndex: 4569,
					padding: 0,
					margin: 0
				});
				$("#gFform_content").css({
					"min-width": '99.8%',
					"max-height": $(window).outerHeight( true ) - $('.fix_header_class').outerHeight( true ),
					"overflow-y": "auto"
				}); 
				$("#gFform_title").text(title).append('<div id="gFLform_errors_ico" class="navButtonSz errorButton" style="display: none;" onclick="$.popgFLfrm._errbox();" title="Show/hide error messages">&nbsp;&nbsp;</div>');
				/*
					.append('<div class="navButtonSz backButton" onclick="$.popgFLfrm._hide();">&nbsp;&nbsp;</div>')
					.append('<div id="fl_bak_hom_bt" class="navButtonSz homeButton" onclick="$.popgFLfrm._home();">&nbsp;&nbsp;</div>')
					.append('<div id="fl_hlp_bt" class="navButtonSz helpButton" style="display: none;" onclick="$.popgFLfrm._help();">&nbsp;&nbsp;</div>')
					
				*/	
				$("#gFform_content").addClass(type);
				$("#gFform_message").text(''); // msg
				$("#gFform_message").html( $("#gFform_message").text().replace(/\n/g, '<br />') );
				
				$("#gFform_container").css({
					minWidth: '99.8%',
					height: $(window).outerHeight( true ) - $('.fix_header_class').outerHeight( true ) + 20
				});
				
				$.popgFLfrm._reposition();
				$.popgFLfrm._maintainPosition(true);
			}  else  $("#"+$.popgFLfrm.styleIds[0]).empty();
			
			switch( type ) {
				case 'GntTaskAdd': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										if (prjAgility == 0) {
											$("#gFform_division").load("Gantt_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
												hide_upload_started(); 
												//var msgid = $("#gFform_division [id$='-message-box']").attr('id');
												//alert(msgid);
												TaskController(value, 'add');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
												
											});
										} else {
											$("#gFform_division").load("Agile_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
												hide_upload_started(); 
												$("#tab_advanced, #gTaskType").css("display", "none");
												$('#gnt-task-type option[value="0"]').attr("selected","selected");
												$("#tab_dates").css("display", "block");
												TaskController(value, 'add');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
												
											});
										}
										
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskAddIns('add'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntTaskMeeting': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_dates, #tab_advanced, #tab_resources, #gTaskType, #gTaskNonRecur").css("display", "none");
											$('#gnt-task-type option[value="2"]').attr("selected","selected");
											$("#gTaskRecur").css("display", "block");
											TaskController(value, 'add');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskAddIns('add'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'AglAddSprint': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddProjectSprint", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											TaskController(value, 'addsprint');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitSprintAddIns('addsprint'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'BakStoryAdd': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddBaklogStory", function(responseText, statusText, xhr) {
											$("#tab_cost, #tab_predecessor, #sty-edit-docs").css("display", "none");
											hide_upload_started(); 
											TaskController(value, 'addbakstory');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitBakStoryAddIns('addbakstory'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'BakStoryInsert': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddBaklogStory", function(responseText, statusText, xhr) {
											$("#tab_cost, #tab_predecessor, #sty-edit-docs").css("display", "none");
											hide_upload_started(); 
											TaskController(value, 'insertbakstory');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitBakStoryAddIns('insertbakstory'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'BakStoryEdit': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gFform_del"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddBaklogStory", function(responseText, statusText, xhr) {
											$("#tab_cost, #tab_predecessor, #tab_advanced, #sty-edit-docs").css("display", "block");
											if (value == 1) {
												$("#tab_dates, #gFform_del, #Not-for-1").css("display", "none");
											} else {
												$("#tab_dates, #Not-for-1").css("display", "block");
												$("#gFform_del").css("display", "inline-block");
											}	
											hide_upload_started(); 
											TaskController(value, 'editbakstory');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						//alert('clicked');
						submitBakStoryEdit(val); 
					});
					$("#gFform_del").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitBakStoryDelete(val); 
					}); 
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'BakStoryUpdate': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#UpdateBacklogStory").remove();
										$("#gFform_division").load("Agile_Masters.html #UpdateBacklogStory", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											BacklogUpdator(value);
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});										
										
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						//alert('clicked');
						submitBakStoryUpdate(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'BakStoryView': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#ViewBacklogStory").remove();
										$("#gFform_division").load("Agile_Masters.html #ViewBacklogStory", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											BacklogViewer(value);
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});										
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntTaskInsert': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
					
										show_upload_started();
										if (prjAgility == 0) {
											$("#gFform_division").load("Gantt_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
												hide_upload_started(); 
												TaskController(value, 'insert');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										} else {
											$("#gFform_division").load("Agile_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
												hide_upload_started();
												$("#tab_advanced, #gTaskType").css("display", "none");
												$('#gnt-task-type option[value="0"]').attr("selected","selected");
												$("#tab_dates").css("display", "block");
												TaskController(value, 'insert');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										}
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskAddIns('insert'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'GntInsertMeeting': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddProjectTask", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_dates, #tab_advanced, #tab_resources, #gTaskType, #gTaskNonRecur").css("display", "none");
											$('#gnt-task-type option[value="2"]').attr("selected","selected");
											$("#gTaskRecur").css("display", "block");
											TaskController(value, 'insert');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskAddIns('insert'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'AglInsertSprint': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddProjectSprint", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											TaskController(value, 'insertsprint');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitSprintAddIns('insertsprint'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntTaskEdit': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gFform_del"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										if (prjAgility == 0) {
											$("#gFform_division").load("Gantt_Masters.html #EditProjectTask", function(responseText, statusText, xhr) {
												hide_upload_started(); 
												if (parseInt(value) == 1) $("#gFform_del").css("display","none");
												TaskController(value, 'edit');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										} else {
											$("#gFform_division").load("Agile_Masters.html #EditProjectTask", function(responseText, statusText, xhr) {
												$("#tab_advanced, #gTaskType").css("display", "none");
												$('#gnt-task-type option[value="0"]').attr("selected","selected");
												$("#tab_dates").css("display", "block");
												hide_upload_started(); 
												if (parseInt(value) == 1) $("#gFform_del").css("display","none");
												TaskController(value, 'edit');
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										}
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						//alert('clicked');
						submitTaskEdit(val); 
					});
					$("#gFform_del").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskDelete(val); 
					}); 
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntEditMeeting': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.delButton + '" id="gFform_del"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #EditProjectTask", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											if (parseInt(value) == 1) $("#gFform_del").css("display","none");
											$("#tab_dates, #tab_advanced, #tab_resources, #gTaskType, #gTaskNonRecur").css("display", "none");
											$('#gnt-task-type option[value="2"]').attr("selected","selected");
											$("#gTaskRecur").css("display", "block");
											TaskController(value, 'edit');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
										});
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						//alert('clicked');
						submitTaskEdit(val); 
					});
					$("#gFform_del").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskDelete(val); 
					}); 
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'AglEditSprint': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #EditProjectSprint", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											TaskController(value, 'editsprint');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitSprintEdit(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntResourceUsage': {
					$("#gFform_message").append('<input type="text"  id="rgs-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"  style="margin: 0px auto;"></div');
							
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="Print" id="gFform_prn"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
							
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#ProjectResourceUse").remove();
										exclude_script('js/rbsgantt.js', "js");
										exclude_script('js/jquery.rbsgantt.js', "js");
										exclude_script('js/jquery.rRBSClickMenu.js', "js"); 
										
										$.when(
											$.getScript( 'js/rbsgantt.js' ),
											$.getScript( 'js/jquery.rbsgantt.js' ),
											$.getScript( 'js/jquery.rRBSClickMenu.js' ),
											$.Deferred(function( deferred ){
												$( deferred.resolve );
											})
										)
										.done(function(){
											$("#gFform_division").load("Gantt_Masters.html #ProjectResourceUse", function(responseText, statusText, xhr) {
												if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$("input:checkbox[name=showResCols][value=EstCost]").attr('disabled', 'disabled');
													$('.HideFinanceMenu').css("display","none");
												} else if ((user_profile == 'stake') && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$('.HideActualsMenu').css("display","none");
												}
												
												$.popgFLfrm._show();
												
												$.ajax({
													url: "phpGanttLoad.php",
													type: 'POST',
													data: {"page": "gantt-resusage", 
															"project-id": $('#gantt-select-devp').val(), 
															"user-id": user_id, 
															"user-profile": user_profile,
															"user-previlege": user_previlege,
															"user-public": publicView
													},
													timeout: xhr_timeout,
													error: function () {
														hide_all_errors();
														hide_upload_started();
														jAlert('Could not connect to server...','T');
													},
													success: function(response) {
														hide_all_errors();
														hide_upload_started();
														prjres = jQuery.parseJSON(response);
														reDrawRBS(); 
													}
												});
												
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										})
										.fail(function( jqxhr, settings, exception ) {
											jAlert('Could not load script !', 'E');
										}); 
										
					$("#gFform_prn").click( function() {
						var val = $('#rgs-entity-id-edit').val();
						//alert('clicked');
						$('#ResHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS split-up properly */
						PrintResourceUsage(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$('#ResHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS split-up properly */
						$("#ProjectResourceUse").remove();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntCAUsage': {
					$("#gFform_message").append('<input type="text"  id="cas-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
									
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="Print" id="gFform_prn"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
									
										show_upload_started();
										$("#ProjectCAUse").remove();
										exclude_script('js/cagantt.js', "js");
										exclude_script('js/jquery.cagantt.js', "js");
										exclude_script('js/jquery.rCAClickMenu.js', "js"); 
										
										$.when(
											$.getScript( 'js/cagantt.js' ),
											$.getScript( 'js/jquery.cagantt.js' ),
											$.getScript( 'js/jquery.rCAClickMenu.js' ),
											$.Deferred(function( deferred ){
												$( deferred.resolve );
											})
										)
										.done(function(){
											$("#gFform_division").load("Gantt_Masters.html #ProjectCAUse", function(responseText, statusText, xhr) {
												if ((user_profile == 'stake') || (user_profile == 'proposal')){
													$('.HideStakeMenu').css("display","none");
												}			
												if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$('.HideFinanceMenu').css("display","none");
												} else if (((user_profile == 'stake') || (user_profile == 'proposal')) && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$('.HideActualsMenu').css("display","none");
												}
												
												$.popgFLfrm._show();
												$.ajax({
													url: "phpGanttLoad.php",
													type: 'POST',
													data: {"page": "gantt-causage", 
															"project-id": $('#gantt-select-devp').val(), 
															"user-id": user_id, 
															"user-profile": user_profile,
															"user-previlege": user_previlege,
															"user-public": publicView
													},
													timeout: xhr_timeout,
													error: function () {
														hide_all_errors();
														hide_upload_started();
														jAlert('Could not connect to server...','T');
													},
													success: function(response) {
														hide_all_errors();
														hide_upload_started();
														prjca = jQuery.parseJSON(response);
														reDrawCA(); 
													}
												});
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
											
										})
										.fail(function( jqxhr, settings, exception ) {
											jAlert('Could not load script !', 'E');
										}); 
					$("#gFform_prn").click( function() {
						var val = $('#cas-entity-id-edit').val();
						//alert('clicked');
						$('#CAHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS split-up properly */
						PrintCABreakdown(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$('#CAHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS split-up properly */
						$("#ProjectCAUse").remove();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'GntTaskUpdate': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										
										
										show_upload_started();
										$("#UpdateProjectTask").remove();
										$("#gFform_division").load("Gantt_Masters.html #UpdateProjectTask", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											TaskUpdator(value);
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitTaskUpdate(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntTaskView': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#UpdateProjectView").remove();
										$("#gFform_division").load("Gantt_Masters.html #UpdateProjectView", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											TaskViewer(value);
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						selNodeData = '';
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'StakeGeneralView': {
					$("#gFform_message").append('<input type="text"  id="StakeGeneralView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
					
										show_upload_started();
										$("#GeneralStakeholderView").remove();
										$("#gFform_division").load("Business_Masters.html #GeneralStakeholderView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popGeneralStakeholderView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'ConsultantView': {
					$("#gFform_message").append('<input type="text"  id="ConsultantView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										show_upload_started();
										$("#ConsultantsView").remove();
										$("#gFform_division").load("Company_Masters.html #ConsultantsView", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											hide_upload_started(); 
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popConsultantsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'RskRegCommentView': {
					$("#gFform_message").append('<input type="text"  id="RskRegCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#RskRegComments").remove();
										$("#gFform_division").load("General_Services.html #RskRegComments", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popRskRegCommentsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'IsuRegCommentView': {
					$("#gFform_message").append('<input type="text"  id="IsuRegCommentView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#IsuRegComments").remove();
										$("#gFform_division").load("General_Services.html #IsuRegComments", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popIsuRegCommentsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'SponsorRegisterView': {
					$("#gFform_message").append('<input type="text"  id="SponsorRegisterView-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');						
										show_upload_started();
										$("#SponsorDetails").remove();
										$("#gFform_division").load("General_Services.html #SponsorDetails", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popSponsorDetailsView();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'ProjectDetailsView': {
				
					if (($.popgFLfrm.styleIds[0] == undefined) || ($.popgFLfrm.styleIds[0] == '')) {
						$("#gFform_message").append('<input type="text"  id="gantt-select-devp" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#gFform_message").append('<br /><div id="gFform_division"></div');
						$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');					
					} else {
						$("#"+$.popgFLfrm.styleIds[0]).empty();
						$("#"+$.popgFLfrm.styleIds[0]).append('<input type="text"  id="gantt-select-devp" name="field-edit" style="display:none" value="'+value+'"/>');
						$("#"+$.popgFLfrm.styleIds[0]).append('<br /><div id="gFform_division"></div');
						$("#"+$.popgFLfrm.styleIds[0]).css({
								// "margin-top": "-8px",
								 "height": ($(window).outerHeight( true ) - $('.fix_header_class').outerHeight( true ))  + 'px'
							});
					
					}
				
										show_upload_started();
										$("#wk0ProjectDetails").remove();
										$("#gFform_division").load("General_Services.html #wk0ProjectDetails", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													popProjectDetailsDisp();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'ProjectBacklog': {
					$("#gFform_message").append('<input type="text"  id="gantt-select-devp" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="OK" id="gFform_cancel"  class="button gray smlbut"/></div><br />');					
										show_upload_started();
										$("#ProjectBacklog").remove();
										$("#gFform_division").load("General_Services.html #ProjectBacklog", function(responseText, statusText, xhr) {
											exclude_script('js/jquery.Service_Forms.js', "js");
											$.getScript( 'js/jquery.Service_Forms.js' )
												.done(function( script, textStatus ) {
													$.popgFLfrm.cntrlFlg = true;
													popProjectBacklog();
												})
												.fail(function( jqxhr, settings, exception ) {
													jAlert('Could not load script !', 'E');
												});	 
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												exclude_script('js/jquery.Service_Forms.js', "js");
											}
											
										});
					
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
						//filter_key = undefined;
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'AglPullStory': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');										
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddSprintStory", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											TaskController(value, 'pullstory');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitStoryPullIns('pullstory'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'AglInsertStory': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');										
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #AddSprintStory", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											TaskController(value, 'insertstory');
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						submitStoryPullIns('insertstory'); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}
				case 'AglEditStory': {
					$("#gFform_message").append('<input type="text"  id="div-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="' + $.popgFLfrm.savButton + '" id="gFform_sav"  class="button gray smlbut"/> <input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');										
										show_upload_started();
										$("#gFform_division").load("Agile_Masters.html #EditProjectStory", function(responseText, statusText, xhr) {
											hide_upload_started(); 
											$("#tab_advanced, #gTaskType, #gTaskNonRecur").css("display", "none");
											//$('#gnt-task-type option[value="2"]').attr("selected","selected");
											//$("#gTaskRecur").css("display", "block");
											if (parseInt(value) != 1) $("#agile-story-node").css("display", "block"); // #tab_resources, 
												else $("#agile-project-node").css("display", "block");
											TaskController(value, 'editstory'); // Common for Story and Node 1
											if(statusText == "error") {
												alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
											}
											
										});
										
					
					$("#gFform_sav").click( function() {
						var val = $('#div-entity-id-edit').val();
						if (parseInt(val) != 1) submitAglStoryEdit(val);
							else submitAglNode1Edit(val);
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				case 'GntStoryUsage': {
					$("#gFform_message").append('<input type="text"  id="rgs-entity-id-edit" name="field-edit" style="display:none" value="'+value+'"/>');
					$("#gFform_message").append('<br /><div id="gFform_division"></div');
					$("#gFform_container").append('<div id="gFform_panel"><input type="button" value="Print" id="gFform_prn"  class="button gray smlbut"/><input type="button" value="' + $.popgFLfrm.cancelButton + '" id="gFform_cancel"  class="button gray smlbut"/></div><br />');
										
										show_upload_started();
										//load_script("css/Masters.css", "css");
										$("#ProjectStoryList").remove();
										exclude_script('js/sbsgantt.js', "js");
										exclude_script('js/jquery.sbsgantt.js', "js");
										exclude_script('js/jquery.rSBSClickMenu.js', "js"); 
										
										$.when(
											$.getScript( 'js/sbsgantt.js' ),
											$.getScript( 'js/jquery.sbsgantt.js' ),
											$.getScript( 'js/jquery.rSBSClickMenu.js' ),
											$.Deferred(function( deferred ){
												$( deferred.resolve );
											})
										)
										.done(function(){
											$("#gFform_division").load("Gantt_Masters.html #ProjectStoryList", function(responseText, statusText, xhr) {
												if ((user_profile == 'project') && (hide_fins == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$("input:checkbox[name=showResCols][value=EstCost]").attr('disabled', 'disabled');
													$('.HideFinanceMenu').css("display","none");
												} else if ((user_profile == 'stake') && (hide_acts == 1) && ((user_previlege == 1) || (user_previlege == 2))) {
													$('.HideActualsMenu').css("display","none");
												}
												
												$.popgFLfrm._show();
												
												$.ajax({
													url: "phpAgileLoad.php",
													type: 'POST',
													data: {"page": "gantt-storyusage", 
														"project-id": $('#gantt-select-devp').val(), 
														"user-id": user_id, 
														"user-profile": user_profile,
														"user-previlege": user_previlege,
														"user-public": publicView
													},
													timeout: xhr_timeout,
													error: function () {
														hide_all_errors();
														hide_upload_started();
														jAlert('Could not connect to server...','T');
													},
													success: function(response) {
														
														hide_all_errors();
														hide_upload_started();
														prjsbs = jQuery.parseJSON(response);
														reDrawSBS(); 
													}
												});
												
												if(statusText == "error") {
													alert("An error occurred: " + xhr.status + " - " + xhr.statusText);
												}
											});
										})
										.fail(function( jqxhr, settings, exception ) {
											jAlert('Could not load script !', 'E');
										}); 
										
					$("#gFform_prn").click( function() {
						var val = $('#rgs-entity-id-edit').val();
						//alert('clicked');
						$('#SBSHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS or SBS split-up properly */
						PrintStoryBreakList(val); 
					});
					$("#gFform_cancel").click( function() {
						hide_all_errors();
						$('#SBSHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS or SBS split-up properly */
						$("#ProjectStoryList").remove();
						$.popgFLfrm._hide();
					});
					if( value ) $("#gFform_division").val(value);
					$("#gFform_division").focus().select();
					break;
				}	
				
				
				
				
				
				
				
				
				
				
				/* next case here   */ 
				
				
			}
			// Make draggable
			if( $.popgFLfrm.draggable ) {
				try {
					$("#gFform_container").draggable({ handle: $("#gFform_title") });
					$("#gFform_title").css({ cursor: 'move' });
				} catch(e) { /* requires jQuery UI draggables */ }
			}
			
			return true;
			
		},
		_show: function() {
			if (($.popgFLfrm.styleIds[0] == undefined) ||($.popgFLfrm.styleIds[0] == '')) {
				$("#gFform_panel").css({
					 "zindex": 4575,
					 "min-width": $("#gFform_container").width(),
					 "height": "40px",
					 "top": $(window).outerHeight( true ) - 60,
					 "left": $("#gFform_container").position().left - 10
				});				
				$("#gFform_division").append('<div id="gFform_dummy" style="height: 80px;"></div>');
				
				var msgid = $("#gFform_division [id$='-message-box']").attr('id');
				if ((msgid != undefined) && (msgid !="")) {
					var classNames = $("#"+msgid).attr("class").toString();
					$("#"+msgid).remove();
					$("#gFLform_errors").append('<div id="'+ msgid +'"></div>');
					$("#"+msgid).addClass(classNames).css("display", "none");
					
					$("#gFLform_errors").css({
						zIndex: 4574,
						maxHeight: (($(window).outerHeight( true ) - $('.fix_header_class').outerHeight( true ) - 60) / 2),
						minWidth: $("#gFform_container").width() + 20,
						top: $('.fix_header_class').outerHeight( true ) + $('#gFform_title').outerHeight( true )  + 'px',
						left: 0
					});
				
				}
				popup_stack.push('FL');
				popup_help.push($.popgFLfrm.cnTxtHelp);
				if ($.popgFLfrm.cnTxtHelp <= 0) $("#brd_help").css("display","none");
						else $("#brd_help").css("display","inline");
				$("#brd_errors_ico").css("display","none");
				$("#brd_back, #brd_home").css("display", "inline-block");
				$("BODY").css("overflow", "hidden");
				$.popgFLfrm._overlay('show');
				fnProjectSelectorMenu( false );
				$("#gFform_container").css("display", "block");
			} else $.popgFLfrm.styleIds = [];
			
		},
		_errbox: function() {
			var msgid = $("#gFLform_errors [id$='-message-box']").attr('id');
			if ((msgid != undefined) && (msgid !="")) {
				if ($("#"+msgid).text() != '') {
					if ($("#gFLform_errors").css("display") == "none") $("#gFLform_errors").css("display", "block");
						else $("#gFLform_errors").css("display", "none");
				}
			}
		},
		_home: function() {
			clearPopUps("Mn");
		
		},
		_help: function() {
			// help function - centralized
			return;
		},
		_hide: function() {
			if (($.popgFLfrm.styleIds[0] == undefined) ||($.popgFLfrm.styleIds[0] == '')) {
				$('#ResHideShow, #CAHideShow').trigger('click'); /* This is to avoid a bug of not displaying the CA and RBS split-up properly */
				$("#gFform_container").remove();
				clearPopUps("FL");
				if ($.popgFLfrm.cntrlFlg == true) {
					$.popgFLfrm.cntrlFlg = false;
					procesMode = 2;
					$("#gnt-process-mode option[value='2']").attr("selected","selected");
					$("#project_governance").removeAttr('disabled').attr('title', 'Project Governance and Work Log').removeClass("ganttBaklog").addClass("baklog_detach");
					loadProjectGantt('');
				}
				$.popgFLfrm._overlay('hide');
				$.popgFLfrm._maintainPosition(false);
			} else $.popgFLfrm.styleIds = [];	
			if ($("[id$='form_container']").length == 0) $("BODY").css("overflow", "auto");
		},
		_overlay: function(status) {
			switch( status ) {
				case 'show':
					$.popgFLfrm._overlay('hide');
					$("BODY").append('<div id="gFform_overlay"></div>');
					$("#gFform_overlay").css({
						position: 'absolute',
						zIndex: 4568,
						top: $('.fix_header_class').outerHeight( true ) +'px',  
						left: 0,
						width: '100%',
						height: $(document).height() - $('.fix_header_class').outerHeight( true ) + 1,
						background: $.popgFLfrm.overlayColor,
						opacity: $.popgFLfrm.overlayOpacity
					});
				break;
				case 'hide':
					$("#gFform_overlay").remove();
				break;
			}
		},
		
		_reposition: function() {
			/*var top = (($(window).height() / 2) - ($("#gFform_container").outerHeight() / 2)) + $.popgFLfrm.verticalOffset;
			var left = (($(window).width() / 2) - ($("#gFform_container").outerWidth() / 2)) + $.popgFLfrm.horizontalOffset;
			if( top < 0 ) top = 0;
			if( left < 0 ) left = 0;
			 if( $.browser.msie && top <= 0 ) {
				var  divTPos=$("#gFform_container").position();
				top = top + $(window).scrollTop() + divTPos.top;
			} 
			// IE6 fix
			if( $.browser.msie && parseInt($.browser.version) <= 6 ) top = top + $(window).scrollTop();
			*/
			$("#gFform_container").css({
				top: $('.fix_header_class').outerHeight( true ) + 'px',
				left: 0
			});
			$("#gFform_overlay").height( $(document).height() );
		},
		
		_maintainPosition: function(status) {
			if( $.popgFLfrm.repositionOnResize ) {
				switch(status) {
					case true:
						$(window).bind('resize', $.popgFLfrm._reposition);
					break;
					case false:
						$(window).unbind('resize', $.popgFLfrm._reposition);
					break;
				}
			}
		}
		
	}
	
	
	jgfForms = function(message, value, title, styles) {
		switch(message){ 


			case 'GntTaskAdd': 
				$.popgFLfrm.GntTaskAdd(message, value, title, styles);
				break;

			case 'GntTaskInsert': 
				$.popgFLfrm.GntTaskInsert(message, value, title, styles);
				break;
			case 'GntTaskEdit': 
				$.popgFLfrm.GntTaskEdit(message, value, title, styles);
				break;
			case 'GntResourceUsage': 
				$.popgFLfrm.GntResourceUsage(message, value, title, styles);	
				break;
			case 'GntCAUsage': 
				$.popgFLfrm.GntCAUsage(message, value, title, styles);
				break;
			case 'GntTaskUpdate':  
				$.popgFLfrm.GntTaskUpdate(message, value, title, styles);	
				break;


			case 'GntTaskView': 
				$.popgFLfrm.GntTaskView(message, value, title, styles);
				break;
			case 'StakeGeneralView': 
				$.popgFLfrm.StakeGeneralView(message, value, title, styles);
				break;
			case 'ConsultantView': 
				$.popgFLfrm.ConsultantView(message, value, title, styles);	
				break;
			case 'RskRegCommentView': 
				$.popgFLfrm.RskRegCommentView(message, value, title, styles);
				break;
			case 'IsuRegCommentView': 
				$.popgFLfrm.IsuRegCommentView(message, value, title, styles);	
				break;


			case 'SponsorRegisterView': 
				$.popgFLfrm.SponsorRegisterView(message, value, title, styles);
				break;
			case 'ProjectDetailsView':  
				$.popgFLfrm.ProjectDetailsView(message, value, title, styles);
				break;
			case 'ProjectBacklog': 
				$.popgFLfrm.ProjectBacklog(message, value, title, styles);	
				break;

			case 'GntTaskMeeting': 
				$.popgFLfrm.GntTaskMeeting(message, value, title, styles);
				break;
			case 'GntInsertMeeting': 
				$.popgFLfrm.GntInsertMeeting(message, value, title, styles);
				break;
			case 'GntEditMeeting': 
				$.popgFLfrm.GntEditMeeting(message, value, title, styles);
				break;
			case 'AglAddSprint': 
				$.popgFLfrm.AglAddSprint(message, value, title, styles);
				break;
			case 'AglInsertSprint': 
				$.popgFLfrm.AglInsertSprint(message, value, title, styles);
				break;
				
			case 'AglEditSprint': 
				$.popgFLfrm.AglEditSprint(message, value, title, styles);
				break;
			case 'BakStoryAdd': 
				$.popgFLfrm.BakStoryAdd(message, value, title, styles);
				break;
			case 'BakStoryInsert': 
				$.popgFLfrm.BakStoryInsert(message, value, title, styles);
				break;
			case 'BakStoryEdit':  
				$.popgFLfrm.BakStoryEdit(message, value, title, styles);
				break;	
			case 'BakStoryUpdate': 
				$.popgFLfrm.BakStoryUpdate(message, value, title, styles);	
				break;

			case 'BakStoryView': 
				$.popgFLfrm.BakStoryView(message, value, title, styles);	
				break;
			case 'AglPullStory': 
				$.popgFLfrm.AglPullStory(message, value, title, styles);
				break;
			case 'AglInsertStory': 
				$.popgFLfrm.AglInsertStory(message, value, title, styles);
				break;
			case 'AglEditStory': 
				$.popgFLfrm.AglEditStory(message, value, title, styles);
				break;	
			case 'GntStoryUsage': 
				$.popgFLfrm.GntStoryUsage(message, value, title, styles);	
				break;	
		}
			
	}; 		
	
	
})(jQuery);